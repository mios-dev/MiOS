# MiOS Two-Clock Execution Pipeline & Persistent Invariants
## Fast-Clock Engine:
- Pre-commit AST linting, GBNF grammar validation, unit syntax verification.
## Slow-Clock Engine:
- Upstream LKML CXL 1:1 IOMMU tracking, host DMA frame buffers, long-term memory drift.
