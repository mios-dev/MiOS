# MiOS Capability Gap Remediation Goals & Stopping Invariants

## Stopping Conditions (Definition of Done):
1. [INVARIANT-HW]: Kernel 7.2.7 commit a73d902e eliminates DMAR status reg 2 faults on Blackwell PCIe 5.0 CXL.mem via pci=realloc,noaer,cxl_iommu_bypass=force.
2. [INVARIANT-SEC]: Tetragon v1.4.2 eBPF out-of-process gating intercepts 100% of unauthorized egress sockets with latency <= 2.0ms and zero /dev/kvmfr0 lock contention.
3. [INVARIANT-CUA]: Holo1.5-7B visual grounding loop achieves >= 70% task completion on OSWorld-G with cycle latency <= 120ms.
4. [INVARIANT-ISO]: 4-tier isolation ladder promotes untrusted scripts to Tier 4 libkrun microVMs with <= 90ms startup overhead.
5. [INVARIANT-REL]: Frozen admin-100 suite maintains Reliability AUC >= 0.965 with zero silent regression passes.
