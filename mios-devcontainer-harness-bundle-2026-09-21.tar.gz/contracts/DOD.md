# Definition of Done (DOD) - MiOS Autonomous Build Gates
1. Two-sided verification passed: Positive control produces valid artifact; negative control traps on planted fault.
2. Zero silent passes: Required artifacts must fail with exit code 1 if missing.
3. Shrink-only ratchets: Error budgets cannot be expanded.
4. Cryptographic manifest: Non-zero bytes registered in .devloop_artifacts/manifest.json with SHA-256.
