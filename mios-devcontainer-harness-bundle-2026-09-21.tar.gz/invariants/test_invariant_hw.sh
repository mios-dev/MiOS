#!/bin/bash
set -euo pipefail
echo "[TEST-INVARIANT-HW] Verifying Kernel 7.2.7 CXL IOMMU bypass parameter..."
grep -q "cxl_iommu_bypass=force" /usr/lib/bootc/kargs.d/50-vfio-security.kargs || {
    echo "[FAIL] Missing cxl_iommu_bypass=force" >&2
    exit 1
}
echo "[PASS] [INVARIANT-HW] verified."
