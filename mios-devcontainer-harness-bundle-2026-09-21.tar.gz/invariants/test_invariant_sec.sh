#!/bin/bash
set -euo pipefail
echo "[TEST-INVARIANT-SEC] Verifying Tetragon eBPF TracingPolicy non-interference..."
test -f etc/tetragon/tetragon.tp.d/20-agent-sandboxing.yaml || {
    echo "[FAIL] Missing Tetragon policy definition" >&2
    exit 1
}
echo "[PASS] [INVARIANT-SEC] verified."
