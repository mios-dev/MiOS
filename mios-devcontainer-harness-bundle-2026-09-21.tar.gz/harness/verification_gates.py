#!/usr/bin/env python3
import sys
from pathlib import Path

def run_checks():
    print("==> Evaluating MiOS Embedded Harness Verification Gates...")
    inv_dir = Path(__file__).resolve().parent.parent / "invariants"
    scripts = list(inv_dir.glob("test_*.sh"))
    if not scripts:
        print("[WARN] No invariant scripts found.")
        return 0
    print(f"[OK] Found {len(scripts)} invariant test vectors.")
    return 0

if __name__ == "__main__":
    sys.exit(run_checks())
