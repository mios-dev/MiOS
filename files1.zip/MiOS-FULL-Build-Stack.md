# MiOS — Complete Build Stack (every script, full source)

**Source:** `mios-dev/mios@v0.2.0` + `mios-dev/mios-bootstrap@v0.2.0`
**Total:** 66 files, ~6500 lines

This is the **entire build stack** — every shell script, PowerShell orchestrator, Containerfile, Justfile, and bootstrap installer that participates in producing or deploying a MiOS OCI image. Read in order to follow execution.

## Inventory

### Layer 1 — User entry points (run on a target Fedora host)

| File | Lines | Role |
|---|---|---|
| `bootstrap-repo/install-bootstrap.sh` | ~600 | **The user-facing one-liner.** Interactive ignition installer (sudo bash). Detects bootc vs FHS host, gathers identity, persists `/etc/mios/install.env`, then either `bootc switch` or clones `mios` and runs its FHS overlay |
| `bootstrap-repo/bootstrap.sh` | small | Convenience wrapper around `install-bootstrap.sh` |
| `bootstrap-repo/bootstrap.ps1` | small | Windows-side convenience wrapper |

### Layer 2 — System-side installers (run after bootstrap chooses the FHS path)

| File | Lines | Role |
|---|---|---|
| `install-fhs.sh` | ~50 | Applies the FHS overlay from the cloned `mios` repo to `/usr`, `/etc`, `/var`, `/srv`, `/v1`. Runs `systemd-sysusers`, `systemd-tmpfiles --create`, enables MiOS services. Refuses to run on bootc-managed hosts |
| `build-mios.sh` | 600+ | Full Fedora Server ignition installer with prompts, dnf installs, repo merge (`rsync --ignore-existing`), user creation, Python venv setup, optional `podman build` of the OCI image |

### Layer 3 — Image build orchestrators (run on a Linux or Windows builder)

| File | Lines | Role |
|---|---|---|
| `Containerfile` | 58 | OCI build entry — invokes everything in Layer 4 |
| `Justfile` | 280 | **Linux-native build orchestrator.** Targets: `preflight`, `build`, `build-logged`, `build-verbose`, `embed-log`, `rechunk`, `raw`, `iso`, `sbom`, `init-user-space`, `cloud-build`, `log-bootstrap`, `build-and-log`, `all-bootstrap` |
| `mios-build-local.ps1` | 1100+ | **Windows 5-phase build orchestrator.** Workflow menu (Local Build / Build+Push / Custom / Pull+Deploy), credential masking engine, Podman machine provisioning, BIB target generation (RAW→VHDX, WSL tarball, ISO), self-build helper image detection |
| `preflight.ps1` | ~120 | Windows prerequisite checker (WSL2, Hyper-V, Virtual Machine Platform, Podman, PS7+) |
| `push-to-github.ps1` | ~200 | Single, version-stable release pipeline. Clone → optional staged-dir overlay → bump VERSION → stamp CHANGELOG → commit → push |

### Layer 4 — Numbered build pipeline (the actual image construction)

These run **inside the Containerfile RUN layer**, orchestrated by `automation/build.sh`. Order matters.

#### 4a — Library (sourced by every numbered script)

| File | Lines | Role |
|---|---|---|
| `automation/lib/common.sh` | 39 | Shared logging (`log`, `warn`, `die`, `diag`), establishes `DNF_BIN`, `DNF_SETOPT[]`, `DNF_OPTS[]` |
| `automation/lib/packages.sh` | 102 | `PACKAGES.md` fenced-block parser. `get_packages`, `install_packages`, `install_packages_strict`, `install_packages_optional` |
| `automation/lib/masking.sh` | 106 | Credential masking, `add_mask`, `mask_filter`, `scurl` (token-injecting curl) |

#### 4b — Master orchestrator

| File | Lines | Role |
|---|---|---|
| `automation/build.sh` | 235 | Iterates `[0-9][0-9]-*.sh` in order, skip list for Containerfile-pre-steps, per-script timing, fail tracking, post-build validation, log preservation to `/usr/lib/mios/logs/` |

#### 4c — Phase 0: Repo overlay & kernel

| File | Lines | Role |
|---|---|---|
| `automation/01-repos.sh` | 161 | Two-phase F44 distro-sync, RPMFusion, Terra, CrowdSec, NVIDIA Container Toolkit repos with priority pinning |
| `automation/02-kernel.sh` | 43 | `kernel-modules-extra`, `kernel-devel`, `kernel-headers`, `kernel-tools` (NEVER `kernel`/`kernel-core`) |
| `automation/05-enable-external-repos.sh` | 107 | ublue-os/packages COPR for `uupd`, additional vendor repos |
| `automation/08-system-files-overlay.sh` | 102 | Rootfs-native overlay: `/ctx/usr → /usr` (ex `/usr/local`), `/ctx/usr/local → /var/usrlocal`, `/ctx/etc → /etc`, `/ctx/home → /var/home`. LBI symlinks. `restorecon` |

#### 4d — Phase 1: Desktop, hardware, virtualization, k8s

| File | Lines | Role |
|---|---|---|
| `automation/10-gnome.sh` | 170 | GNOME 50 minimal install (build-up), Geist font, Bibata cursor (3-attempt retry), Phosh mobile session, Flatpak remotes |
| `automation/11-hardware.sh` | 92 | Mesa stack + AMD ROCm + Intel compute (conditional, fault-tolerant) |
| `automation/12-virt.sh` | 98 | KVM/QEMU/libvirt, Cockpit, boot tools, CrowdSec sovereign mode, gaming, guests, storage, HA, utils, Waydroid, VirtIO-Win ISO |
| `automation/13-ceph-k3s.sh` | 90 | Ceph clients + cephadm, K3s binary download with sha256 verification |

#### 4e — Phase 2: Service config & boot fixes

| File | Lines | Role |
|---|---|---|
| `automation/18-apply-boot-fixes.sh` | 50 | Restore exec bits on `/usr/libexec/mios/*`, libvirt qemu hook +x, USBGuard 0600 perms, ordering cycle drop-ins, OCI/WSL2 service gating |
| `automation/19-k3s-selinux.sh` | 51 | Compile k3s-selinux from source (no Fedora package available) |
| `automation/20-fapolicyd-trust.sh` | 22 | Build fapolicyd trust DB |
| `automation/20-services.sh` | 44 | Enable core services |
| `automation/21-moby-engine.sh` | 18 | Optional Docker engine compat layer |
| `automation/22-freeipa-client.sh` | 44 | FreeIPA + SSSD setup |
| `automation/23-uki-render.sh` | 45 | UKI generation prep (future composefs+UKI) |
| `automation/25-firewall-ports.sh` | 16 | Open Cockpit (9090), SSH (22), libvirt bridge |
| `automation/26-gnome-remote-desktop.sh` | 13 | GNOME RDP service config |

#### 4f — Phase 3: User, locale, GPU, identity

| File | Lines | Role |
|---|---|---|
| `automation/30-locale-theme.sh` | 76 | en_US.UTF-8 + Adwaita-dark via dconf (NOT GTK_THEME=) |
| `automation/31-user.sh` | 87 | **Build-arg consumer.** Reads `MIOS_USER` + `MIOS_PASSWORD_HASH`, creates user with `chpasswd -e`, group memberships |
| `automation/32-hostname.sh` | 23 | hostnamectl set-hostname |
| `automation/33-firewall.sh` | 52 | Default-deny posture, allow SSH/Cockpit/libvirt/CrowdSec |
| `automation/34-gpu-detect.sh` | 13 | Stage mios-gpu-detect first-boot service |
| `automation/35-gpu-passthrough.sh` | 55 | VFIO setup for primary card |
| `automation/35-gpu-pv-shim.sh` | 69 | Para-virtualized GPU shim |
| `automation/35-init-service.sh` | 26 | Bootstrap init service registration |
| `automation/36-akmod-guards.sh` | 55 | Guard against akmod-nvidia install on ucore-hci (already pre-signed) |
| `automation/36-tools.sh` | 47 | CLI utility install set |

#### 4g — Phase 4: AI, Flatpak, SELinux, polish

| File | Lines | Role |
|---|---|---|
| `automation/37-aichat.sh` | 48 | aichat + aichat-ng Rust LLM CLIs |
| `automation/37-flatpak-env.sh` | 30 | Flatpak setup, Flathub remote at user level |
| `automation/37-ollama-prep.sh` | 103 | (CI-skipped) Ollama model staging |
| `automation/37-selinux.sh` | 174 | 19 custom SELinux modules + booleans + fcontexts |
| `automation/38-vm-gating.sh` | 70 | ConditionVirtualization= drop-ins |
| `automation/39-desktop-polish.sh` | 41 | Wallpapers, default apps |
| `automation/40-composefs-verity.sh` | 29 | composefs prepare-root.conf |

#### 4h — Phase 5: Supply-chain, updates, hardening, finalize

| File | Lines | Role |
|---|---|---|
| `automation/42-cosign-policy.sh` | 56 | cosign v2 install + Sigstore trust roots + policy.json |
| `automation/43-uupd-installer.sh` | 28 | Install uupd |
| `automation/44-podman-machine-compat.sh` | 50 | Stage `core` user for Podman-machine compat |
| `automation/45-nvidia-cdi-refresh.sh` | 55 | NVIDIA CDI generator timer |
| `automation/46-greenboot.sh` | 35 | Configure greenboot-rs |
| `automation/47-hardening.sh` | 38 | Apply hardening drop-ins |
| `automation/49-finalize.sh` | 41 | Final fix-ups before lint |
| `automation/50-enable-log-copy-service.sh` | 15 | Enable mios-copy-build-log.service |

#### 4i — Phase 6: From-source builds (Looking Glass + KVMFR)

| File | Lines | Role |
|---|---|---|
| `automation/52-bake-kvmfr.sh` | 120 | KVMFR akmod build with kernel-devel match check, MOK signing |
| `automation/53-bake-lookingglass-client.sh` | 103 | Looking Glass B7 from source via cmake |

#### 4j — Phase 7: SBOM, boot config, cleanup, validation

| File | Lines | Role |
|---|---|---|
| `automation/90-generate-sbom.sh` | 50 | Per-build SBOM (CycloneDX) |
| `automation/98-boot-config.sh` | 37 | systemd-boot/grub finalization |
| `automation/99-cleanup.sh` | 54 | Final image cleanup |
| `automation/99-postcheck.sh` | 95 | **Build-time invariant gate.** OpenSSH 9.6+, Cockpit LoginTo=false, NVIDIA CT 1.18+, critical tools present |

#### 4k — Helpers (not in numbered pipeline)

| File | Lines | Role |
|---|---|---|
| `automation/ai-bootstrap.sh` | 75 | Refresh AI manifests, UKB, Wiki documentation |
| `automation/bcvk-wrapper.sh` | 66 | bcvk (bootc Virtual Kernel) wrapper |
| `automation/enroll-mok.sh` | 213 | Machine Owner Key enrollment for Secure Boot |
| `automation/generate-mok-key.sh` | 123 | MOK keypair generation |

---


# Layer 1 — User entry points

---

## bootstrap-repo/install-bootstrap.sh

```bash
#!/usr/bin/env bash
#
# MiOS Bootstrap -- Interactive Ignition Installer
#
# Usage:
#   sudo bash -c "$(curl -fsSL https://raw.githubusercontent.com/MiOS-DEV/MiOS-bootstrap/main/install.sh)"
#   # or after cloning:
#   sudo /path/to/MiOS-bootstrap/install.sh
#
# Bootstrap's job:
#   1. Detect host kind (bootc-managed Fedora vs FHS Fedora vs unsupported).
#   2. Interactively gather installation profile -- everything defaults to
#      "mios" until the user overrides. Prompts:
#         - Linux username        (default: mios)
#         - Hostname              (default: mios)
#         - Full name (GECOS)     (default: "MiOS User")
#         - Password              (no default; prompt twice for confirm)
#         - SSH key handling      (default: generate ed25519)
#         - GitHub PAT            (default: skip)
#         - MiOS image / mode     (default: prebuilt bootc image)
#   3. Apply the profile to the host:
#         - hostnamectl set-hostname
#         - useradd -m -G wheel,libvirt,kvm,video,render,input,dialout
#         - chpasswd
#         - ssh-keygen + ~/.ssh/authorized_keys staging
#         - git credential helper for GitHub PAT
#         - persist non-secret profile to /etc/mios/install.env
#   4. Trigger the MiOS root install:
#         - bootc host: `bootc switch ghcr.io/MiOS-DEV/mios:latest`
#         - FHS host:   Merge MiOS core (mios.git) and Bootstrap (bootstrap.git) into /
#   5. Reboot prompt.
#
# Idempotent: re-running with the same answers updates rather than duplicates.

set -euo pipefail

# ============================================================================
# Defaults -- the "mios everywhere" convention. User overrides via prompts.
# ============================================================================
DEFAULT_USER="mios"
DEFAULT_HOST="mios"
DEFAULT_USER_FULLNAME="MiOS User"
DEFAULT_USER_SHELL="/bin/bash"
DEFAULT_USER_GROUPS="wheel,libvirt,kvm,video,render,input,dialout"
DEFAULT_SSH_KEY_TYPE="ed25519"
DEFAULT_IMAGE="ghcr.io/MiOS-DEV/mios:latest"
DEFAULT_BRANCH="main"

MIOS_REPO="https://github.com/MiOS-DEV/MiOS.git"
BOOTSTRAP_REPO="https://github.com/MiOS-DEV/MiOS-bootstrap.git"
PROFILE_DIR="/etc/mios"
PROFILE_FILE="${PROFILE_DIR}/install.env"
LOG_FILE="/var/log/mios-bootstrap.log"

# ============================================================================
# Logging
# ============================================================================
_BOLD=$(tput bold 2>/dev/null || echo "")
_RED=$(tput setaf 1 2>/dev/null || echo "")
_GREEN=$(tput setaf 2 2>/dev/null || echo "")
_YELLOW=$(tput setaf 3 2>/dev/null || echo "")
_CYAN=$(tput setaf 6 2>/dev/null || echo "")
_DIM=$(tput dim 2>/dev/null || echo "")
_RESET=$(tput sgr0 2>/dev/null || echo "")

log_info()  { printf '%s[INFO]%s %s\n' "${_CYAN}" "${_RESET}" "$*"; }
log_ok()    { printf '%s[ OK ]%s %s\n' "${_GREEN}" "${_RESET}" "$*"; }
log_warn()  { printf '%s[WARN]%s %s\n' "${_YELLOW}" "${_RESET}" "$*" >&2; }
log_err()   { printf '%s[ERR ]%s %s\n' "${_RED}" "${_RESET}" "$*" >&2; }
log_phase() { printf '\n%s%s== %s ==%s\n\n' "${_BOLD}" "${_CYAN}" "$*" "${_RESET}"; }

# ============================================================================
# Preflight
# ============================================================================
require_root() {
    if [[ $EUID -ne 0 ]]; then
        log_err "Bootstrap must run as root. Re-invoke with sudo:"
        log_err "  sudo $0"
        exit 1
    fi
}

detect_host_kind() {
    if command -v bootc >/dev/null 2>&1 && bootc status --format=json 2>/dev/null | grep -q '"booted"'; then
        echo "bootc"
    elif [[ -f /etc/os-release ]] && grep -qE '^ID(_LIKE)?=.*fedora' /etc/os-release; then
        echo "fhs-fedora"
    else
        echo "unsupported"
    fi
}

check_network() {
    local host
    for host in github.com ghcr.io; do
        if ! curl -fsSL --max-time 5 -o /dev/null "https://${host}/" 2>/dev/null; then
            log_err "No network reachability to ${host}. Check your network and re-run."
            exit 1
        fi
    done
    log_ok "Network reachability verified"
}

# ============================================================================
# Prompts -- the "mios" defaults are baked in; user just hits Enter to accept.
# ============================================================================
prompt_default() {
    local question="$1" default="$2" answer
    read -r -p "$(printf '%s%s%s [%s%s%s]: ' "${_BOLD}" "${question}" "${_RESET}" "${_DIM}" "${default}" "${_RESET}")" answer
    echo "${answer:-$default}"
}

prompt_password() {
    local prompt="$1" pw1 pw2
    while :; do
        printf '%s%s%s: ' "${_BOLD}" "${prompt}" "${_RESET}" >&2
        read -rs pw1; echo >&2
        printf '%sConfirm:%s ' "${_BOLD}" "${_RESET}" >&2
        read -rs pw2; echo >&2
        if [[ "$pw1" == "$pw2" ]]; then
            if [[ -z "$pw1" ]]; then
                log_warn "Empty password not allowed."
                continue
            fi
            echo "$pw1"
            return 0
        fi
        log_warn "Passwords don't match, please try again."
    done
}

prompt_yesno() {
    local question="$1" default="${2:-y}" answer hint
    if [[ "$default" == "y" ]]; then hint="[Y/n]"; else hint="[y/N]"; fi
    read -r -p "$(printf '%s%s%s %s: ' "${_BOLD}" "${question}" "${_RESET}" "${hint}")" answer
    answer="${answer:-$default}"
    case "${answer,,}" in
        y|yes) return 0 ;;
        *) return 1 ;;
    esac
}

# ============================================================================
# Phase 2: gather installation profile
# ============================================================================
gather_user_choices() {
    log_phase "Installation profile"
    log_info "Press Enter to accept defaults (everything defaults to MiOS)."
    echo

    LINUX_USER="$(prompt_default 'Linux username' "${DEFAULT_USER}")"
    HOSTNAME_VAL="$(prompt_default 'Hostname' "${DEFAULT_HOST}")"
    USER_FULLNAME="$(prompt_default 'Full name (GECOS)' "${DEFAULT_USER_FULLNAME}")"

    log_info "Setting password for '${LINUX_USER}' (will be a sudoer):"
    USER_PASSWORD="$(prompt_password 'Password')"

    SSH_CHOICE="$(prompt_default 'SSH key: (g)enerate ed25519 / (e)xisting path / (s)kip' 'g')"
    case "${SSH_CHOICE,,}" in
        e|existing) SSH_KEY_PATH="$(prompt_default 'Existing private key path' "/root/.ssh/id_${DEFAULT_SSH_KEY_TYPE}")" ;;
        s|skip)     SSH_KEY_PATH="" ;;
        *)          SSH_KEY_PATH="generate" ;;
    esac

    if prompt_yesno 'Configure GitHub PAT for git credential helper?' n; then
        printf '%sGitHub PAT (input hidden):%s ' "${_BOLD}" "${_RESET}"
        read -rs GH_TOKEN; echo
    else
        GH_TOKEN=""
    fi

    local hostkind
    hostkind="$(detect_host_kind)"
    if [[ "$hostkind" == "bootc" ]]; then
        IMAGE_TAG="$(prompt_default 'MiOS bootc image' "${DEFAULT_IMAGE}")"
        INSTALL_MODE="bootc"
    else
        # FHS mode is always "fhs" for total root overlay in this branch.
        INSTALL_MODE="fhs"
        IMAGE_TAG=""
    fi
}

# ============================================================================
# Phase 3: confirm before applying
# ============================================================================
print_summary() {
    log_phase "Review profile"
    cat <<EOF
  ${_BOLD}Linux user${_RESET}     : ${LINUX_USER}  (full name: ${USER_FULLNAME})
  ${_BOLD}Sudo groups${_RESET}    : ${DEFAULT_USER_GROUPS}
  ${_BOLD}Hostname${_RESET}       : ${HOSTNAME_VAL}
  ${_BOLD}Password${_RESET}       : (set, hidden)
  ${_BOLD}SSH key${_RESET}        : ${SSH_KEY_PATH:-skip}
  ${_BOLD}GitHub PAT${_RESET}     : $([ -n "${GH_TOKEN:-}" ] && echo 'configured' || echo 'skip')
  ${_BOLD}Install mode${_RESET}   : ${INSTALL_MODE} (Total Root Overlay)

EOF
    if ! prompt_yesno 'Proceed with these settings?' y; then
        log_info "Aborted by user. No changes made."
        exit 0
    fi
}

# ============================================================================
# Phase 4: apply profile to host
# ============================================================================
apply_user_profile() {
    log_phase "Apply profile to host"
    mkdir -p "${PROFILE_DIR}"
    chmod 0750 "${PROFILE_DIR}"

    log_info "Setting hostname -> ${HOSTNAME_VAL}"
    hostnamectl set-hostname "${HOSTNAME_VAL}"

    if id -u "${LINUX_USER}" >/dev/null 2>&1; then
        log_info "User '${LINUX_USER}' exists; updating groups + password"
        usermod -aG "${DEFAULT_USER_GROUPS}" "${LINUX_USER}"
        usermod -c "${USER_FULLNAME}" "${LINUX_USER}"
    else
        log_info "Creating '${LINUX_USER}' (groups: ${DEFAULT_USER_GROUPS})"
        useradd -m -G "${DEFAULT_USER_GROUPS}" -s "${DEFAULT_USER_SHELL}" -c "${USER_FULLNAME}" "${LINUX_USER}"
    fi
    echo "${LINUX_USER}:${USER_PASSWORD}" | chpasswd
    log_ok "User '${LINUX_USER}' configured"

    local home; home="$(getent passwd "${LINUX_USER}" | cut -d: -f6)"
    if [[ "$SSH_KEY_PATH" == "generate" ]]; then
        log_info "Generating ${DEFAULT_SSH_KEY_TYPE} key for ${LINUX_USER}"
        sudo -u "${LINUX_USER}" mkdir -p "${home}/.ssh"
        chmod 0700 "${home}/.ssh"
        sudo -u "${LINUX_USER}" ssh-keygen -q -t "${DEFAULT_SSH_KEY_TYPE}" -N '' \
            -C "mios@${HOSTNAME_VAL}" \
            -f "${home}/.ssh/id_${DEFAULT_SSH_KEY_TYPE}"
        log_ok "SSH key generated: ${home}/.ssh/id_${DEFAULT_SSH_KEY_TYPE}"
    elif [[ -n "$SSH_KEY_PATH" ]]; then
        if [[ ! -f "$SSH_KEY_PATH" ]]; then
            log_warn "SSH key path not found: ${SSH_KEY_PATH} -- skipping"
        else
            log_info "Installing SSH key from ${SSH_KEY_PATH}"
            sudo -u "${LINUX_USER}" mkdir -p "${home}/.ssh"
            cp "${SSH_KEY_PATH}" "${home}/.ssh/id_${DEFAULT_SSH_KEY_TYPE}"
            cp "${SSH_KEY_PATH}.pub" "${home}/.ssh/id_${DEFAULT_SSH_KEY_TYPE}.pub" 2>/dev/null || true
            chown "${LINUX_USER}:${LINUX_USER}" "${home}/.ssh"/*
            chmod 0600 "${home}/.ssh/id_${DEFAULT_SSH_KEY_TYPE}"
            log_ok "SSH key installed"
        fi
    fi

    if [[ -n "${GH_TOKEN:-}" ]]; then
        sudo -u "${LINUX_USER}" mkdir -p "${home}/.config/git"
        sudo -u "${LINUX_USER}" git config --file "${home}/.config/git/config" credential.helper store
        echo "https://${LINUX_USER}:${GH_TOKEN}@github.com" > "${home}/.git-credentials"
        chmod 0600 "${home}/.git-credentials"
        chown "${LINUX_USER}:${LINUX_USER}" "${home}/.git-credentials"
        log_ok "GitHub credential helper configured"
    fi

    cat > "${PROFILE_FILE}" <<EOF
# MiOS install profile -- written by mios-bootstrap install.sh
# Non-secret installation metadata. Passwords/tokens are NOT stored here.
MIOS_LINUX_USER="${LINUX_USER}"
MIOS_HOSTNAME="${HOSTNAME_VAL}"
MIOS_USER_FULLNAME="${USER_FULLNAME}"
MIOS_USER_GROUPS="${DEFAULT_USER_GROUPS}"
MIOS_INSTALL_MODE="${INSTALL_MODE}"
MIOS_IMAGE_TAG="${IMAGE_TAG}"
MIOS_INSTALLED_AT="$(date -u --iso-8601=seconds)"
MIOS_BOOTSTRAP_VERSION="0.2.0"
EOF
    chmod 0640 "${PROFILE_FILE}"
    log_ok "Profile written: ${PROFILE_FILE}"
}

# ============================================================================
# Phase 4b: deploy AI system prompt
# ============================================================================
deploy_system_prompt() {
    log_phase "Deploy AI system prompt"
    install -d -m 0755 /etc/mios/ai

    local src_local prompt_url
    src_local="$(dirname "${BASH_SOURCE[0]}")/system-prompt.md"
    prompt_url="https://raw.githubusercontent.com/MiOS-DEV/MiOS-bootstrap/${DEFAULT_BRANCH}/system-prompt.md"

    if [[ -f "$src_local" ]]; then
        log_info "Using local system-prompt.md from ${src_local}"
        install -m 0644 "$src_local" /etc/mios/ai/system-prompt.md
    else
        log_info "Fetching system prompt from ${prompt_url}"
        if curl -fsSL --max-time 30 "$prompt_url" -o /etc/mios/ai/system-prompt.md.new; then
            mv /etc/mios/ai/system-prompt.md.new /etc/mios/ai/system-prompt.md
            chmod 0644 /etc/mios/ai/system-prompt.md
        else
            rm -f /etc/mios/ai/system-prompt.md.new
            log_warn "Could not fetch system prompt"
            return 0
        fi
    fi
    log_ok "System prompt deployed: /etc/mios/ai/system-prompt.md"
}

# ============================================================================
# Phase 5: trigger MiOS root install (TOTAL MERGE)
# ============================================================================
trigger_mios_install() {
    log_phase "Trigger MiOS Total Root Merge"
    
    case "${INSTALL_MODE}" in
        bootc)
            log_info "Switching bootc deployment to ${IMAGE_TAG}"
            bootc switch "${IMAGE_TAG}"
            log_ok "bootc deployment staged"
            ;;
        fhs)
            # 1. Initialize / as the git root for MiOS core
            log_info "Staging MiOS core repository (mios.git) to /"
            if [[ ! -d "/.git" ]]; then
                git init /
                git -C / remote add origin "${MIOS_REPO}"
            fi
            
            # Fetch and Force Checkout MiOS into root (respects .gitignore)
            git -C / fetch --depth=1 origin "${DEFAULT_BRANCH}"
            git -C / checkout -f "${DEFAULT_BRANCH}"
            log_ok "MiOS core (mios.git) merged to /"

            # 2. Apply MiOS-bootstrap repo overlays
            local bootstrap_tmp="/tmp/mios-bootstrap-src"
            log_info "Fetching MiOS-bootstrap overlays from ${BOOTSTRAP_REPO}"
            rm -rf "${bootstrap_tmp}"
            git clone --depth=1 "${BOOTSTRAP_REPO}" "${bootstrap_tmp}"
            
            log_info "Merging bootstrap system folders (etc, usr, var) to /"
            for d in etc usr var; do
                if [[ -d "${bootstrap_tmp}/${d}" ]]; then
                    cp -rv "${bootstrap_tmp}/${d}/"* "/${d}/" 2>/dev/null || true
                fi
            done
            
            local home; home="$(getent passwd "${LINUX_USER}" | cut -d: -f6)"
            if [[ -d "${bootstrap_tmp}/profile" ]]; then
                log_info "Staging user-space profile to ${home}"
                cp -rv "${bootstrap_tmp}/profile/"* "${home}/"
                chown -R "${LINUX_USER}:${LINUX_USER}" "${home}"
            fi
            rm -rf "${bootstrap_tmp}"
            log_ok "MiOS-bootstrap overlays applied"

            # 3. Comprehensive Package Installation for Self-Building support
            if [[ -f "/usr/share/mios/PACKAGES.md" ]]; then
                log_info "Installing full MiOS package stack from manifest (PACKAGES.md)..."
                
                # Extract all package names from fenced code blocks tagged with ```packages-*
                local pkgs
                pkgs=$(sed -n '/^```packages-/,/^```$/{/^```/d;/^#/d;/^$/d;p}' /usr/share/mios/PACKAGES.md | tr '\n' ' ')
                
                if [[ -n "$pkgs" ]]; then
                    # Determine DNF command
                    local dnf_cmd="dnf"
                    command -v dnf5 >/dev/null 2>&1 && dnf_cmd="dnf5"
                    
                    log_info "Executing: $dnf_cmd install -y --skip-unavailable --best $pkgs"
                    $dnf_cmd install -y --skip-unavailable --best $pkgs || log_warn "Some packages failed to install."
                else
                    log_warn "No packages found in PACKAGES.md manifest."
                fi
            else
                log_err "CRITICAL: /usr/share/mios/PACKAGES.md not found! Package installation skipped."
            fi

            # 4. Final MiOS System Initiation
            if [[ -x "/install.sh" ]]; then
                log_info "Running MiOS system-side installer from /"
                bash "/install.sh"
                log_ok "MiOS FHS system overlay complete"
            else
                log_err "MiOS install.sh not found at /install.sh"
                exit 1
            fi
            ;;
    esac
}

# ============================================================================
# Phase 6: reboot prompt
# ============================================================================
reboot_prompt() {
    log_phase "Reboot"
    if prompt_yesno 'Reboot now to activate MiOS?' y; then
        log_info "Rebooting in 3s..."
        sleep 3
        systemctl reboot
    else
        log_info "Skipping reboot. Run 'sudo systemctl reboot' when ready."
    fi
}

# ============================================================================
# Main
# ============================================================================
main() {
    require_root
    log_phase "MiOS Bootstrap Installer (Total Root Merge Mode)"

    local hostkind
    hostkind="$(detect_host_kind)"
    if [[ "$hostkind" == "unsupported" ]]; then
        log_err "Host is not Fedora. Aborting."
        exit 1
    fi
    log_info "Detected host: ${hostkind}"

    check_network
    gather_user_choices
    print_summary
    apply_user_profile
    deploy_system_prompt
    trigger_mios_install
    reboot_prompt
}

main "$@"
```

---

## bootstrap-repo/bootstrap.sh

```bash
#!/bin/bash
# MiOS Public Bootstrap — Linux / WSL2
# Repository: MiOS-DEV/MiOS-bootstrap
# Usage: curl -fsSL https://raw.githubusercontent.com/MiOS-DEV/MiOS-bootstrap/main/bootstrap.sh | bash
set -euo pipefail

PRIVATE_INSTALLER="https://raw.githubusercontent.com/MiOS-DEV/mios/main/install.sh"
_ENV_FILE="${XDG_CONFIG_HOME:-$HOME/.config}/mios/mios-build.env"

_r=$'\033[0m'; _b=$'\033[1m'; _dim=$'\033[2m'; _c=$'\033[36m'; _g=$'\033[32m'; _red=$'\033[31m'; _y=$'\033[33m'

echo ""
echo "  ${_c}╔══════════════════════════════════════════════════════════════╗${_r}"
echo "  ${_c}║  MiOS — Local Build Configuration                           ║${_r}"
echo "  ${_c}╚══════════════════════════════════════════════════════════════╝${_r}"
echo ""

# ── Load saved build config ────────────────────────────────────────────────
if [[ -f "$_ENV_FILE" ]]; then
    echo "  ${_dim}Found saved config: $_ENV_FILE${_r}"
    read -rp "  Load previous build variables? [Y/n]: " _load_ok </dev/tty
    if [[ "${_load_ok,,}" != "n" ]]; then
        set +u
        # shellcheck source=/dev/null
        source "$_ENV_FILE"
        set -u
        echo "  ${_g}[OK]${_r} Loaded."
        echo ""
    fi
fi

# ── GitHub PAT (required for private repo access) ─────────────────────────
if [[ -z "${GHCR_TOKEN:-}" ]]; then
    read -rsp "  ${_b}GitHub PAT${_r} (requires 'repo' scope): " GHCR_TOKEN </dev/tty; echo ""
fi
if [[ -z "${GHCR_TOKEN:-}" ]]; then
    echo "  ${_red}[!] Token required.${_r}"; exit 1
fi
export GHCR_TOKEN

echo ""
echo "  ${_y}── Build Configuration ─────────────────────────────────────────${_r}"
echo ""

# ── Admin username ─────────────────────────────────────────────────────────
if [[ -z "${MIOS_USER:-}" ]]; then
    read -rp "  Admin username ${_dim}[mios]${_r}: " MIOS_USER </dev/tty
    MIOS_USER="${MIOS_USER:-mios}"
else
    echo "  Admin username: ${MIOS_USER}  ${_dim}(env)${_r}"
fi
export MIOS_USER

# ── Admin password ─────────────────────────────────────────────────────────
if [[ -z "${MIOS_PASSWORD:-}" ]]; then
    while true; do
        read -rsp "  Admin password: " MIOS_PASSWORD </dev/tty; echo ""
        [[ -z "${MIOS_PASSWORD:-}" ]] && { echo "  ${_red}[!] Password cannot be empty.${_r}"; continue; }
        read -rsp "  Confirm password: " _c2 </dev/tty; echo ""
        [[ "$MIOS_PASSWORD" == "$_c2" ]] && break
        echo "  ${_red}[!] Mismatch — try again.${_r}"
    done
else
    echo "  Admin password: ${_dim}(env — masked)${_r}"
fi
export MIOS_PASSWORD

# ── Hostname ───────────────────────────────────────────────────────────────
# Suffix is generated first so the user sees the full hostname in the prompt.
if [[ -z "${MIOS_HOSTNAME:-}" ]]; then
    _suf=$(shuf -i 10000-99999 -n1 2>/dev/null || printf '%05d' $(( RANDOM % 90000 + 10000 )))
    read -rp "  Hostname base ${_dim}[mios]${_r} (suffix -${_suf} is pre-generated -> mios-${_suf}): " _hbase </dev/tty
    _hbase="${_hbase:-mios}"
    export MIOS_HOSTNAME="${_hbase}-${_suf}"
else
    echo "  Hostname: ${MIOS_HOSTNAME}  ${_dim}(env)${_r}"
fi

# ── Optional: GHCR push credentials ───────────────────────────────────────
if [[ -z "${MIOS_GHCR_USER:-}" ]]; then
    echo ""
    read -rp "  GHCR push username ${_dim}[skip]${_r}: " MIOS_GHCR_USER </dev/tty
fi
export MIOS_GHCR_USER="${MIOS_GHCR_USER:-}"

if [[ -n "$MIOS_GHCR_USER" && -z "${MIOS_GHCR_PUSH_TOKEN:-}" ]]; then
    read -rsp "  GHCR push token ${_dim}[reuse GitHub PAT]${_r}: " MIOS_GHCR_PUSH_TOKEN </dev/tty; echo ""
    export MIOS_GHCR_PUSH_TOKEN="${MIOS_GHCR_PUSH_TOKEN:-$GHCR_TOKEN}"
fi

# ── Summary ────────────────────────────────────────────────────────────────
echo ""
echo "  ${_y}── Summary ──────────────────────────────────────────────────────${_r}"
echo ""
printf "    %-20s %s\n" "Admin user:"     "$MIOS_USER"
printf "    %-20s %s\n" "Admin password:" "(masked)"
printf "    %-20s %s\n" "Hostname:"       "$MIOS_HOSTNAME"
printf "    %-20s %s\n" "Registry push:"  "${MIOS_GHCR_USER:-none (local build only)}"
printf "    %-20s %s\n" "Config saved to:" "$_ENV_FILE"
echo ""
read -rp "  ${_b}Proceed?${_r} [Y/n]: " _ok </dev/tty
[[ "${_ok,,}" == "n" ]] && { echo "  Aborted."; exit 0; }

# ── Save build config ──────────────────────────────────────────────────────
mkdir -p "$(dirname "$_ENV_FILE")"
{
    printf '# MiOS Build Configuration\n'
    printf '# Generated: %s\n' "$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
    printf 'GHCR_TOKEN=%q\n'    "$GHCR_TOKEN"
    printf 'MIOS_USER=%q\n'     "$MIOS_USER"
    printf 'MIOS_PASSWORD=%q\n' "$MIOS_PASSWORD"
    printf 'MIOS_HOSTNAME=%q\n' "$MIOS_HOSTNAME"
    [[ -n "${MIOS_GHCR_USER:-}" ]]       && printf 'MIOS_GHCR_USER=%q\n'       "$MIOS_GHCR_USER"
    [[ -n "${MIOS_GHCR_PUSH_TOKEN:-}" ]] && printf 'MIOS_GHCR_PUSH_TOKEN=%q\n' "$MIOS_GHCR_PUSH_TOKEN"
} > "$_ENV_FILE"
chmod 600 "$_ENV_FILE"
echo "  ${_g}[OK]${_r} Build config saved → ${_dim}$_ENV_FILE${_r}"

# ── Fetch and execute private installer ───────────────────────────────────
export MIOS_AUTOINSTALL=1
echo ""
echo "  [+] Fetching private installer..."
_tmp=$(mktemp /tmp/mios-install-XXXXXX.sh)
if curl -fsSL -H "Authorization: token $GHCR_TOKEN" "$PRIVATE_INSTALLER" -o "$_tmp"; then
    chmod +x "$_tmp"
    echo "  ${_g}[OK]${_r} Launching installer."
    echo ""
    bash "$_tmp"
    rm -f "$_tmp"
else
    rm -f "$_tmp"
    echo "  ${_red}[!] Failed to fetch installer. Check token and repo permissions.${_r}"
    exit 1
fi
```

---

## bootstrap-repo/bootstrap.ps1

```powershell
# MiOS Unified Bootstrap v2 - Windows (PowerShell 5.1+)
# Repository: MiOS-DEV/MiOS-bootstrap
# Single-pass configuration wizard - ALL variables collected upfront
# Usage: irm https://raw.githubusercontent.com/MiOS-DEV/MiOS-bootstrap/main/bootstrap-v2.ps1 | iex

$ErrorActionPreference = "Stop"

# ============================================================================
# XDG-Style Directory Structure (Windows-adapted)
# ============================================================================
$XDG_DATA_HOME = Join-Path $env:LOCALAPPDATA "MiOS"          # ~/.local/share/mios
$XDG_CONFIG_HOME = Join-Path $env:APPDATA "MiOS"             # ~/.config/mios
$XDG_CACHE_HOME = Join-Path $env:LOCALAPPDATA "MiOS\cache"   # ~/.cache/mios
$XDG_STATE_HOME = Join-Path $env:LOCALAPPDATA "MiOS\state"   # ~/.local/state/mios

$MiosConfigFile = Join-Path $XDG_CONFIG_HOME "registry.toml" # Single source of truth
$MiosEnvFile = Join-Path $XDG_CONFIG_HOME "build.env"        # Legacy support
$MiosSecretsFile = Join-Path $XDG_STATE_HOME "secrets.env"   # SHA-512 hashes + tokens
$MiosLogsDir = Join-Path $XDG_STATE_HOME "logs"
$MiosBuildDir = Join-Path $XDG_CACHE_HOME "builds"
$MiosRepoDir = Join-Path $XDG_DATA_HOME "repo"

$PublicInstaller = "https://raw.githubusercontent.com/MiOS-DEV/MiOS-bootstrap/main/mios-build-local.ps1"

# ============================================================================
# Helper Functions
# ============================================================================

function Set-SecureACL {
    param([string]$Path)
    if (-not (Test-Path $Path)) { return }
    try {
        $acl = Get-Acl $Path
        $acl.SetAccessRuleProtection($true, $false)
        $currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $currentUser, "FullControl", "Allow"
        )
        $acl.AddAccessRule($rule)
        $adminRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            "Administrators", "FullControl", "Allow"
        )
        $acl.AddAccessRule($adminRule)
        Set-Acl $Path $acl
    } catch {
        Write-Host "  [!] Warning: Could not restrict permissions on $Path" -ForegroundColor Yellow
    }
}

function Read-Secret {
    param([string]$Prompt)
    Write-Host "  $Prompt " -NoNewline -ForegroundColor White
    if ($PSVersionTable.PSVersion.Major -ge 7) {
        return Read-Host -MaskInput
    }
    $sec  = Read-Host -AsSecureString
    $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
    try   { return [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
    finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

function Read-WithDefault {
    param([string]$Prompt, [string]$Default = "")
    Write-Host "  $Prompt " -NoNewline -ForegroundColor White
    if ($Default) { Write-Host "[$Default] " -NoNewline -ForegroundColor DarkGray }
    $val = Read-Host
    if ([string]::IsNullOrWhiteSpace($val)) { return $Default }
    return $val
}

function Get-SHA512Hash {
    param([string]$PlainText)
    # Generate SHA-512 crypt-style hash (format: $6$salt$hash)
    # Compatible with Linux shadow file format
    $salt = -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 16 | ForEach-Object { [char]$_ })
    $saltPrefix = "`$6`$$salt`$"

    $encoder = [System.Text.Encoding]::UTF8
    $hasher = [System.Security.Cryptography.SHA512]::Create()
    $bytes = $encoder.GetBytes($PlainText + $salt)
    $hashBytes = $hasher.ComputeHash($bytes)
    $hashB64 = [Convert]::ToBase64String($hashBytes).Replace("+", ".").Replace("=", "")

    return "$saltPrefix$hashB64"
}

# ============================================================================
# Main Wizard
# ============================================================================

Write-Host ""
Write-Host "  ╔══════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "  ║  MiOS v0.2.0 -- Unified Bootstrap Wizard                         ║" -ForegroundColor Cyan
Write-Host "  ╚══════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""
Write-Host "  This wizard collects ALL configuration variables ONCE," -ForegroundColor Gray
Write-Host "  then propagates them through the entire build pipeline." -ForegroundColor Gray
Write-Host ""

# Stage directories
Write-Host "  [1/7] Creating XDG-compliant directories..." -ForegroundColor Yellow
foreach ($d in @($XDG_DATA_HOME, $XDG_CONFIG_HOME, $XDG_CACHE_HOME, $XDG_STATE_HOME, $MiosLogsDir, $MiosBuildDir, $MiosRepoDir)) {
    if (-not (Test-Path $d)) {
        New-Item -ItemType Directory -Path $d -Force | Out-Null
        Write-Host "    Created: $d" -ForegroundColor DarkGray
    }
}
Write-Host "  [OK]" -ForegroundColor Green
Write-Host ""

# Configure WSL2
Write-Host "  [2/7] Configuring WSL2 for MiOS..." -ForegroundColor Yellow
try {
    $wslConfigPath = Join-Path $env:USERPROFILE ".wslconfig"
    $totalRAM = (Get-CimInstance Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum).Sum
    $wslRAM = [Math]::Max(16, [Math]::Floor($totalRAM / 1GB * 0.80))
    $wslCPUs = (Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors

    $wslConfig = @"
# MiOS v0.2.0 - WSL2 Configuration
[wsl2]
memory=${wslRAM}GB
processors=${wslCPUs}
swap=8GB
localhostForwarding=true
nestedVirtualization=true
vmIdleTimeout=-1
systemd=true

[experimental]
networkingMode=mirrored
dnsTunneling=true
autoProxy=true
"@

    if (Test-Path $wslConfigPath) {
        $backup = "${wslConfigPath}.bak.$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        Copy-Item $wslConfigPath $backup -Force
        Write-Host "    Backed up existing .wslconfig to $backup" -ForegroundColor DarkGray
    }
    $wslConfig | Set-Content $wslConfigPath -Encoding UTF8
    Write-Host "  [OK] ${wslRAM}GB RAM, $wslCPUs CPUs" -ForegroundColor Green
} catch {
    Write-Host "  [!] Failed to configure .wslconfig (non-fatal)" -ForegroundColor Yellow
}
Write-Host ""

# ============================================================================
# Phase 3: Collect ALL Variables Upfront
# ============================================================================

Write-Host "  ╔══════════════════════════════════════════════════════════════════╗" -ForegroundColor Yellow
Write-Host "  ║  [3/7] Configuration Collection - Answer ALL questions below     ║" -ForegroundColor Yellow
Write-Host "  ╚══════════════════════════════════════════════════════════════════╝" -ForegroundColor Yellow
Write-Host ""

# User Account
Write-Host "  ┌─ User Account ────────────────────────────────────────────────┐" -ForegroundColor Cyan
$MIOS_USER = Read-WithDefault "Admin username:" "mios"
while ($true) {
    $pw1 = Read-Secret "Admin password:"
    if (-not $pw1) { Write-Host "  [!] Password cannot be empty." -ForegroundColor Red; continue }
    $pw2 = Read-Secret "Confirm password:"
    if ($pw1 -eq $pw2) {
        $MIOS_PASSWORD = $pw1
        $MIOS_PASSWORD_HASH = Get-SHA512Hash $pw1
        break
    }
    Write-Host "  [!] Passwords do not match. Try again." -ForegroundColor Red
}
Write-Host "  └───────────────────────────────────────────────────────────────┘" -ForegroundColor Cyan
Write-Host ""

# Hostname
Write-Host "  ┌─ Hostname ────────────────────────────────────────────────────┐" -ForegroundColor Cyan
$suffix = '{0:D5}' -f (Get-Random -Minimum 10000 -Maximum 99999)
$hbase = Read-WithDefault "Hostname base (suffix -$suffix will be appended):" "mios"
$MIOS_HOSTNAME = "$hbase-$suffix"
Write-Host "    Full hostname: $MIOS_HOSTNAME" -ForegroundColor DarkGray
Write-Host "  └───────────────────────────────────────────────────────────────┘" -ForegroundColor Cyan
Write-Host ""

# GitHub Access (for private MiOS repository)
Write-Host "  ┌─ GitHub Access ───────────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "  " -NoNewline
Write-Host "MiOS is a private repository - GitHub credentials required" -ForegroundColor Yellow
Write-Host ""
$GITHUB_USER = Read-Host "  GitHub username"
if ([string]::IsNullOrWhiteSpace($GITHUB_USER)) {
    Write-Host "  [!] GitHub username is required to clone MiOS repository." -ForegroundColor Red
    exit 1
}
$GITHUB_TOKEN = Read-Secret "GitHub PAT (with repo scope):"
if ([string]::IsNullOrWhiteSpace($GITHUB_TOKEN)) {
    Write-Host "  [!] GitHub token is required to clone MiOS repository." -ForegroundColor Red
    exit 1
}
Write-Host "  └───────────────────────────────────────────────────────────────┘" -ForegroundColor Cyan
Write-Host ""

# Flatpak Selection
Write-Host "  ┌─ Flatpak Applications ────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "  " -NoNewline
Write-Host "DEFAULT apps:" -ForegroundColor White
Write-Host "    - Flatseal, LocalSend, Bottles, Ptyxis, Pods, " -ForegroundColor DarkGray
Write-Host "      Extension Manager, Warehouse" -ForegroundColor DarkGray
Write-Host ""
$addMore = Read-Host "  Add more Flatpaks? (comma-separated IDs, or press Enter to skip)"
$MIOS_FLATPAKS = @(
    "com.github.tchx84.Flatseal",
    "org.localsend.localsend_app",
    "com.usebottles.bottles",
    "app.devsuite.Ptyxis",
    "com.github.marhkb.Pods",
    "com.mattjakeman.ExtensionManager",
    "io.github.flattool.Warehouse"
)
if (![string]::IsNullOrWhiteSpace($addMore)) {
    $additionalFlatpaks = $addMore -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" }
    $MIOS_FLATPAKS += $additionalFlatpaks
    Write-Host "    Added: $($additionalFlatpaks -join ', ')" -ForegroundColor Green
}
$MIOS_FLATPAKS_STR = $MIOS_FLATPAKS -join ','
Write-Host "    Total: $($MIOS_FLATPAKS.Count) apps" -ForegroundColor DarkGray
Write-Host "  └───────────────────────────────────────────────────────────────┘" -ForegroundColor Cyan
Write-Host ""

# Registry Push (Optional)
Write-Host "  ┌─ Registry Push (Optional) ────────────────────────────────────┐" -ForegroundColor Cyan
$GHCR_USER = Read-WithDefault "GHCR username (skip for local-only):" ""
if ($GHCR_USER) {
    $GHCR_TOKEN = Read-Secret "GHCR token (PAT with packages:write scope):"
} else {
    Write-Host "    Skipping registry push (local build only)" -ForegroundColor DarkGray
    $GHCR_TOKEN = ""
}
Write-Host "  └───────────────────────────────────────────────────────────────┘" -ForegroundColor Cyan
Write-Host ""

# Summary
Write-Host "  ╔══════════════════════════════════════════════════════════════════╗" -ForegroundColor Yellow
Write-Host "  ║  Configuration Summary                                           ║" -ForegroundColor Yellow
Write-Host "  ╚══════════════════════════════════════════════════════════════════╝" -ForegroundColor Yellow
Write-Host ""
Write-Host "    Admin User:       $MIOS_USER"
Write-Host "    Password Hash:    $($MIOS_PASSWORD_HASH.Substring(0,20))... (SHA-512)"
Write-Host "    Hostname:         $MIOS_HOSTNAME"
Write-Host "    GitHub User:      $GITHUB_USER (for private repo access)"
Write-Host "    Flatpaks:         $($MIOS_FLATPAKS.Count) apps"
if ($GHCR_USER) {
    Write-Host "    Registry Push:    $GHCR_USER (enabled)"
} else {
    Write-Host "    Registry Push:    Disabled (local build only)"
}
Write-Host "    Config File:      $MiosConfigFile"
Write-Host ""
$confirm = Read-Host "  Proceed with these settings? [Y/n]"
if ($confirm -and $confirm.ToLower() -eq "n") {
    Write-Host "  Aborted by user." -ForegroundColor Yellow
    exit 0
}

# ============================================================================
# Phase 4: Write registry.toml (Single Source of Truth)
# ============================================================================

Write-Host ""
Write-Host "  [4/7] Writing registry.toml (single source of truth)..." -ForegroundColor Yellow

$registryToml = @"
# MiOS Registry - Single Source of Truth for Build Variables
# Generated: $([DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ'))
# XDG-Compliant Path: $MiosConfigFile

[metadata]
version = "0.2.0"
generated_at = "$([DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ'))"
generated_by = "bootstrap-v2.ps1"

[tags.VAR_VERSION]
value = "0.2.0"
subscribers = [
    "VERSION",
    "Justfile:VERSION",
    "Containerfile:org.opencontainers.image.version"
]

[tags.VAR_USER]
value = "$MIOS_USER"
subscribers = [
    "automation/31-user.sh:C_USER",
    "usr/lib/sysusers.d/10-mios.conf"
]

[tags.VAR_HOSTNAME]
value = "$MIOS_HOSTNAME"
subscribers = [
    "automation/32-hostname.sh:MIOS_HOSTNAME",
    "etc/hostname"
]

[tags.VAR_PASSWORD_HASH]
value = "$MIOS_PASSWORD_HASH"
subscribers = [
    "automation/31-user.sh:C_HASH"
]

[tags.VAR_FLATPAKS]
value = "$MIOS_FLATPAKS_STR"
subscribers = [
    "Containerfile:MIOS_FLATPAKS",
    "usr/lib/systemd/system/mios-flatpak-install.service"
]

[tags.IMG_BASE]
value = "ghcr.io/ublue-os/ucore-hci:stable-nvidia"
subscribers = [
    "Containerfile:BASE_IMAGE",
    "Justfile:MIOS_BASE_IMAGE"
]

[tags.IMG_BIB]
value = "quay.io/centos-bootc/bootc-image-builder:latest"
subscribers = [
    "Justfile:BIB_IMAGE"
]
"@

if ($GHCR_USER) {
    $registryToml += @"

[tags.VAR_GHCR_USER]
value = "$GHCR_USER"
subscribers = [
    "Justfile:GHCR_USER"
]
"@
}

$registryToml | Set-Content $MiosConfigFile -Encoding UTF8
Set-SecureACL $MiosConfigFile
Write-Host "  [OK] Saved to: $MiosConfigFile" -ForegroundColor Green
Write-Host ""

# Write secrets to separate file (SHA-512 hashes + tokens)
Write-Host "  [5/7] Writing secrets.env (hashed credentials)..." -ForegroundColor Yellow
$secretsContent = @"
# MiOS Secrets - SHA-512 Hashes and Tokens
# Generated: $([DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ'))
# SECURITY: This file contains hashed passwords and tokens.
#           Permissions are restricted to current user + Administrators.

MIOS_PASSWORD_HASH=$MIOS_PASSWORD_HASH
GITHUB_USER=$GITHUB_USER
GITHUB_TOKEN=$GITHUB_TOKEN
"@

if ($GHCR_TOKEN) {
    $secretsContent += "`nGHCR_TOKEN=$GHCR_TOKEN"
}

$secretsContent | Set-Content $MiosSecretsFile -Encoding UTF8
Set-SecureACL $MiosSecretsFile
Write-Host "  [OK] Saved to: $MiosSecretsFile" -ForegroundColor Green
Write-Host ""

# Write legacy .env file for compatibility
Write-Host "  [6/7] Writing build.env (legacy compatibility)..." -ForegroundColor Yellow
$envContent = @"
# MiOS Build Configuration (Legacy Format)
# Generated: $([DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ'))
# Modern builds should read from registry.toml instead.

MIOS_USER=$MIOS_USER
MIOS_HOSTNAME=$MIOS_HOSTNAME
MIOS_FLATPAKS=$MIOS_FLATPAKS_STR
"@

if ($GHCR_USER) {
    $envContent += "`nGHCR_USER=$GHCR_USER"
}

$envContent | Set-Content $MiosEnvFile -Encoding UTF8
Write-Host "  [OK] Saved to: $MiosEnvFile" -ForegroundColor Green
Write-Host ""

# ============================================================================
# Phase 7: Launch Build
# ============================================================================

Write-Host "  [7/7] Launching MiOS build pipeline..." -ForegroundColor Yellow
Write-Host ""

$env:MIOS_CONFIG_FILE = $MiosConfigFile
$env:MIOS_SECRETS_FILE = $MiosSecretsFile
$env:MIOS_USER = $MIOS_USER
$env:MIOS_HOSTNAME = $MIOS_HOSTNAME
$env:MIOS_PASSWORD_HASH = $MIOS_PASSWORD_HASH
$env:MIOS_FLATPAKS = $MIOS_FLATPAKS_STR
$env:MIOS_AUTOINSTALL = "1"
$env:MIOS_DIR = $MiosRepoDir
$env:MIOS_BUILDS_DIR = $MiosBuildDir
$env:MIOS_LOGS_DIR = $MiosLogsDir

if ($GHCR_USER) {
    $env:GHCR_USER = $GHCR_USER
    $env:GHCR_TOKEN = $GHCR_TOKEN
}

$target = "$env:TEMP\mios-install-$(Get-Random).ps1"

try {
    Write-Host "  Fetching mios-build-local.ps1 from MiOS-bootstrap..." -ForegroundColor Gray
    Invoke-WebRequest -Uri $PublicInstaller -OutFile $target -UseBasicParsing
    Write-Host "  [OK] Build script downloaded" -ForegroundColor Green
    Write-Host ""
    Write-Host "  ════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  Starting MiOS build (estimated time: 15-20 minutes)" -ForegroundColor Cyan
    Write-Host "  ════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host ""

    & $target

} catch {
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════════════════╗" -ForegroundColor Red
    Write-Host "  ║  Build Failed                                                    ║" -ForegroundColor Red
    Write-Host "  ╚══════════════════════════════════════════════════════════════════╝" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Error: $_" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Troubleshooting:" -ForegroundColor Yellow
    Write-Host "    1. Check internet connection" -ForegroundColor Gray
    Write-Host "    2. Verify Podman Desktop is installed" -ForegroundColor Gray
    Write-Host "    3. Review logs at: $MiosLogsDir" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  Manual build:" -ForegroundColor Yellow
    Write-Host "    git clone https://github.com/MiOS-DEV/MiOS-bootstrap.git" -ForegroundColor Gray
    Write-Host "    cd MiOS-bootstrap" -ForegroundColor Gray
    Write-Host "    .\mios-build-local.ps1" -ForegroundColor Gray
    exit 1
} finally {
    Remove-Item $target -ErrorAction SilentlyContinue
}
```

# Layer 2 — System-side installers

---

## install-fhs.sh (mios repo install.sh)

```bash
#!/usr/bin/env bash
# MiOS system-side installer (FHS overlay path).
#
# This script is invoked by the bootstrap installer on non-bootc Fedora hosts.
# On bootc-managed hosts, do NOT run this -- use `bootc switch` instead.
#
# What it does:
#   1. Refuses to run on bootc-managed hosts (their /usr is read-only composefs).
#   2. Lays down the FHS overlay from this repository's working tree to /.
#   3. Runs systemd-sysusers, systemd-tmpfiles, and reloads systemd units.
#   4. Enables MiOS services.

set -euo pipefail

# Refuse to run on bootc-managed hosts.
if command -v bootc >/dev/null 2>&1 && bootc status --format=json 2>/dev/null | grep -q '"booted"'; then
    echo "[FAIL] This host is bootc-managed. install.sh is for non-bootc Fedora hosts." >&2
    echo "       Use 'sudo bootc switch ghcr.io/MiOS-DEV/mios:latest' instead." >&2
    exit 1
fi

if [[ $EUID -ne 0 ]]; then
    echo "[FAIL] install.sh must run as root: sudo $0" >&2
    exit 1
fi

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "[INFO] MiOS system installer running from ${REPO_ROOT}"

if [[ "${REPO_ROOT}" != "/" ]]; then
    # Apply FHS overlay. We rsync each top-level overlay dir if it exists.
    for d in usr etc var srv; do
        if [[ -d "${REPO_ROOT}/${d}" ]]; then
            echo "[INFO] Applying overlay: ${d}/"
            rsync -aH --info=stats1 "${REPO_ROOT}/${d}/" "/${d}/"
        fi
    done

    # v1/ holds discovery symlinks; we materialize them at /v1.
    if [[ -d "${REPO_ROOT}/v1" ]]; then
        echo "[INFO] Materializing /v1 discovery surface"
        install -d /v1
        rsync -aH "${REPO_ROOT}/v1/" "/v1/"
    fi
else
    echo "[INFO] Running directly from root (/), skipping overlay sync."
fi
echo "[INFO] Running systemd-sysusers"
systemd-sysusers

echo "[INFO] Running systemd-tmpfiles"
systemd-tmpfiles --create

echo "[INFO] Reloading systemd"
systemctl daemon-reload

echo "[INFO] Enabling MiOS services"
if [[ -f /etc/containers/systemd/mios-ai.container ]]; then
    systemctl enable --now mios-ai.service || echo "[WARN] mios-ai.service not yet active; will retry on boot"
fi

echo "[ OK ] MiOS system installer complete."
echo "       Log out and back in (or reboot) to pick up profile changes."
```

---

## build-mios.sh

```bash
#!/bin/bash
# MiOS Fedora Server Ignition Script
# Fetches MiOS repository and merges onto Fedora Server root (FHS-compliant, NO deletions)
# Version: 0.2.0
# Usage: curl -fsSL https://raw.githubusercontent.com/MiOS-DEV/MiOS-bootstrap/main/build-mios.sh | sudo bash
#        OR: sudo bash build-mios.sh

set -euo pipefail

# ============================================================================
# Configuration
# ============================================================================
MIOS_REPO_URL="${MIOS_REPO_URL:-https://github.com/MiOS-DEV/MiOS-bootstrap.git}"
MIOS_REPO_BRANCH="${MIOS_REPO_BRANCH:-main}"
MIOS_TMP_DIR="/tmp/mios-ignition-$$"
MIOS_INSTALL_LOG="/var/log/mios-ignition.log"
MIOS_CONFIG_DIR="/etc/mios"
MIOS_USER_CONFIG_DIR="" # Will be set after user is determined

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# ============================================================================
# Logging Functions
# ============================================================================
log() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $*" | tee -a "$MIOS_INSTALL_LOG"
}

log_warn() {
    echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] WARN:${NC} $*" | tee -a "$MIOS_INSTALL_LOG"
}

log_error() {
    echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERROR:${NC} $*" | tee -a "$MIOS_INSTALL_LOG"
}

log_info() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')] INFO:${NC} $*" | tee -a "$MIOS_INSTALL_LOG"
}

# ============================================================================
# Banner
# ============================================================================
show_banner() {
    cat << 'EOF'
â•”â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•—
â•‘                   MiOS Fedora Server Ignition                            â•‘
â•‘                         Version 1.0.0                                    â•‘
â•šâ•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

This script will:
  1. Fetch MiOS repository from GitHub
  2. Prompt for user configuration (username, hostname, etc.)
  3. Queue environment files and dotfiles
  4. Merge MiOS structure onto Fedora Server (FHS-compliant)
  5. NO deletions - only additions and updates
  6. Build MiOS OCI image

EOF
}

# ============================================================================
# User Configuration Prompts
# ============================================================================
collect_user_config() {
    log_info "Collecting user configuration..."
    echo ""

    # Username
    read -p "Enter username (default: mios): " MIOS_USERNAME
    MIOS_USERNAME="${MIOS_USERNAME:-mios}"

    # Password
    while true; do
        read -sp "Enter password for ${MIOS_USERNAME}: " MIOS_PASSWORD
        echo ""
        read -sp "Confirm password: " MIOS_PASSWORD_CONFIRM
        echo ""

        if [[ "$MIOS_PASSWORD" == "$MIOS_PASSWORD_CONFIRM" ]]; then
            # Generate SHA-512 hash
            MIOS_PASSWORD_HASH=$(openssl passwd -6 "${MIOS_PASSWORD}")
            break
        else
            log_error "Passwords do not match. Please try again."
        fi
    done

    # Hostname
    read -p "Enter hostname (default: mios): " MIOS_HOSTNAME
    MIOS_HOSTNAME="${MIOS_HOSTNAME:-mios}"

    # Base image
    echo ""
    echo "Select base image:"
    echo "  1) ghcr.io/ublue-os/ucore-hci:stable-nvidia (NVIDIA GPU, recommended)"
    echo "  2) ghcr.io/ublue-os/ucore-hci:stable (No NVIDIA)"
    echo "  3) ghcr.io/ublue-os/ucore:stable (Minimal)"
    echo "  4) Custom (enter manually)"
    read -p "Choice [1-4] (default: 1): " BASE_IMAGE_CHOICE
    BASE_IMAGE_CHOICE="${BASE_IMAGE_CHOICE:-1}"

    case "$BASE_IMAGE_CHOICE" in
        1) MIOS_BASE_IMAGE="ghcr.io/ublue-os/ucore-hci:stable-nvidia" ;;
        2) MIOS_BASE_IMAGE="ghcr.io/ublue-os/ucore-hci:stable" ;;
        3) MIOS_BASE_IMAGE="ghcr.io/ublue-os/ucore:stable" ;;
        4)
            read -p "Enter custom base image: " MIOS_BASE_IMAGE
            ;;
        *) MIOS_BASE_IMAGE="ghcr.io/ublue-os/ucore-hci:stable-nvidia" ;;
    esac

    # Flatpak apps
    echo ""
    read -p "Enter Flatpak app IDs (comma-separated, optional): " MIOS_FLATPAKS_INPUT
    MIOS_FLATPAKS="${MIOS_FLATPAKS_INPUT}"

    # AI Configuration
    echo ""
    read -p "Configure AI settings? (y/N): " CONFIGURE_AI
    if [[ "$CONFIGURE_AI" =~ ^[Yy]$ ]]; then
        read -p "AI Model (default: llama3.1:8b): " MIOS_AI_MODEL
        MIOS_AI_MODEL="${MIOS_AI_MODEL:-llama3.1:8b}"

        read -p "AI Endpoint (default: http://localhost:8080/v1): " MIOS_AI_ENDPOINT
        MIOS_AI_ENDPOINT="${MIOS_AI_ENDPOINT:-http://localhost:8080/v1}"

        read -sp "AI API Key (optional, press Enter to skip): " MIOS_AI_KEY
        echo ""
    else
        MIOS_AI_MODEL="llama3.1:8b"
        MIOS_AI_ENDPOINT="http://localhost:8080/v1"
        MIOS_AI_KEY=""
    fi

    # Summary
    echo ""
    log_info "Configuration Summary:"
    echo "  Username:     $MIOS_USERNAME"
    echo "  Hostname:     $MIOS_HOSTNAME"
    echo "  Base Image:   $MIOS_BASE_IMAGE"
    echo "  Flatpaks:     ${MIOS_FLATPAKS:-none}"
    echo "  AI Model:     $MIOS_AI_MODEL"
    echo "  AI Endpoint:  $MIOS_AI_ENDPOINT"
    echo ""

    read -p "Proceed with this configuration? (y/N): " CONFIRM
    if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
        log_error "Installation cancelled by user."
        exit 1
    fi
}

# ============================================================================
# Prerequisites Check
# ============================================================================
check_prerequisites() {
    log_info "Checking prerequisites..."

    # Check if running as root
    if [[ $EUID -ne 0 ]]; then
        log_error "This script must be run as root (use sudo)"
        exit 1
    fi

    # Check OS
    if [[ ! -f /etc/fedora-release ]]; then
        log_warn "This script is designed for Fedora Server. Detected OS: $(cat /etc/os-release | grep PRETTY_NAME || echo 'Unknown')"
        read -p "Continue anyway? (y/N): " CONTINUE
        if [[ ! "$CONTINUE" =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi

    # Check internet connection
    if ! curl -fsSL --max-time 5 -o /dev/null https://github.com/; then
        log_error "No internet connection. Please check your network."
        exit 1
    fi

    log "Prerequisites check passed"
}

# ============================================================================
# Install Dependencies
# ============================================================================
install_dependencies() {
    log_info "Installing required dependencies..."

    dnf install -y \
        git \
        podman \
        buildah \
        rsync \
        python3 \
        systemd \
        coreutils \
        util-linux \
        || { log_error "Failed to install dependencies"; exit 1; }

    # Optional: Install just
    if ! command -v just &>/dev/null; then
        log_info "Installing 'just' command runner..."
        if command -v cargo &>/dev/null; then
            cargo install just || log_warn "'just' installation failed, continuing without it"
        else
            log_warn "'just' not installed (cargo not available). You can use podman directly."
        fi
    fi

    log "Dependencies installed successfully"
}

# ============================================================================
# Fetch MiOS Repository
# ============================================================================
fetch_mios_repo() {
    log_info "Fetching MiOS repository from ${MIOS_REPO_URL}..."

    # Create temporary directory
    mkdir -p "$MIOS_TMP_DIR"
    cd "$MIOS_TMP_DIR"

    # Clone repository
    git clone --depth 1 --branch "$MIOS_REPO_BRANCH" "$MIOS_REPO_URL" mios \
        || { log_error "Failed to clone MiOS repository"; exit 1; }

    cd mios

    log "MiOS repository fetched successfully"
}

# ============================================================================
# Queue Environment Files
# ============================================================================
queue_environment_files() {
    log_info "Queuing environment files and dotfiles..."

    # Determine user home directory
    if [[ "$MIOS_USERNAME" == "root" ]]; then
        MIOS_USER_HOME="/root"
    else
        MIOS_USER_HOME="/home/${MIOS_USERNAME}"
    fi

    MIOS_USER_CONFIG_DIR="${MIOS_USER_HOME}/.config/mios"

    # Create user configuration directory structure
    mkdir -p "$MIOS_USER_CONFIG_DIR"

    # Create env.toml
    cat > "$MIOS_USER_CONFIG_DIR/env.toml" <<EOF
# MiOS User Environment Configuration
# Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)

[mios]
user = "${MIOS_USERNAME}"
hostname = "${MIOS_HOSTNAME}"

[ai]
model = "${MIOS_AI_MODEL}"
endpoint = "${MIOS_AI_ENDPOINT}"
temperature = 0.7
EOF

    # Create images.toml
    cat > "$MIOS_USER_CONFIG_DIR/images.toml" <<EOF
# MiOS Image Configuration

[base]
image = "${MIOS_BASE_IMAGE}"

[builder]
image = "quay.io/centos-bootc/bootc-image-builder:latest"

[output]
name = "localhost/mios"
tag = "latest"
EOF

    # Create build.toml
    cat > "$MIOS_USER_CONFIG_DIR/build.toml" <<EOF
# MiOS Build Configuration

[build]
no_cache = true
progress = "tty"

[flatpaks]
source_file = "${MIOS_USER_CONFIG_DIR}/flatpaks.list"
EOF

    # Create flatpaks.list
    if [[ -n "$MIOS_FLATPAKS" ]]; then
        echo "$MIOS_FLATPAKS" | tr ',' '\n' > "$MIOS_USER_CONFIG_DIR/flatpaks.list"
    else
        touch "$MIOS_USER_CONFIG_DIR/flatpaks.list"
    fi

    # Create ai.env (secrets - not committed)
    if [[ -n "$MIOS_AI_KEY" ]]; then
        cat > "$MIOS_USER_CONFIG_DIR/ai.env" <<EOF
# MiOS AI Configuration (SECRETS - DO NOT COMMIT)
MIOS_AI_KEY="${MIOS_AI_KEY}"
EOF
        chmod 600 "$MIOS_USER_CONFIG_DIR/ai.env"
    fi

    # Create system-wide runtime.env
    mkdir -p "$MIOS_CONFIG_DIR"
    cat > "$MIOS_CONFIG_DIR/runtime.env" <<EOF
# MiOS Runtime Environment
# Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)

MIOS_AI_ENDPOINT="${MIOS_AI_ENDPOINT}"
MIOS_AI_MODEL="${MIOS_AI_MODEL}"
MIOS_HOSTNAME="${MIOS_HOSTNAME}"
EOF

    log "Environment files queued successfully"
}

# ============================================================================
# Merge MiOS Structure (FHS-Compliant, NO Deletions)
# ============================================================================
merge_mios_structure() {
    log_info "Merging MiOS structure onto Fedora Server root (FHS-compliant)..."

    cd "$MIOS_TMP_DIR/mios"

    # Merge directories with rsync (--ignore-existing = NO overwrites)
    # This ensures existing Fedora files are PRESERVED

    # 1. Merge /usr (system binaries, libraries, data)
    log_info "Merging /usr..."
    rsync -av --ignore-existing usr/ /usr/ \
        || log_warn "Some files in /usr were skipped (already exist)"

    # 2. Merge /etc (configuration templates)
    log_info "Merging /etc..."
    rsync -av --ignore-existing etc/ /etc/ \
        || log_warn "Some files in /etc were skipped (already exist)"

    # 3. Declare /var directories via tmpfiles.d (NO direct mkdir)
    log_info "Declaring /var directories via tmpfiles.d..."
    if [[ -f usr/lib/tmpfiles.d/mios.conf ]]; then
        cp -n usr/lib/tmpfiles.d/mios.conf /usr/lib/tmpfiles.d/ || true
        systemd-tmpfiles --create /usr/lib/tmpfiles.d/mios.conf || log_warn "tmpfiles creation had warnings"
    fi

    # 4. Merge /home skeleton
    log_info "Merging /home skeleton..."
    if [[ -d home/mios ]]; then
        mkdir -p /etc/skel/.config/mios
        rsync -av --ignore-existing home/mios/ /etc/skel/ || true
    fi

    # 5. Copy tools and automation (for building)
    log_info "Installing tools and automation..."
    rsync -av tools/ /usr/share/mios/tools/ || true
    rsync -av automation/ /usr/share/mios/automation/ || true

    # 6. Make all scripts executable
    log_info "Setting executable permissions..."
    chmod +x /usr/bin/mios* /usr/bin/iommu-groups 2>/dev/null || true
    chmod +x /usr/libexec/mios* 2>/dev/null || true
    chmod +x /usr/libexec/mios/* 2>/dev/null || true
    chmod +x /usr/share/mios/tools/*.sh 2>/dev/null || true
    chmod +x /usr/share/mios/automation/*.sh 2>/dev/null || true

    # 7. Copy Containerfile and Justfile to /usr/share/mios for building
    log_info "Installing build files..."
    cp -n Containerfile /usr/share/mios/ || true
    cp -n Justfile /usr/share/mios/ || true
    cp -n VERSION /usr/share/mios/ || true

    # 8. Create /usr/src/mios symlink (for mios rebuild command)
    log_info "Creating source symlink..."
    ln -sf /usr/share/mios /usr/src/mios || true

    log "MiOS structure merged successfully (NO deletions)"
}

# ============================================================================
# Create User Account & Initialize User-Space
# ============================================================================
create_user_account() {
    log_info "Creating user account: ${MIOS_USERNAME}..."

    if id "$MIOS_USERNAME" &>/dev/null; then
        log_warn "User ${MIOS_USERNAME} already exists, updating password..."
        echo "${MIOS_USERNAME}:${MIOS_PASSWORD}" | chpasswd
    else
        # Create user with password hash
        EXTRA_GROUPS="wheel,libvirt,kvm,video,render,input,dialout"
        if getent group docker >/dev/null 2>&1; then EXTRA_GROUPS="$EXTRA_GROUPS,docker"; fi
        useradd -m -G "$EXTRA_GROUPS" -s /bin/bash "$MIOS_USERNAME"
        echo "${MIOS_USERNAME}:${MIOS_PASSWORD}" | chpasswd

        # Set up sudo access
        echo "${MIOS_USERNAME} ALL=(ALL) NOPASSWD:ALL" > "/etc/sudoers.d/${MIOS_USERNAME}"
        chmod 0440 "/etc/sudoers.d/${MIOS_USERNAME}"
    fi

    log_info "Initializing user-space directories and configuration..."

    # XDG Base Directory variables
    MIOS_USER_DATA_DIR="${MIOS_USER_HOME}/.local/share/mios"
    MIOS_USER_CACHE_DIR="${MIOS_USER_HOME}/.cache/mios"
    MIOS_USER_STATE_DIR="${MIOS_USER_HOME}/.local/state/mios"

    # Create XDG directory structure
    mkdir -p "${MIOS_USER_CONFIG_DIR}/credentials/ssh-keys"
    mkdir -p "${MIOS_USER_DATA_DIR}/artifacts"
    mkdir -p "${MIOS_USER_DATA_DIR}/images"
    mkdir -p "${MIOS_USER_DATA_DIR}/templates"
    mkdir -p "${MIOS_USER_DATA_DIR}/plugins"
    mkdir -p "${MIOS_USER_CACHE_DIR}/podman"
    mkdir -p "${MIOS_USER_CACHE_DIR}/downloads"
    mkdir -p "${MIOS_USER_CACHE_DIR}/build-cache"
    mkdir -p "${MIOS_USER_STATE_DIR}/logs"

    # Setup dotfiles directory for build-time injection
    mkdir -p "${MIOS_USER_CONFIG_DIR}/dotfiles"
    if [[ ! -f "${MIOS_USER_CONFIG_DIR}/dotfiles/.bashrc.user" ]]; then
        cat > "${MIOS_USER_CONFIG_DIR}/dotfiles/.bashrc.user" <<'DOTFILE_EOF'
# MiOS User-Space .bashrc extension
# This file is injected into the image during build-time.
alias ll='ls -alF'
alias mios-status='mios assess'
export EDITOR=vim
DOTFILE_EOF
    fi

    # Create credentials .gitignore
    cat > "${MIOS_USER_CONFIG_DIR}/credentials/.gitignore" <<'GITIGNORE_EOF'
# MiOS Credentials - Ignore Everything
# This directory should NEVER be committed to version control

*
!.gitignore
!README.md
GITIGNORE_EOF

    # Initialize Python virtual environment
    if command -v python3 &>/dev/null; then
        if [[ ! -d "${MIOS_USER_DATA_DIR}/venv" ]]; then
            python3 -m venv "${MIOS_USER_DATA_DIR}/venv" 2>/dev/null || log_warn "Failed to create Python venv"
        fi
    fi

    # Copy environment files to user's home and fix ownership
    chown -R "${MIOS_USERNAME}:${MIOS_USERNAME}" "${MIOS_USER_HOME}/.config" 2>/dev/null || true
    chown -R "${MIOS_USERNAME}:${MIOS_USERNAME}" "${MIOS_USER_HOME}/.local" 2>/dev/null || true
    chown -R "${MIOS_USERNAME}:${MIOS_USERNAME}" "${MIOS_USER_HOME}/.cache" 2>/dev/null || true

    log "User account and user-space configured successfully"
}

# ============================================================================
# Set Hostname
# ============================================================================
set_hostname() {
    log_info "Setting hostname to: ${MIOS_HOSTNAME}..."

    hostnamectl set-hostname "$MIOS_HOSTNAME"

    log "Hostname set successfully"
}

# ============================================================================
# Build MiOS Image (Optional)
# ============================================================================
build_mios_image() {
    log_info "Would you like to build the MiOS OCI image now?"
    echo "  This will take 15-25 minutes on first build."
    echo "  You can also build later with: cd /usr/share/mios && just build"
    echo ""
    read -p "Build now? (y/N): " BUILD_NOW

    if [[ "$BUILD_NOW" =~ ^[Yy]$ ]]; then
        log_info "Building MiOS OCI image..."

        cd /usr/share/mios

        # Load user environment
        export MIOS_BASE_IMAGE
        export MIOS_FLATPAKS
        export MIOS_USER="${MIOS_USERNAME}"
        export MIOS_PASSWORD_HASH
        export MIOS_HOSTNAME

        if command -v just &>/dev/null; then
            just build || { log_error "Build failed"; return 1; }
        else
            # Fallback to direct podman build
            podman build --no-cache \
                --build-arg BASE_IMAGE="$MIOS_BASE_IMAGE" \
                --build-arg MIOS_USER="$MIOS_USERNAME" \
                --build-arg MIOS_PASSWORD_HASH="$MIOS_PASSWORD_HASH" \
                --build-arg MIOS_HOSTNAME="$MIOS_HOSTNAME" \
                --build-arg MIOS_FLATPAKS="$MIOS_FLATPAKS" \
                -t localhost/mios:latest . \
                || { log_error "Build failed"; return 1; }
        fi

        log "MiOS OCI image built successfully: localhost/mios:latest"

        # Ask about deployment
        echo ""
        read -p "Deploy to this system now? (y/N): " DEPLOY_NOW
        if [[ "$DEPLOY_NOW" =~ ^[Yy]$ ]]; then
            log_info "Deploying MiOS to this system..."
            bootc install to-existing-root --source-imgref localhost/mios:latest \
                || log_warn "Deployment failed or not supported on this system"
        fi
    else
        log_info "Skipping build. To build later, run:"
        echo "  cd /usr/share/mios && just build"
    fi
}

# ============================================================================
# Cleanup
# ============================================================================
cleanup() {
    log_info "Cleaning up temporary files..."

    if [[ -d "$MIOS_TMP_DIR" ]]; then
        rm -rf "$MIOS_TMP_DIR"
    fi

    log "Cleanup complete"
}

# ============================================================================
# Final Summary
# ============================================================================
show_summary() {
    cat << EOF

â•”â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•—
â•‘                   MiOS Installation Complete!                            â•‘
â•šâ•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

Configuration:
  Username:     ${MIOS_USERNAME}
  Hostname:     ${MIOS_HOSTNAME}
  Config Dir:   ${MIOS_USER_CONFIG_DIR}

Installation Details:
  âœ“ MiOS structure merged to system root (FHS-compliant)
  âœ“ User account created with full permissions
  âœ“ User-space initialized (XDG directories, configs, dotfiles)
  âœ“ Python virtual environment created
  âœ“ System configuration installed
  âœ“ Build files installed to /usr/share/mios

Next Steps:

  1. Switch to your user:
     su - ${MIOS_USERNAME}

  2. Build MiOS image (if not done):
     cd /usr/share/mios && just build

  3. Check system status:
     mios status

  4. View available commands:
     mios --help

  5. Customize your configuration:
     \$EDITOR ~/.config/mios/env.toml

Documentation:
  - Installation log: ${MIOS_INSTALL_LOG}
  - Configuration: ${MIOS_USER_CONFIG_DIR}
  - System config: ${MIOS_CONFIG_DIR}

For more information:
  https://github.com/MiOS-DEV/MiOS-bootstrap

EOF
}

# ============================================================================
# Main Execution
# ============================================================================
main() {
    # Initialize log
    mkdir -p "$(dirname "$MIOS_INSTALL_LOG")"
    touch "$MIOS_INSTALL_LOG"

    show_banner

    check_prerequisites
    collect_user_config
    install_dependencies
    fetch_mios_repo
    queue_environment_files
    merge_mios_structure
    create_user_account
    set_hostname
    build_mios_image
    cleanup
    show_summary

    log "MiOS Fedora Server ignition completed successfully!"
}

# Trap errors
trap 'log_error "Installation failed at line $LINENO. Check $MIOS_INSTALL_LOG for details."' ERR

# Run main
main "$@"
```

# Layer 3 — Image build orchestrators

---

## Containerfile

```dockerfile
# syntax=docker/dockerfile:1.9
# ============================================================================
# MiOS - Unified Image (v0.2.0)
# ============================================================================
# One image. Every role. Every surface. Every GPU vendor.
#
# Base:     Controlled by MIOS_BASE_IMAGE in .env.mios
#           Default: ghcr.io/ublue-os/ucore-hci:stable-nvidia
# ============================================================================

ARG BASE_IMAGE=ghcr.io/ublue-os/ucore-hci:stable-nvidia # @track:IMG_BASE

# ----------------------------------------------------------------------------
# ctx stage: build context
# ----------------------------------------------------------------------------
FROM scratch AS ctx
COPY automation/           /ctx/automation/
COPY usr/                  /ctx/usr/
COPY etc/                  /ctx/etc/
COPY home/                 /ctx/home/
COPY usr/share/mios/PACKAGES.md                          /ctx/PACKAGES.md
COPY VERSION            /ctx/VERSION
COPY config/artifacts/       /ctx/bib-configs/
COPY tools/             /ctx/tools/

# ----------------------------------------------------------------------------
# main stage
# ----------------------------------------------------------------------------
FROM ${BASE_IMAGE}

LABEL org.opencontainers.image.title="MiOS"
LABEL org.opencontainers.image.description="Unified immutable cloud-native workstation OS"
LABEL org.opencontainers.image.source="https://github.com/MiOS-DEV/MiOS-bootstrap"
LABEL org.opencontainers.image.licenses="Apache-2.0"
LABEL org.opencontainers.image.version="v0.2.0"
LABEL containers.bootc="1"
LABEL ostree.bootable="1"

CMD ["/sbin/init"]

ARG MIOS_USER=mios
ARG MIOS_HOSTNAME=mios
ARG MIOS_FLATPAKS=

# Build context mounted read-only
COPY --from=ctx /ctx /ctx

# Unified Build Pipeline: Install -> Overlay -> Automation -> Cleanup
RUN --mount=type=cache,dst=/var/cache/libdnf5,sharing=locked     --mount=type=cache,dst=/var/cache/dnf,sharing=locked         set -e;     # 1. Install essential security packages     dnf install -y --skip-unavailable --setopt=install_weak_deps=False         policycoreutils-python-utils         selinux-policy-targeted         firewalld         audit         fapolicyd         crowdsec         usbguard         kernel-devel;     # 2. Inject flatpaks if provided     if [[ -n "${MIOS_FLATPAKS}" ]]; then         echo "${MIOS_FLATPAKS}" | tr "," "\n" > /ctx/usr/share/mios/flatpak-list;     fi;     # 3. Rootfs Overlay     bash /ctx/automation/08-system-files-overlay.sh;     # 4. Numbered Pipeline     chmod +x /ctx/automation/build.sh /ctx/automation/*.sh 2>/dev/null || true;     chmod +x /usr/libexec/mios/copy-build-log.sh;     /ctx/automation/build.sh;     # 5. Mandatory Cleanup for bootc lint     dnf clean all;     find /var -mindepth 1 -maxdepth 1 ! -name tmp -exec rm -rf {} +;     find /run -mindepth 1 -maxdepth 1 ! -name "secrets" -exec rm -rf {} + 2>/dev/null || true

# Install bootc bash completions
RUN bootc completion bash > /etc/bash_completion.d/bootc

# -- systemd-sysext consolidation ----------
RUN mkdir -p /usr/lib/extensions/source  && chmod +x /ctx/tools/mios-sysext-pack.sh  && /ctx/tools/mios-sysext-pack.sh /usr/lib/extensions/source || true

RUN rm -rf /ctx  && ostree container commit
RUN bootc container lint
```

---

## Justfile

```makefile
# MiOS v0.2.0 - Linux Build Targets
# Requires: podman, just
# Usage: just build | just iso | just all

# Load user environment from XDG-compliant configuration
# This sources $HOME/.config/mios/*.toml files and exports MIOS_* variables
_load_env := `bash -c 'source ./tools/load-user-env.sh 2>/dev/null || true'`

MIOS_REGISTRY_DEFAULT := "ghcr.io/MiOS-DEV/mios" # @verb:GET_REGISTRY
IMAGE_NAME := env_var_or_default("MIOS_IMAGE_NAME", MIOS_REGISTRY_DEFAULT) # @verb:GET_IMAGE
MIOS_VAR_VERSION := "v0.2.0" # @verb:GET_VERSION
VERSION := `cat VERSION 2>/dev/null || echo {{MIOS_VAR_VERSION}}`
LOCAL := env_var_or_default("MIOS_LOCAL_TAG", "localhost/mios:latest") # @verb:SET_LOCAL
MIOS_IMG_BIB := "quay.io/centos-bootc/bootc-image-builder:latest" # @verb:GET_BIB
BIB := env_var_or_default("MIOS_BIB_IMAGE", MIOS_IMG_BIB)

# Run preflight system check
preflight:
    @chmod +x tools/preflight.sh
    @./tools/preflight.sh

# Show current flight status and variable mappings
flight-status:
    @chmod +x tools/flight-control.sh
    @./tools/flight-control.sh

# Unified initialization (Mode 2: User-space)
init:
    @chmod +x tools/mios-overlay.sh
    sudo ./tools/mios-overlay.sh

# System-wide deployment (Mode 1: FHS system install)
deploy:
    @chmod +x tools/mios-overlay.sh
    sudo ./tools/mios-overlay.sh

# Live ISO Initiation (Mode 0: Overlay onto root)
live-init:
    @chmod +x tools/mios-overlay.sh
    sudo ./tools/mios-overlay.sh

# Build OCI image locally
build: artifact preflight flight-status
    podman build --no-cache \
        --build-arg BASE_IMAGE={{env_var_or_default("MIOS_BASE_IMAGE", "ghcr.io/ublue-os/ucore-hci:stable-nvidia")}} \
        --build-arg MIOS_FLATPAKS={{env_var_or_default("MIOS_FLATPAKS", "")}} \
        -t {{LOCAL}} .
    @echo "[OK] Built: {{LOCAL}}"

# Build OCI image with unified logging
build-logged: artifact
    @mkdir -p logs
    @LOG_FILE="logs/build-$(date -u +%Y%m%dT%H%M%SZ).log"
    @echo "---" | tee -a "${LOG_FILE}"
    @echo "[START] CHECKPOINT: Starting MiOS build..." | tee -a "${LOG_FILE}"
    @echo "Unified log will be available at: ${LOG_FILE}" | tee -a "${LOG_FILE}"
    @echo "---" | tee -a "${LOG_FILE}"
    @set -o pipefail; podman build --no-cache \
        --build-arg BASE_IMAGE={{env_var_or_default("MIOS_BASE_IMAGE", "ghcr.io/ublue-os/ucore-hci:stable-nvidia")}} \
        --build-arg MIOS_FLATPAKS={{env_var_or_default("MIOS_FLATPAKS", "")}} \
        -t {{LOCAL}} . 2>&1 | tee -a "${LOG_FILE}"
    @echo "---" | tee -a "${LOG_FILE}"
    @echo "[OK] CHECKPOINT: MiOS build complete." | tee -a "${LOG_FILE}"
    @echo "Unified log available at: ${LOG_FILE}" | tee -a "${LOG_FILE}"
    @echo "---"

# Build OCI image with verbose output (no redirection)
build-verbose: artifact
    podman build --no-cache \
        --build-arg BASE_IMAGE={{env_var_or_default("MIOS_BASE_IMAGE", "ghcr.io/ublue-os/ucore-hci:stable-nvidia")}} \
        --build-arg MIOS_FLATPAKS={{env_var_or_default("MIOS_FLATPAKS", "")}} \
        -t {{LOCAL}} .

# Embed the most recent build log into the image
embed-log:
    @echo "[START] Finding most recent build log..."
    @LOG_FILE=$$(ls -t logs/build-*.log 2>/dev/null | head -n 1)
    @if [ -z "$${LOG_FILE}" ]; then \
        echo "[FAIL] No build logs found in logs/. Run 'just build-logged' first."; \
        exit 1; \
    fi
    @echo "  Found: $${LOG_FILE}"
    @echo "[START] Creating temporary Containerfile to embed log..."
    @echo "FROM {{LOCAL}}" > /tmp/Containerfile.embed
    @echo "COPY --chown=root:root $${LOG_FILE} /usr/share/mios/build-logs/latest-build.log" >> /tmp/Containerfile.embed
    @echo "[START] Building image with embedded log..."
    @set -o pipefail; podman build --no-cache -f /tmp/Containerfile.embed -t localhost/mios:latest-with-log .
    @rm /tmp/Containerfile.embed
    @echo "---"
    @echo "[OK] Success! New image created: localhost/mios:latest-with-log"
    @echo "   Embedded log is at: /usr/share/mios/build-logs/latest-build.log"
    @echo "---"

# Refresh all AI manifests, UKB, and Wiki documentation
artifact:
    ./automation/ai-bootstrap.sh
    @echo "[OK] Artifacts, UKB, and Wiki refreshed."

# Build OCI image on Cloud (using remote context)
cloud-build:
    @echo "Configure cloud-build with your cloud provider CLI"
    @echo "Example: podman build --remote -t {{IMAGE_NAME}}:{{VERSION}} ."
    @echo "[OK] Cloud Build target (customize for your cloud provider)"

# Rechunk for optimal Day-2 updates (5-10x smaller deltas)
rechunk: build
    podman run --rm \
        --security-opt label=type:unconfined_t \
        -v /var/lib/containers/storage:/var/lib/containers/storage \
        {{LOCAL}} \
        /usr/libexec/bootc-base-imagectl rechunk --max-layers 67 containers-storage:{{LOCAL}} containers-storage:{{IMAGE_NAME}}:{{VERSION}}
    podman tag {{IMAGE_NAME}}:{{VERSION}} {{IMAGE_NAME}}:latest
    @echo "[OK] Rechunked: {{IMAGE_NAME}}:{{VERSION}}"

# Generate RAW bootable disk image (80 GiB root)
raw: build
    mkdir -p output
    sudo podman run --rm -it --privileged \
        --security-opt label=type:unconfined_t \
        -v ./output:/output \
        -v /var/lib/containers/storage:/var/lib/containers/storage \
        -v ./config/artifacts/bib.toml:/config.toml:ro \
        {{BIB}} build --type raw --rootfs ext4 {{LOCAL}}
    @echo "[OK] RAW image in output/"

# Generate Anaconda installer ISO
# FIX v0.2.0: ONLY mount iso.toml (includes minsize). Do NOT also mount bib config.
# BIB crashes with: "found config.json and also config.toml"
iso: build
    mkdir -p output
    sudo podman run --rm -it --privileged \
        --security-opt label=type:unconfined_t \
        -v ./output:/output \
        -v /var/lib/containers/storage:/var/lib/containers/storage \
        -v ./config/artifacts/iso.toml:/config.toml:ro \
        {{BIB}} build --type iso --rootfs ext4 {{LOCAL}}
    @echo "[OK] ISO image in output/"

# Log artifacts to MiOS-bootstrap repository (Linux FS native)
log-bootstrap:
    @echo "[START] Logging artifacts to MiOS-bootstrap repository (Linux FS native)..."
    ./tools/log-to-bootstrap.sh
    @echo "[OK] Artifacts logged to bootstrap repository"

# Complete build with bootstrap logging (recommended for releases)
build-and-log: build-logged
    @echo "[START] Running bootstrap artifact logging (Linux FS native)..."
    ./tools/log-to-bootstrap.sh
    @echo "[OK] Build complete with artifacts logged to bootstrap"

# Full pipeline: build  rechunk  log to bootstrap (Linux FS native)
all-bootstrap: build rechunk log-bootstrap
    @echo "[OK] Full pipeline complete (build  rechunk  bootstrap Linux FS native)"

# Generate SBOM for the local image
sbom:
    @echo "[START] Generating SBOM for {{LOCAL}}..."
    @mkdir -p artifacts/sbom
    podman run --rm \
        -v ./artifacts/sbom:/out \
        -v /var/lib/containers/storage:/var/lib/containers/storage \
        anchore/syft:latest scan {{LOCAL}} -o cyclonedx-json > artifacts/sbom/mios-sbom.json
    @echo "[OK] SBOM generated: artifacts/sbom/mios-sbom.json"

# ============================================================================
# User-Space Management
# ============================================================================

# Initialize user-space configuration (XDG Base Directory structure)
init-user-space:
    @echo "[ENG]  Initializing MiOS user-space..."
    ./tools/init-user-space.sh
    @echo "[OK] User-space initialization complete"

# Re-initialize user-space (overwrite existing configs)
reinit-user-space:
    @echo "[SYNC] Re-initializing MiOS user-space (overwriting existing configs)..."
    ./tools/init-user-space.sh --force
    @echo "[OK] User-space re-initialization complete"

# Show user-space configuration paths
show-user-space:
    @echo "MiOS User-Space Directories:"
    @echo "  Config:  ${XDG_CONFIG_HOME:-$HOME/.config}/mios/"
    @echo "  Data:    ${XDG_DATA_HOME:-$HOME/.local/share}/mios/"
    @echo "  Cache:   ${XDG_CACHE_HOME:-$HOME/.cache}/mios/"
    @echo "  State:   ${XDG_STATE_HOME:-$HOME/.local/state}/mios/"
    @echo "  Runtime: ${XDG_RUNTIME_DIR:-/run/user/$(id -u)}/mios/"
    @echo ""
    @echo "Configuration files:"
    @if [ -f "${XDG_CONFIG_HOME:-$HOME/.config}/mios/env.toml" ]; then \
        echo "  [OK] env.toml"; \
    else \
        echo "  [FAIL] env.toml (not found - run: just init-user-space)"; \
    fi
    @if [ -f "${XDG_CONFIG_HOME:-$HOME/.config}/mios/images.toml" ]; then \
        echo "  [OK] images.toml"; \
    else \
        echo "  [FAIL] images.toml (not found - run: just init-user-space)"; \
    fi
    @if [ -f "${XDG_CONFIG_HOME:-$HOME/.config}/mios/build.toml" ]; then \
        echo "  [OK] build.toml"; \
    else \
        echo "  [FAIL] build.toml (not found - run: just init-user-space)"; \
    fi

# Show loaded environment variables
show-env:
    @echo "MiOS Environment Variables:"
    @source ./tools/load-user-env.sh && env | grep '^MIOS_' | sort | sed 's/^/  /'

# Edit user environment configuration
edit-env:
    @if [ ! -f "${XDG_CONFIG_HOME:-$HOME/.config}/mios/env.toml" ]; then \
        echo "[FAIL] User config not found. Run: just init-user-space"; \
        exit 1; \
    fi
    @${EDITOR:-vim} "${XDG_CONFIG_HOME:-$HOME/.config}/mios/env.toml"

# Edit user image configuration
edit-images:
    @if [ ! -f "${XDG_CONFIG_HOME:-$HOME/.config}/mios/images.toml" ]; then \
        echo "[FAIL] User config not found. Run: just init-user-space"; \
        exit 1; \
    fi
    @${EDITOR:-vim} "${XDG_CONFIG_HOME:-$HOME/.config}/mios/images.toml"

# Edit user build configuration
edit-build:
    @if [ ! -f "${XDG_CONFIG_HOME:-$HOME/.config}/mios/build.toml" ]; then \
        echo "[FAIL] User config not found. Run: just init-user-space"; \
        exit 1; \
    fi
    @${EDITOR:-vim} "${XDG_CONFIG_HOME:-$HOME/.config}/mios/build.toml"

# Edit Flatpak applications list
edit-flatpaks:
    @if [ ! -f "${XDG_CONFIG_HOME:-$HOME/.config}/mios/flatpaks.list" ]; then \
        echo "[FAIL] User config not found. Run: just init-user-space"; \
        exit 1; \
    fi
    @${EDITOR:-vim} "${XDG_CONFIG_HOME:-$HOME/.config}/mios/flatpaks.list"
```

---

## mios-build-local.ps1

```powershell
<#
.SYNOPSIS
    MiOS v0.2.0 - MiOS Builder (Windows)

.DESCRIPTION
    Secure build orchestrator with workflow selection.
    Tokens/passwords NEVER appear in plain text in logs or terminal output.

    SECURITY FIXES in v0.2.0:
      - Passwords pre-hashed (SHA-512) before injection - plaintext never in build log
      - Registry token uses SecureString - never echoed, never in process args
      - Workflow menu: Local Build, Push Build, Custom Build
      - Admin/origin-owner detection for default token inference
      - Hostname randomization option for HA clusters

    SELF-BUILDING in v0.2.0:
      - Pulls existing MiOS image from GHCR as the helper/builder image
      - MiOS image replaces alpine/python for all helper operations
      - Falls back to alpine/python only on first-ever build (no prior image)
      - MAKEFLAGS passed into build for parallel compilation (akmod, Looking Glass)
      - MiOS image IS the builder - podman, buildah, bootc, BIB all baked in
#>

$ErrorActionPreference = "Stop"

# ==============================================================================
#  UI HELPERS & MASKING ENGINE
# ==============================================================================
$BuildAudit = @()
$Global:MiOS_MaskList = @()

function Register-Secret {
    param([string]$S)
    if ([string]::IsNullOrWhiteSpace($S) -or $S.Length -lt 4) { return }
    if ($Global:MiOS_MaskList -notcontains $S) {
        $Global:MiOS_MaskList += $S
    }
}

function Format-Masked {
    param([string]$InputString)
    if ([string]::IsNullOrWhiteSpace($InputString)) { return $InputString }
    $out = $InputString
    foreach ($secret in $Global:MiOS_MaskList) {
        # Escape for regex and replace case-insensitively
        $pattern = [regex]::Escape($secret)
        $out = $out -ireplace $pattern, "********"
    }
    return $out
}

function Write-Banner { 
    param([string]$T) 
    $w=78; 
    $maskedT = Format-Masked $T
    Write-Host "`n$("="*$w)" -ForegroundColor Cyan; 
    Write-Host ("  $maskedT") -ForegroundColor Cyan; 
    Write-Host "$("="*$w)`n" -ForegroundColor Cyan 
}

function Write-Phase { 
    param([string]$N,[string]$L) 
    $maskedL = Format-Masked $L
    Write-Host "`n  [$N] $maskedL" -ForegroundColor Yellow; 
    Write-Host "  $("-"*70)" -ForegroundColor DarkGray 
    $script:BuildAudit += "PHASE ${N}: ${maskedL}"
    try {
        $percent = [int]($N) * 20
        Write-Progress -Activity "MiOS Build ${Version}" -Status "Phase ${N}: ${maskedL}" -PercentComplete $percent
    } catch {}
}

function Write-Step  { 
    param([string]$M) 
    $maskedM = Format-Masked $M
    Write-Host "       $maskedM" -ForegroundColor DarkCyan 
}

function Write-OK { 
    param([string]$M) 
    $maskedM = Format-Masked $M
    Write-Host "      [OK] $maskedM" -ForegroundColor Green; 
    $script:BuildAudit += "  [OK] $maskedM" 
}

function Write-Warn { 
    param([string]$M) 
    $maskedM = Format-Masked $M
    Write-Host "       $maskedM" -ForegroundColor Yellow; 
    $script:BuildAudit += "  [WARN] $maskedM" 
}

function Write-Fatal { 
    param([string]$M) 
    $maskedM = Format-Masked $M
    Write-Host "`n  [FAIL] FATAL: $maskedM" -ForegroundColor Red; 
    $script:BuildAudit += "  [FAIL] $maskedM"; 
    Show-StatusCard; 
    exit 1 
}

function Show-StatusCard {
    $w = 78
    Write-Host "`n+$($("="*($w-2)))+" -ForegroundColor Cyan
    Write-Host "|$($(" "*[math]::Floor(($w-18)/2)))MiOS BUILD SUMMARY$($(" "*[math]::Ceiling(($w-18)/2)))|" -ForegroundColor Cyan
    Write-Host "+$($("="*($w-2)))+" -ForegroundColor Cyan
    Write-Host "  Version:  $Version"
    Write-Host "  Status:   $([DateTime]::UtcNow.ToString('yyyy-MM-dd HH:mm:ss')) UTC"
    Write-Host "  Audit Log:"
    foreach ($line in $script:BuildAudit) {
        # Audit log entries are already masked during collection, but double-check here
        $maskedLine = Format-Masked $line
        if ($maskedLine -match "FAIL") { Write-Host "    $maskedLine" -ForegroundColor Red }
        elseif ($maskedLine -match "WARN") { Write-Host "    $maskedLine" -ForegroundColor Yellow }
        elseif ($maskedLine -match "PHASE") { Write-Host "    $maskedLine" -ForegroundColor Cyan }
        else { Write-Host "    $maskedLine" -ForegroundColor Gray }
    }
    Write-Host "+$($("="*($w-2)))+`n" -ForegroundColor Cyan
}

# -- Register initial secrets from environment (if present) --
@("MIOS_PASSWORD", "GHCR_TOKEN", "MIOS_GHCR_PUSH_TOKEN", "MIOS_PASSWORD_HASH") | ForEach-Object {
    if ($env:$_) { Register-Secret $env:$_ }
}

function Get-FileSize { param([string]$P) if(!(Test-Path $P)){return "N/A"} $s=(Get-Item $P).Length; if($s -gt 1GB){"$([math]::Round($s/1GB,2)) GB"}else{"$([math]::Round($s/1MB,2)) MB"} }

function Read-Timed {
    param([string]$Prompt, [string]$Default, [switch]$Secret)
    if ($Secret) {
        Write-Host "      $Prompt " -NoNewline -ForegroundColor DarkCyan
        Write-Host "[$(if($Default){'********'}else{''})] " -NoNewline -ForegroundColor DarkGray
    } else {
        Write-Host "      $Prompt " -NoNewline -ForegroundColor DarkCyan
        Write-Host "[$Default] " -NoNewline -ForegroundColor DarkGray
    }
    $sw = [System.Diagnostics.Stopwatch]::StartNew(); $buf = ""
    while ($sw.Elapsed.TotalSeconds -lt $Timeout -and -not [Console]::KeyAvailable) { Start-Sleep -Milliseconds 100 }
    if ([Console]::KeyAvailable) {
        if ($Secret) {
            if ($PSVersionTable.PSVersion.Major -ge 7) {
                $buf = Read-Host -MaskInput
            } else {
                $sec  = Read-Host -AsSecureString
                $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
                try   { $buf = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
                finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
            }
            if ($buf) { Register-Secret $buf }
        } else {
            $buf = Read-Host
        }
    } else {
        Write-Host ""
    }
    if ([string]::IsNullOrWhiteSpace($buf)) { $buf = $Default }
    return $buf
}

function Get-SHA512Hash {
    # Generate a SHA-512 crypt hash ($6$...) compatible with chpasswd -e
    # Prefers MiOS helper image (has openssl), falls back to alpine/python
    param([string]$SecretText)
    $salt = -join ((65..90) + (97..122) + (48..57) | Get-Random -Count 16 | ForEach-Object { [char]$_ })

    $hash = $null

    # Try MiOS helper image first (openssl is already installed)
    if ($HelperImage) {
        $hash = & podman run --rm $HelperImage openssl passwd -6 -salt "$salt" "$SecretText" 2>$null
        if ($LASTEXITCODE -eq 0 -and $hash -match '^\$6\$') { return $hash.Trim() }
    }

    # Fallback: alpine + openssl
    $hash = & podman run --rm $FallbackHash sh -c "apk add --quiet openssl >/dev/null 2>&1 && openssl passwd -6 -salt '$salt' '$SecretText'" 2>$null
    if ($LASTEXITCODE -eq 0 -and $hash -match '^\$6\$') { return $hash.Trim() }

    # Fallback: python
    $hash = & podman run --rm docker.io/library/python:3-slim python3 -c "import crypt; print(crypt.crypt('$SecretText', crypt.mksalt(crypt.METHOD_SHA512)))" 2>$null
    return $hash.Trim()
}

function Clear-BIBTemp { foreach ($d in "image","vpc","qcow2","bootiso") { Get-ChildItem $OutputFolder -Directory -Filter $d -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue } }

# --- Auto-Elevation ---
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "  Relaunching as Administrator..." -ForegroundColor Cyan
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$($MyInvocation.MyCommand.Path)`"" -Verb RunAs
    return
}

# -- Self-Build defaults (initialized early - referenced throughout) --
$SelfBuild = $false
$BibImage = "quay.io/centos-bootc/bootc-image-builder:latest"
Set-StrictMode -Version Latest

# ==============================================================================
#  CONFIGURATION
# ==============================================================================
# Source .env.mios if present
if (Test-Path ".env.mios") {
    Write-Phase "0.1" "Loading Unified Environment"
    Get-Content ".env.mios" | ForEach-Object {
        if ($_ -match '^([^#\s][^=]+)="?([^"]*)"?$') {
            $name = $matches[1].Trim()
            $val = $matches[2].Trim()
            [Environment]::SetEnvironmentVariable($name, $val)
        }
    }
}

$v = Get-Content "VERSION" -ErrorAction SilentlyContinue; $Version = if ($v) { $v.Trim() } else { "v0.2.0" }
$ImageName      = if ($env:MIOS_IMAGE_NAME) { ($env:MIOS_IMAGE_NAME -split '/')[-1] -replace ':.*$','' } else { "mios" }
$ImageTag       = "latest"
$MIOS_USER_ADMIN = "mios" # @track:USER_ADMIN
$DefUser        = if ($env:MIOS_USER) { $env:MIOS_USER } elseif ($env:MIOS_DEFAULT_USER) { $env:MIOS_DEFAULT_USER } else { $MIOS_USER_ADMIN }
$DefPass        = if ($env:MIOS_PASSWORD) { $env:MIOS_PASSWORD } elseif ($env:MIOS_DEFAULT_USER_PASSWORD) { $env:MIOS_DEFAULT_USER_PASSWORD } else { "mios" }
$DefHostname    = if ($env:MIOS_HOSTNAME) { $env:MIOS_HOSTNAME } else { "mios" }
$MIOS_REGISTRY_DEFAULT = "ghcr.io/MiOS-DEV/mios" # @track:REGISTRY_DEFAULT
$DefRegistry    = if ($env:MIOS_IMAGE_NAME) { $env:MIOS_IMAGE_NAME -replace ':.*$','' } else { $MIOS_REGISTRY_DEFAULT }
$BibImage       = if ($env:MIOS_BIB_IMAGE) { $env:MIOS_BIB_IMAGE } else { "quay.io/centos-bootc/bootc-image-builder:latest" quay.io/centos-bootc/bootc-image-builder:latest # @track:IMG_BIB
$BuilderMachine = "mios-builder"
$LocalImage     = "localhost/${ImageName}:${ImageTag}"
$MiosDocsDir      = Join-Path ([Environment]::GetFolderPath("MyDocuments")) "MiOS"
$MiosDeployDir    = Join-Path $MiosDocsDir "deployments"
$MiosManifestsDir = Join-Path $MiosDocsDir "manifests"
$MiosImagesDir    = Join-Path $MiosDocsDir "images"
$OutputFolder     = $MiosDeployDir
$MIOS_IMG_RECHUNK = "quay.io/centos-bootc/centos-bootc:stream10" # @track:IMG_RECHUNK
$RechunkImage     = $MIOS_IMG_RECHUNK
$Timeout          = 30

$RawImg         = Join-Path $MiosImagesDir "mios-bootable.raw"
$TargetVhdx     = Join-Path $MiosDeployDir "mios-hyperv.vhdx"
$TargetWsl      = Join-Path $MiosDeployDir "mios-wsl.tar"
$TargetIso      = Join-Path $MiosImagesDir "mios-installer.iso"

# Helper image: prefer MiOS itself, fall back to alpine/python for first build
$HelperImage    = ""
$FallbackHash   = "docker.io/library/alpine:latest"
$FallbackConvert = "docker.io/library/alpine:latest"

# ==============================================================================
#  BANNER + WORKFLOW MENU
# ==============================================================================
Write-Banner "MiOS v$Version - MiOS Builder"

$workflow = $env:MIOS_WORKFLOW
if ([string]::IsNullOrWhiteSpace($workflow)) {
    Write-Host "  Select build workflow:" -ForegroundColor White
    Write-Host ""
    Write-Host "    1) Local Build Only     - Build image, generate targets, NO registry push" -ForegroundColor Cyan
    Write-Host "    2) Build + Push         - Full pipeline: build  targets  push to registry" -ForegroundColor Cyan
    Write-Host "    3) Custom Build         - Custom user/pass/hostname/registry/token" -ForegroundColor Cyan
    Write-Host "    4) Pull + Deploy Only   - Pull existing image from registry, generate targets" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  Choice [1-4] (default 1): " -NoNewline -ForegroundColor Yellow
    $workflow = Read-Host
    if ([string]::IsNullOrWhiteSpace($workflow)) { $workflow = "1" }
} else {
    Write-OK "Workflow inherited from environment: $workflow"
}

$DoPush       = $false
$DoCustom     = $false
$DoBuild      = $true
$DoPull       = $false

switch ($workflow) {
    "1" { $DoPush = $false }
    "2" { $DoPush = $true }
    "3" { $DoPush = $true; $DoCustom = $true }
    "4" { $DoBuild = $false; $DoPull = $true; $DoPush = $false }
    default { Write-Fatal "Invalid choice: $workflow" }
}

# ==============================================================================
#  PHASE 0: CONFIGURATION
# ==============================================================================
Write-Phase "0" "Configuration"

if ($DoCustom) {
    $U = Read-Timed "Username:" $DefUser
    $P = Read-Timed "Password:" $DefPass -Secret
    $HostIn = Read-Timed "Static Hostname (blank for mios-XXXXX):" $DefHostname
    $luksIn = Read-Timed "Enable LUKS encryption? (y/N):" "N"
    $UseLuks = $luksIn -match "^[yY]"
    $LuksPass = if ($UseLuks) { Read-Timed "LUKS passphrase:" "mios" -Secret } else { "" }
    $RegistryUrl = Read-Timed "Registry URL:" $DefRegistry

    Write-Host ""
    Write-Host "      Select Deployment Targets (comma separated or 'all'):" -ForegroundColor DarkCyan
    Write-Host "      1) RAW, 2) VHDX, 3) WSL, 4) ISO" -ForegroundColor DarkGray
    $targetIn = Read-Timed "Targets:" "all"
    if ($targetIn -eq "all") { $SelectedTargets = 1..4 }
    else { $SelectedTargets = $targetIn -split ',' | ForEach-Object { $_.Trim() } }
} else {
    $U = $DefUser
    $P = $DefPass
    $HostIn = $DefHostname
    $UseLuks = $false
    $LuksPass = ""
    $RegistryUrl = $DefRegistry
    
    # Target selection inheritance
    if ($env:MIOS_TARGETS) {
        if ($env:MIOS_TARGETS -eq "none") { $SelectedTargets = @() }
        elseif ($env:MIOS_TARGETS -eq "all") { $SelectedTargets = 1..4 }
        else { $SelectedTargets = $env:MIOS_TARGETS -split ',' | ForEach-Object { [int]$_.Trim() } }
    } else {
        $SelectedTargets = 1..4
    }
}

$GhcrImage = "${RegistryUrl}:${ImageTag}"

# -- Registry credentials (only if pushing or pulling) -------------------------
$RegistryUser  = ""
$RegistryToken = ""

if ($DoPush -or $DoPull) {
    # Try environment variables first (CI/CD friendly)
    $RegistryUser  = $env:MIOS_GHCR_USER
    $RegistryToken = if ($env:MIOS_GHCR_TOKEN) { $env:MIOS_GHCR_TOKEN } else { $env:GHCR_TOKEN }
    if ($RegistryToken) { Register-Secret $RegistryToken }

    if (-not $RegistryUser) {
        $RegistryUser = Read-Timed "Registry username:" "MiOS-DEV"
    }
    if (-not $RegistryToken) {
        Write-Host ""
        Write-Host "      +-----------------------------------------------------+" -ForegroundColor DarkYellow
        Write-Host "      |  Token input is masked. It will NEVER be displayed. |" -ForegroundColor DarkYellow
        Write-Host "      +-----------------------------------------------------+" -ForegroundColor DarkYellow
        $RegistryToken = Read-Timed "Registry token/PAT:" "" -Secret
    }

    if (-not $RegistryToken -and $DoPush) {
        Write-Warn "No registry token provided - push will be skipped"
        $DoPush = $false
    }
}

# -- Summary (NEVER show token or password) ------------------------------------
$tokenStatus = if ($RegistryToken) { "provided (masked)" } else { "none" }
Write-Host ""
Write-OK "User: $U | LUKS: $(if($UseLuks){'Yes'}else{'No'}) | Registry: $GhcrImage"
Write-OK "Workflow: $(switch($workflow){'1'{'Local Build'}; '2'{'Build+Push'}; '3'{'Custom Build+Push'}; '4'{'Pull+Deploy'}}) | Token: $tokenStatus"

# -- Validate prerequisites ---------------------------------------------------
Write-Phase "0.5" "System Validation"
if (-not (Test-Path $OutputFolder)) { New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null }
try { $pv = & podman --version 2>&1; Write-OK "Podman: $pv" } catch { Write-Fatal "Podman not found" }
$cpu = (Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors
$ram = [math]::Floor((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1MB)
Write-OK "CPU: $cpu cores | RAM: $ram MB"

if ($DoBuild) {
    foreach ($f in "Containerfile","usr/share/mios/PACKAGES.md","VERSION","automation/build.sh","automation/31-user.sh") {
        if (-not (Test-Path $f)) { Write-Fatal "Missing required file: $f - are you in the MiOS repo root?" }
    }
    Write-OK "All repo files present"
}

# ==============================================================================
#  PHASE 1: PODMAN BUILDER MACHINE
# ==============================================================================
Write-Phase "1" "Podman Builder Machine"
$ErrorActionPreference = "Continue"

$builderScript = Join-Path $PWD "automation\mios-build-builder.ps1"
if (-not (Test-Path $builderScript)) { Write-Fatal "Missing $builderScript" }

Write-Step "Executing dedicated builder provisioning script..."
& $builderScript -MachineName $BuilderMachine
if ($LASTEXITCODE -ne 0) { Write-Fatal "Builder provisioning failed." }

& podman system connection default "${BuilderMachine}-root"
Write-OK "Builder connection set to: ${BuilderMachine}-root"
$ErrorActionPreference = "Stop"


# ==============================================================================
Write-Phase "1.5" "Self-Building - Pull MiOS Helper Image"
$ErrorActionPreference = "Continue"

# Try to pull the existing MiOS image from the registry.
# If it exists, use it as the helper image for ALL container operations
# (hash generation, qemu-img conversion, etc.) - MiOS IS the builder.
# First build ever: no image exists yet, fall back to alpine/python.
Write-Step "Checking for existing MiOS image at $GhcrImage..."

# Authenticate if we have credentials
if ($RegistryToken) {
    $registryHost = ($GhcrImage -split '/')[0]
    $RegistryToken | & podman login $registryHost --username $RegistryUser --password-stdin 2>&1 | Out-Null
}

& podman pull $GhcrImage 2>$null
if ($LASTEXITCODE -eq 0) {
    $HelperImage = $GhcrImage
    Write-OK "MiOS helper image pulled - self-building cycle active"
    Write-OK "All helper operations will use MiOS (openssl, qemu-img, etc.)"
} else {
    # Check if it exists locally already (previous local build)
    & podman image exists $LocalImage 2>$null
    if ($LASTEXITCODE -eq 0) {
        $HelperImage = $LocalImage
        Write-OK "Using local MiOS image as helper - self-building cycle active"
    } else {
        $HelperImage = ""
        Write-Warn "No existing MiOS image found - first build, using alpine/python fallbacks"
        Write-Step "After this build completes and pushes, subsequent builds will self-build"
    }
}
# -- Self-Building BIB: Try MiOS as bootc-image-builder --------------------
# MiOS includes bootc-image-builder + osbuild as RPMs. If HelperImage is set,
# verify it can serve as BIB. Falls back to centos-bootc on first build.
$BIBSelfBuild = $false
if ($HelperImage) {
    $ErrorActionPreference = "Continue"
    $null = & podman run --rm $HelperImage which bootc-image-builder 2>$null
    if ($LASTEXITCODE -eq 0) {
        $BIBImage = $HelperImage
        $BIBSelfBuild = $true
        Write-OK "Self-building BIB: MiOS image will be used as bootc-image-builder"
    } else {
        Write-Step "MiOS image lacks bootc-image-builder binary - using centos-bootc BIB"
    }
}
$ErrorActionPreference = "Stop"


# ==============================================================================
if ($DoPull) {
    Write-Phase "2" "Pulling Image from Registry"
    if ($RegistryToken) {
        $registryHost = ($GhcrImage -split '/')[0]
        Write-Step "Authenticating to $registryHost..."
        $RegistryToken | & podman login $registryHost --username $RegistryUser --password-stdin 2>&1 | Out-Null
    }
    Write-Step "Pulling $GhcrImage..."
    & podman pull $GhcrImage
    if ($LASTEXITCODE -ne 0) { Write-Fatal "Pull failed" }
    & podman tag $GhcrImage $LocalImage
    Write-OK "Image pulled and tagged as $LocalImage"
} elseif ($DoBuild) {
    Write-Phase "2" "OCI Container Build"

    # -- Hash the password BEFORE injection --
    Write-Step "Pre-hashing credentials (plaintext will NOT appear in build log)..."
    $passHash = Get-SHA512Hash -SecretText $P
    if (-not $passHash -or $passHash -notmatch '^\$6\$') {
        Write-Fatal "Failed to generate password hash. Check podman connectivity."
    }
    Write-OK "Password hashed (SHA-512)"

    # -- Inject hostname (only if custom; restored via git checkout after build) --
    if ($HostIn -ne "mios") {
        Write-Step "Injecting static hostname: $HostIn ..."
        Set-Content "etc/hostname" "$HostIn" -Encoding ascii
    }

    $t0 = Get-Date
    Write-Step "Building OCI image (all $cpu threads, MAKEFLAGS=-j$cpu)..."
    
    # Force TTY detection and color for localized progress bars
    $env:FORCE_COLOR = "1"
    $env:BUILDAH_FORMAT = "docker"

    # Credentials passed as --build-arg: hash is available as MIOS_PASSWORD_HASH
    # env var inside the container build (consumed by 31-user.sh). Plaintext NEVER
    # written to disk, never appears in the build log or image layer metadata.
    & podman build --progress=tty --no-cache `
        --build-arg MAKEFLAGS="-j$cpu" `
        --build-arg MIOS_USER="$U" `
        --build-arg MIOS_PASSWORD_HASH="$passHash" `
        --jobs 2 -t $LocalImage .
    
    if ($LASTEXITCODE -ne 0) { Write-Fatal "podman build failed" }

    Write-Progress -Activity "MiOS Build ${Version}" -Completed

    # Restore hostname if it was temporarily overridden
    & git checkout etc/hostname 2>$null | Out-Null

    $buildMin = [math]::Round(((Get-Date) - $t0).TotalMinutes, 1)
    Write-OK "Image built in $buildMin min  $LocalImage"

    # Tag with GHCR ref BEFORE BIB - sets permanent update origin
    Write-Step "Tagging as $GhcrImage (sets update origin for bootc)..."
    & podman tag $LocalImage $GhcrImage
    Write-OK "Update origin set: $GhcrImage"

    # Rechunk
    Write-Step "Rechunking for optimized OCI layers..."
    $ErrorActionPreference = "Continue"
    # Use the freshly built image as the rechunker tool (Self-Building)
    # Falls back to external RECHUNK_IMAGE if local fails
    & podman run --rm --privileged `
        -v /var/lib/containers/storage:/var/lib/containers/storage `
        $LocalImage /usr/libexec/bootc-base-imagectl rechunk --max-layers 67 "containers-storage:$LocalImage" "containers-storage:$LocalImage"
    if ($LASTEXITCODE -ne 0) {
        Write-Warn "Self-build rechunk failed; falling back to external rechunker"
        & podman run --rm --privileged `
            -v /var/lib/containers/storage:/var/lib/containers/storage `
            $RechunkImage /usr/libexec/bootc-base-imagectl rechunk --max-layers 67 "containers-storage:$LocalImage" "containers-storage:$LocalImage"
    }
    $ErrorActionPreference = "Stop"

    Write-OK "Rechunk complete"

    # Update helper image reference - this freshly built image IS the builder now
    $HelperImage = $LocalImage
    # Check if freshly built image can serve as BIB for deployment targets
    $null = & podman run --rm $LocalImage which bootc-image-builder 2>$null
    if ($LASTEXITCODE -eq 0) {
        $BIBImage = $LocalImage
        $BIBSelfBuild = $true
        Write-OK "Helper image updated - self-building BIB active (MiOS IS the builder)"
    } else {
        Write-OK "Helper image updated to freshly built $LocalImage (self-building ready)"
    }
}

# ==============================================================================
#  PHASE 3: GENERATE DEPLOYMENT TARGETS
# ==============================================================================
Write-Phase "3" "Generating Deployment Targets"
$ErrorActionPreference = "Continue"

$bibConf = Join-Path $PWD "config\bib.toml"
if (-not (Test-Path $bibConf)) { $bibConf = Join-Path $PWD "config\bib.json" }
$bibConfDest = Join-Path $OutputFolder "bib-config"
if (Test-Path $bibConf) {
    if ($bibConf -match '\.toml$') {
        $bibMountPath = "/config.toml"
        Copy-Item $bibConf "$bibConfDest.toml" -Force
        $bibConfDest = "$bibConfDest.toml"
    } else {
        $bibMountPath = "/config.json"
        Copy-Item $bibConf "$bibConfDest.json" -Force
        $bibConfDest = "$bibConfDest.json"
    }
    Write-OK "BIB config: 80 GiB minimum root (mounted as $bibMountPath)"
} else {
    Write-Warn "No BIB config found - disk may auto-size too small!"
    $bibConfDest = $null
}

$isoToml = Join-Path $PWD "iso.toml"
$hasIsoToml = Test-Path $isoToml
if ($hasIsoToml) { Write-OK "iso.toml found - kickstart will be injected into ISO" }

function Get-BIBArgs {
    param([string]$Type)
    $bibArgs = @(
        "run", "--rm", "-it", "--privileged",
        "--security-opt", "label=type:unconfined_t",
        "-v", "/var/lib/containers/storage:/var/lib/containers/storage",
        "-v", "${OutputFolder}:/output:z"
    )
    if ($Type -eq "anaconda-iso" -and $hasIsoToml) {
        $isoContent = Get-Content $isoToml -Raw
        $isoContent = $isoContent.Replace('INJ_U', $U)
        $isoContent = $isoContent.Replace('INJ_IMAGE', $GhcrImage)
        if (-not $script:passHash) { $script:passHash = Get-SHA512Hash -SecretText $P }
        if ($script:passHash) {
            $isoContent = $isoContent.Replace('INJ_HASH', $script:passHash)
        }
        $isoContent | Set-Content (Join-Path $OutputFolder "iso.toml") -NoNewline -Encoding UTF8
        $bibArgs += @("-v", "$(Join-Path $OutputFolder 'iso.toml'):/config.toml:ro")
    } elseif ($bibConfDest) {
        $bibArgs += @("-v", "${bibConfDest}:${bibMountPath}:ro")
    }
    if ($UseLuks -and $Type -in @("raw","anaconda-iso")) {
        $LuksPass | Set-Content (Join-Path $OutputFolder ".luks-tmp") -NoNewline
        $bibArgs += @("-v", "$(Join-Path $OutputFolder '.luks-tmp'):/luks-pass:ro")
        $bibArgs += @("--env", "LUKS_PASSPHRASE_FILE=/luks-pass")
    }
    $bibArgs += @($BIBImage, "build", "--type", $Type, "--rootfs", "ext4", "--local", $LocalImage)
    return $bibArgs
}

# -- RAW --
if ($SelectedTargets -contains 1) {
    Write-Step "TARGET 1 - RAW disk image..."
    Clear-BIBTemp
    $rawArgs = Get-BIBArgs "raw"
    & podman @rawArgs 2>&1
    if ($LASTEXITCODE -eq 0) {
        $rawFile = Get-ChildItem $OutputFolder -Recurse -Filter "*.raw" | Select-Object -First 1
        if ($rawFile) { Move-Item $rawFile.FullName $RawImg -Force; Write-OK "RAW: $(Get-FileSize $RawImg)" }
    } else { Write-Warn "RAW build failed" }
}

# -- VHDX --
if ($SelectedTargets -contains 2) {
    Write-Step "TARGET 2 - VHD  VHDX (Hyper-V Gen2)..."
    Clear-BIBTemp
    $vhdArgs = Get-BIBArgs "vhd"
    & podman @vhdArgs 2>&1
    if ($LASTEXITCODE -eq 0) {
        # BIB nests output in subdirectories (vpc/disk.vhd or image/disk.vhd).
        # Move to output root first so the container mount path is simple.
        $vhdFile = Get-ChildItem $OutputFolder -Recurse -Include "*.vhd","*.vpc" | Select-Object -First 1
        if ($vhdFile) {
            $vhdSrc = Join-Path $OutputFolder "disk.vhd"
            if ($vhdFile.FullName -ne $vhdSrc) {
                Move-Item $vhdFile.FullName $vhdSrc -Force
            }
            Write-Step "Converting disk.vhd  VHDX (parallel coroutines)..."
            # -m 16 -W enables 16 parallel coroutines and out-of-order writes for massive speedup
            if ($HelperImage) {
                & podman run --rm -v "${OutputFolder}:/data:z" $HelperImage `
                    qemu-img convert -m 16 -W -f vpc -O vhdx /data/disk.vhd /data/mios-hyperv.vhdx
            } else {
                & podman run --rm -v "${OutputFolder}:/data:z" $FallbackConvert sh -c `
                    "apk add --quiet qemu-img && qemu-img convert -m 16 -W -f vpc -O vhdx /data/disk.vhd /data/mios-hyperv.vhdx"
            }
            Remove-Item $vhdSrc -Force -ErrorAction SilentlyContinue
            Clear-BIBTemp
            if (Test-Path $TargetVhdx) { Write-OK "VHDX: $(Get-FileSize $TargetVhdx)" }
            else { Write-Warn "VHDX conversion failed - qemu-img error" }
        } else {
            Write-Warn "VHD file not found in BIB output"
        }
    } else { Write-Warn "VHD build failed" }
}

# -- WSL --
if ($SelectedTargets -contains 3) {
    Write-Step "TARGET 3 - WSL2 tarball (via native bootc export)..."
    if ($HelperImage) {
        & podman run --rm --privileged -v "${MiosDeployDir}:/output:z" $HelperImage bootc container export --format=tar "oci-archive:/output/wsl.oci" --output /output/mios-wsl.tar
        if ($LASTEXITCODE -ne 0) {
            # Fallback for older helper images
            Write-Warn "bootc export failed, falling back to podman export..."
            $wslCid = & podman create $LocalImage 2>$null
            if ($wslCid) {
                & podman export $wslCid -o $TargetWsl 2>$null
                & podman rm $wslCid 2>$null
            }
        }
    } else {
        # Fallback if no helper image exists at all
        $wslCid = & podman create $LocalImage 2>$null
        if ($wslCid) {
            & podman export $wslCid -o $TargetWsl 2>$null
            & podman rm $wslCid 2>$null
        }
    }
    if (Test-Path $TargetWsl) { Write-OK "WSL: $(Get-FileSize $TargetWsl)" }
    else { Write-Warn "WSL export failed" }
}

# -- ISO --
if ($SelectedTargets -contains 4) {
    Write-Step "TARGET 4 - Anaconda installer ISO..."
    Clear-BIBTemp
    $isoArgs = Get-BIBArgs "anaconda-iso"
    & podman @isoArgs 2>&1
    if ($LASTEXITCODE -eq 0) {
        $isoFile = Get-ChildItem $OutputFolder -Recurse -Filter "*.iso" | Select-Object -First 1
        if ($isoFile) { Move-Item $isoFile.FullName $TargetIso -Force; Write-OK "ISO: $(Get-FileSize $TargetIso)" }
    } else { Write-Warn "ISO failed" }
}

# Clean LUKS temp
Remove-Item (Join-Path $OutputFolder ".luks-tmp") -Force -ErrorAction SilentlyContinue

# ==============================================================================
#  PHASE 3b: DEPLOYMENT (Hyper-V + WSL2)
# ==============================================================================
if ($env:MIOS_SKIP_DEPLOY -eq "1") {
    Write-OK "Deployment phase skipped (MIOS_SKIP_DEPLOY=1)"
} else {
    Write-Phase "3b" "Deployment (Hyper-V + WSL2)"

    # Hyper-V
    if (Test-Path $TargetVhdx) {
        $ErrorActionPreference = "Continue"
        $vmName = "MiOS"
        $doDeploy = $true
        if ($env:MIOS_FORCE_DEPLOY -ne "1") {
            $ans = Read-Timed "Deploy/Update Hyper-V VM '$vmName'? (y/N)" "N"
            $doDeploy = $ans -match "^[yY]"
        }

        if ($doDeploy) {
            try {
                Write-Step "Preparing Hyper-V VM..."
                if (Get-VM -Name $vmName -ErrorAction SilentlyContinue) {
                    Write-Warn "VM '$vmName' already exists. This will OVERWRITE it."
                    $ans = "Y"
                    if ($env:MIOS_FORCE_DEPLOY -ne "1") {
                        $ans = Read-Timed "Confirm OVERWRITE of '$vmName'? (y/N)" "N"
                    }
                    if ($ans -match "^[yY]") {
                        Stop-VM -Name $vmName -Force -ErrorAction SilentlyContinue
                        Remove-VM -Name $vmName -Force
                    } else {
                        Write-Warn "Overwrite cancelled. Skipping Hyper-V deployment."
                        $doDeploy = $false
                    }
                }
                
                if ($doDeploy) {
                    $vmSwitchObj = Get-VMSwitch | Where-Object SwitchType -eq "External" | Select-Object -First 1
                    $vmSwitch = if ($vmSwitchObj) { $vmSwitchObj.Name } else { "Default Switch" }
                    $vmCpu = $cpu
                    $totalRamBytes = (Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory
                    $vmRamRaw = [int64]($totalRamBytes * 0.8)
                    $vmRam = [int64]([Math]::Floor($vmRamRaw / 2MB) * 2MB)  # Align to 2MB (Hyper-V requirement)
                    $vmRamGB = [Math]::Floor($vmRam / 1GB)
                    $minRam = [Math]::Min(16GB, [int64]([Math]::Floor($totalRamBytes * 0.5 / 2MB) * 2MB))
                    if ($totalRamBytes -lt 16GB) { $minRam = [int64]([Math]::Floor($totalRamBytes * 0.5 / 2MB) * 2MB) }
                    else { $minRam = 16GB }

                    New-VM -Name $vmName -MemoryStartupBytes $minRam -Generation 2 -VHDPath $TargetVhdx -SwitchName $vmSwitch | Out-Null
                    Set-VM -Name $vmName -ProcessorCount $vmCpu -DynamicMemory -MemoryMinimumBytes $minRam -MemoryMaximumBytes $vmRam -MemoryStartupBytes $minRam
                    Set-VMFirmware -VMName $vmName -SecureBootTemplate "MicrosoftUEFICertificateAuthority"
                    Write-OK "Hyper-V VM '$vmName' created (CPUs: $vmCpu | RAM: ${vmRamGB}GB max)"

                    # Start VM
                    Write-Step "Starting VM..."
                    Start-VM -Name $vmName
                    
                    # Wait for POST
                    $timeout = 120; $elapsed = 0; $hb = ""
                    while ($elapsed -lt $timeout) {
                        $hb = (Get-VMIntegrationService -VMName $vmName | Where-Object Name -eq "Heartbeat").PrimaryStatusDescription
                        if ($hb -eq "OK") { break }
                        Start-Sleep 5; $elapsed += 5
                        Write-Progress -Activity "Hyper-V POST" -Status "Waiting for heartbeat..." -PercentComplete ([int]($elapsed/$timeout*100))
                    }
                    Write-Progress -Activity "Hyper-V POST" -Completed

                    if ($hb -eq "OK") {
                        Write-OK "VM fully booted (heartbeat OK)"
                        Write-Step "Enabling Enhanced Session (HvSocket)..."
                        Stop-VM -Name $vmName -Force -ErrorAction SilentlyContinue
                        Set-VM -Name $vmName -EnhancedSessionTransportType HvSocket
                        Start-VM -Name $vmName
                        Write-OK "Hyper-V VM ready. Connect: vmconnect.exe localhost $vmName"
                    } else {
                        Write-Warn "VM may still be booting (no heartbeat). Configure Enhanced Session manually if needed."
                    }
                }
            } catch { Write-Warn "Hyper-V deployment failed: $_" }
        }
    }

    # WSL2
    if (Test-Path $TargetWsl) {
        $ErrorActionPreference = "Continue"
        $WslName = "MiOS"
        $WslPath = Join-Path $env:USERPROFILE "WSL\$WslName"
        $doDeploy = $true
        if ($env:MIOS_FORCE_DEPLOY -ne "1") {
            $ans = Read-Timed "Import/Update WSL2 distro '$WslName'? (y/N)" "N"
            $doDeploy = $ans -match "^[yY]"
        }

        if ($doDeploy) {
            try {
                Write-Step "Preparing WSL2 distro..."
                $existing = wsl --list --quiet | Where-Object { $_ -match "^$WslName" }
                if ($existing) {
                    Write-Warn "WSL distro '$WslName' already exists. This will DELETE it."
                    $ans = "Y"
                    if ($env:MIOS_FORCE_DEPLOY -ne "1") {
                        $ans = Read-Timed "Confirm DELETION of existing '$WslName'? (y/N)" "N"
                    }
                    if ($ans -match "^[yY]") {
                        wsl --unregister $WslName | Out-Null
                    } else {
                        Write-Warn "WSL import cancelled."
                        $doDeploy = $false
                    }
                }

                if ($doDeploy) {
                    New-Item -ItemType Directory -Path $WslPath -Force | Out-Null
                    wsl --import $WslName $WslPath $TargetWsl --version 2
                    if ($LASTEXITCODE -eq 0) {
                        Write-OK "WSL2 distro '$WslName' imported"
                        
                        # Generate .wslconfig
                        $wslConfigPath = Join-Path $env:USERPROFILE ".wslconfig"
                        $wslCPUs = $cpu
                        $wslRAM = [Math]::Max(16, [Math]::Floor((Get-CimInstance Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum).Sum / 1GB * 0.75))
                        
                        $wslLines = @(
                            "# MiOS v0.2.0 - WSL2 Configuration",
                            "[wsl2]",
                            "memory=${wslRAM}GB",
                            "processors=${wslCPUs}",
                            "swap=8GB",
                            "localhostForwarding=true",
                            "nestedVirtualization=true",
                            "vmIdleTimeout=-1",
                            "systemd=true",
                            "",
                            "[experimental]",
                            "networkingMode=mirrored",
                            "dnsTunneling=true",
                            "autoProxy=true"
                        )
                        $wslLines -join "`r`n" | Set-Content $wslConfigPath -Encoding UTF8
                        Write-OK ".wslconfig optimized: ${wslRAM}GB RAM"
                    } else { Write-Warn "WSL import failed" }
                }
            } catch { Write-Warn "WSL2 deployment failed: $_" }
        }
    }
}
$ErrorActionPreference = "Stop"


# ==============================================================================
if ($DoPush -and $RegistryToken) {
    Write-Phase "4" "Registry Push  $GhcrImage"
    $ErrorActionPreference = "Continue"
    $registryHost = ($GhcrImage -split '/')[0]

    Write-Step "Authenticating to $registryHost (token via stdin - NOT in process args)..."
    $RegistryToken | & podman login $registryHost --username $RegistryUser --password-stdin 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { Write-Warn "Registry login failed - push may fail" }

    & podman push $GhcrImage
    if ($LASTEXITCODE -eq 0) {
        Write-OK "Pushed to $registryHost"
        # Make package public if ghcr.io
        if ($registryHost -eq "ghcr.io") {
            try {
                $pkgName = ($GhcrImage -split '/')[-1] -replace ':.*$',''
                $owner = ($GhcrImage -split '/')[1]
                $headers = @{ Authorization = "Bearer $RegistryToken"; Accept = "application/vnd.github+json" }
                $uri = "https://api.github.com/orgs/$owner/packages/container/$pkgName"
                $body = '{"visibility":"public"}'
                try { Invoke-RestMethod -Uri $uri -Method Patch -Headers $headers -Body $body -ContentType "application/json" -ErrorAction Stop }
                catch { $uri = "https://api.github.com/user/packages/container/$pkgName"; Invoke-RestMethod -Uri $uri -Method Patch -Headers $headers -Body $body -ContentType "application/json" -ErrorAction SilentlyContinue }
                Write-OK "Package visibility set to public"
            } catch { Write-Warn "Could not set package visibility (may need manual config)" }
        }
    } else { Write-Warn "Push failed" }
    $ErrorActionPreference = "Stop"

} elseif ($DoPush) {
    Write-Warn "Skipping push - no registry token provided"
}

# ==============================================================================
#  PHASE 5: SUMMARY
# ==============================================================================
Write-Phase "5" "Build Summary"
Write-Host ""

# Self-building status
if ($HelperImage) {
    Write-OK "Self-building: ACTIVE - MiOS image used as builder"
    if ($BIBSelfBuild) { Write-OK "  BIB: Self-building (MiOS used as bootc-image-builder)" }
    else { Write-OK "  BIB: External (centos-bootc)" }
    Write-OK "  Next build will pull this image and use it for all operations"
} else {
    Write-Warn "Self-building: BOOTSTRAP - first build used fallback images"
    Write-OK "  After push, subsequent builds will self-build from $GhcrImage"
}
Write-Host ""

$targets = @()
if (Test-Path $RawImg)    { $targets += "RAW: $(Get-FileSize $RawImg)" }
if (Test-Path $TargetVhdx){ $targets += "VHDX: $(Get-FileSize $TargetVhdx)" }
if (Test-Path $TargetWsl) { $targets += "WSL: $(Get-FileSize $TargetWsl)" }
if (Test-Path $TargetIso) { $targets += "ISO: $(Get-FileSize $TargetIso)" }
foreach ($t in $targets) { Write-OK $t }
Write-Host ""
Write-OK "Output folder: $OutputFolder"

# -- Copy Manifests --
if (-not (Test-Path $MiosManifestsDir)) { New-Item -ItemType Directory -Path $MiosManifestsDir -Force | Out-Null }
$manifests = @("root-manifest.json", "ai-context.json")
foreach ($mf in $manifests) {
    if (Test-Path $mf) { Copy-Item $mf (Join-Path $MiosManifestsDir $mf) -Force -ErrorAction SilentlyContinue }
}
Write-OK "Manifests staged in $MiosManifestsDir"

Write-Host ""
Write-Host "  MiOS is self-replicating: pull  build  push  repeat" -ForegroundColor Cyan
Write-Host "  On deployed MiOS:  mios-rebuild" -ForegroundColor Cyan
Write-Host "  On any machine:       podman pull $GhcrImage" -ForegroundColor Cyan
Write-Host ""

Show-StatusCard

# Cleanup: wipe any credential variables from memory
$P = $null; $passHash = $null; $RegistryToken = $null; $LuksPass = $null
[System.GC]::Collect()
```

---

## preflight.ps1

```powershell
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host '  Run as Administrator!' -ForegroundColor Red
    return
}
<#
.SYNOPSIS
    MiOS Preflight -- Check and install prerequisites
.DESCRIPTION
    Usage: $tmp = "$env:TEMP\mios-preflight.ps1"; irm https://raw.githubusercontent.com/MiOS-DEV/mios/main/preflight.ps1 | Set-Content $tmp; & $tmp; Remove-Item $tmp
#>
$ErrorActionPreference = "Continue"

Write-Host ""
Write-Host "+==============================================================+" -ForegroundColor Cyan
Write-Host "|  MiOS Preflight -- Prerequisites Check                    |" -ForegroundColor Cyan
Write-Host "+==============================================================+" -ForegroundColor Cyan
Write-Host ""

$pass = 0
$fail = 0
$fixed = 0

function Check($name, $test, $fix) {
    Write-Host "  [$name] " -NoNewline
    if (& $test) {
        Write-Host "[OK]" -ForegroundColor Green
        $script:pass++
    }
    else {
        Write-Host "[MISSING]" -ForegroundColor Red
        $script:fail++
        if ($fix) {
            $doFix = Read-Host "    Install $name? (y/n)"
            if ($doFix -eq 'y') {
                & $fix
                $script:fixed++
            }
        }
    }
}

Write-Host "--- System ---" -ForegroundColor Yellow
Check "Windows 10/11 Pro+" {
    (Get-CimInstance Win32_OperatingSystem).Caption -match "Pro|Enterprise|Education"
} $null

Write-Host ""
Write-Host "--- WSL2 ---" -ForegroundColor Yellow
Check "WSL2 Feature" {
    (Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Windows-Subsystem-Linux).State -eq 'Enabled'
} {
    Write-Host "    Enabling WSL..." -ForegroundColor Cyan
    wsl --install --no-distribution
    Write-Host "    [WARN] Reboot required after WSL install" -ForegroundColor Yellow
}
Check "Virtual Machine Platform" {
    (Get-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform).State -eq 'Enabled'
} {
    Enable-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -NoRestart
}

Write-Host ""
Write-Host "--- Hyper-V (optional) ---" -ForegroundColor Yellow
Check "Hyper-V" {
    (Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V).State -eq 'Enabled'
} {
    Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -All -NoRestart
    Write-Host "    [WARN] Reboot required" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "--- PowerShell ---" -ForegroundColor Yellow
Check "PowerShell 7+" {
    $PSVersionTable.PSVersion.Major -ge 7
} {
    Write-Host "    Installing PowerShell 7+ via winget..." -ForegroundColor Cyan
    winget install --id Vendor.PowerShell --accept-source-agreements --accept-package-agreements
    Write-Host "    [WARN] Restart terminal after PS7 install, then re-run preflight" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "--- Software ---" -ForegroundColor Yellow
Check "Git" {
    Get-Command git -ErrorAction SilentlyContinue
} {
    winget install --id Git.Git --accept-source-agreements --accept-package-agreements
}
Check "Podman" {
    Get-Command podman -ErrorAction SilentlyContinue
} {
    winget install --id RedHat.Podman --accept-source-agreements --accept-package-agreements
}
Check "Podman Desktop" {
    (Get-Command "podman-desktop" -ErrorAction SilentlyContinue) -or (Test-Path "$env:LOCALAPPDATA\Programs\Podman Desktop")
} {
    winget install --id RedHat.Podman-Desktop --accept-source-agreements --accept-package-agreements
}

Write-Host ""
Write-Host "--- Results ---" -ForegroundColor Cyan
Write-Host "  Passed: $pass  Failed: $fail  Fixed: $fixed" -ForegroundColor White
if ($fail -eq 0 -or $fail -eq $fixed) {
    Write-Host "  [OK] Ready to build MiOS!" -ForegroundColor Green
    Write-Host "    Run: `$tmp = `"`$env:TEMP\mios-install.ps1`"; irm https://raw.githubusercontent.com/MiOS-DEV/mios/main/install.ps1 | Set-Content `$tmp; & `$tmp; Remove-Item `$tmp" -ForegroundColor Gray
} else {
    Write-Host "  [WARN] Some prerequisites missing. Fix them and re-run." -ForegroundColor Yellow
}
Write-Host ""```

---

## push-to-github.ps1

```powershell
# ============================================================================
# push-to-github.ps1  MiOS release deliverable (v0.2.0 baseline)
# ----------------------------------------------------------------------------
# Single source of truth for the release pipeline. Per INDEX.md 4 + the
# /push-version skill, this script is rewritten per release and never split
# into push-vX.Y.Z.ps1 siblings.
#
# Behaviour:
#   1. Clone github.com/MiOS-DEV/MiOS-bootstrap into a temp directory.
#   2. Optionally overlay a staged companion directory (-StagedDir) onto the
#      working tree, preserving layout relative to repo root. Files-only 
#      directories are walked and replaced file by file. Nothing is deleted.
#   3. Bump VERSION to -Version (default: read from local VERSION file).
#   4. Stamp CHANGELOG.md with a top-of-file release block dated today.
#   5. Commit with a structured release message.
#   6. Push to main using $env:GH_TOKEN or the configured credential helper.
#   7. Print a summary: changed paths, commit SHA, GHCR tag.
#
# This is the deliverable. Humans run it; the agent does not push for you.
# ============================================================================

[CmdletBinding()]
param(
    [string]$Version,
    [string]$Message = 'release sync',
    [string]$StagedDir,
    [string]$Repo = 'github.com/MiOS-DEV/MiOS-bootstrap',
    [string]$Branch = 'main',
    [switch]$DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-Step([string]$msg) { Write-Host "==> $msg" -ForegroundColor Cyan }
function Write-Ok  ([string]$msg) { Write-Host "    $msg" -ForegroundColor Green }
function Write-Warn([string]$msg) { Write-Host "    $msg" -ForegroundColor Yellow }

$repoRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not (Test-Path -LiteralPath (Join-Path $repoRoot 'VERSION'))) {
    throw "push-to-github.ps1 must live at the repo root next to VERSION."
}

if (-not $Version) {
    $Version = (Get-Content -LiteralPath (Join-Path $repoRoot 'VERSION') -Raw).Trim()
    Write-Warn "No -Version given; using local VERSION file: $Version"
}

if ($StagedDir) {
    if (-not (Test-Path -LiteralPath $StagedDir -PathType Container)) {
        throw "Staged companion directory not found: $StagedDir"
    }
    $StagedDir = (Resolve-Path -LiteralPath $StagedDir).Path
}

# Token discovery  never echoed to stdout.
$token = $env:GH_TOKEN
if (-not $token) { $token = $env:GITHUB_TOKEN }
if (-not $token) {
    Write-Warn 'No GH_TOKEN/GITHUB_TOKEN in environment; relying on git credential helper.'
}

$workDir = Join-Path ([System.IO.Path]::GetTempPath()) ("mios-push-" + [guid]::NewGuid().ToString('N').Substring(0,8))
Write-Step "Working directory: $workDir"
New-Item -ItemType Directory -Force -Path $workDir | Out-Null

try {
    $cloneUrl = if ($token) { "https://x-access-token:$token@$Repo.git" } else { "https://$Repo.git" }
    $safeUrl  = "https://$Repo.git"

    Write-Step "Cloning $safeUrl ($Branch)  full history."
    git clone --branch $Branch $cloneUrl $workDir 2>&1 | ForEach-Object { Write-Verbose $_ }
    if ($LASTEXITCODE -ne 0) { throw "git clone failed (exit $LASTEXITCODE)." }

    if ($StagedDir) {
        Write-Step "Overlaying staged files from $StagedDir"
        $stagedFiles = Get-ChildItem -LiteralPath $StagedDir -Recurse -File
        foreach ($f in $stagedFiles) {
            $rel = $f.FullName.Substring($StagedDir.Length).TrimStart('\','/')
            $dst = Join-Path $workDir $rel
            $dstDir = Split-Path -Parent $dst
            if (-not (Test-Path -LiteralPath $dstDir)) {
                New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
            }
            Copy-Item -LiteralPath $f.FullName -Destination $dst -Force
            Write-Ok "copied $rel"
        }
    } else {
        Write-Step "No -StagedDir; pushing local working tree state under $repoRoot"
        # Mirror the working repo into the clone (excluding .git).
        $rsyncSrc = (Resolve-Path -LiteralPath $repoRoot).Path
        Get-ChildItem -LiteralPath $rsyncSrc -Force -Recurse -File |
            Where-Object { $_.FullName -notlike (Join-Path $rsyncSrc '.git*') } |
            ForEach-Object {
                $rel = $_.FullName.Substring($rsyncSrc.Length).TrimStart('\','/')
                if ($rel -like '.git\*' -or $rel -eq '.git') { return }
                $dst = Join-Path $workDir $rel
                $dstDir = Split-Path -Parent $dst
                if (-not (Test-Path -LiteralPath $dstDir)) {
                    New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
                }
                Copy-Item -LiteralPath $_.FullName -Destination $dst -Force
            }
    }

    Write-Step "Bumping VERSION  $Version"
    Set-Content -LiteralPath (Join-Path $workDir 'VERSION') -Value $Version -NoNewline -Encoding utf8

    $changelog = Join-Path $workDir 'CHANGELOG.md'
    if (Test-Path -LiteralPath $changelog) {
        $today = Get-Date -Format 'yyyy-MM-dd'
        $existing = Get-Content -LiteralPath $changelog -Raw
        $header = "# Changelog`r`nAll notable changes to this project will be documented in this file.`r`n"
        $body = $existing
        if ($body.StartsWith($header)) { $body = $body.Substring($header.Length).TrimStart() }
        $newBlock = "## [v$Version] - $today`r`n`r`n- $Message`r`n`r`n"
        Set-Content -LiteralPath $changelog -Value ($header + "`r`n" + $newBlock + $body) -Encoding utf8
        Write-Ok "CHANGELOG.md stamped v$Version ($today)"
    } else {
        Write-Warn "CHANGELOG.md missing in clone  skipping changelog stamp."
    }

    Push-Location $workDir
    try {
        git add --all 2>&1 | ForEach-Object { Write-Verbose $_ }
        $status = git status --porcelain
        if (-not $status) {
            Write-Warn 'No changes to commit. Nothing to push.'
            return
        }

        $commitMsg = "release: v$Version  $Message"
        if ($DryRun) {
            Write-Step "DRY RUN  skipping commit/push. Pending changes:"
            Write-Host $status
            return
        }

        git -c user.name='MiOS bot' -c user.email='mios@users.noreply.github.com' `
            commit -m $commitMsg 2>&1 | ForEach-Object { Write-Verbose $_ }
        if ($LASTEXITCODE -ne 0) { throw "git commit failed (exit $LASTEXITCODE)." }

        $sha = (git rev-parse HEAD).Trim()
        Write-Step "Pushing to $Branch"
        git push origin $Branch 2>&1 | ForEach-Object { Write-Verbose $_ }
        if ($LASTEXITCODE -ne 0) { throw "git push failed (exit $LASTEXITCODE)." }

        Write-Ok "Commit: $sha"
        Write-Ok "GHCR tag (built by CI): ghcr.io/MiOS-DEV/mios:$Version"
    }
    finally {
        Pop-Location
    }
}
finally {
    if (Test-Path -LiteralPath $workDir) {
        Remove-Item -LiteralPath $workDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}
```

# Layer 4a — Build pipeline library

---

## automation/lib/common.sh

```bash
#!/usr/bin/env bash
# ============================================================================
# automation/lib/common.sh
# ----------------------------------------------------------------------------
# Shared helpers for MiOS build scripts.
# Safe to source multiple times (idempotent).
# ============================================================================

# shellcheck source=lib/masking.sh
source "$(dirname "${BASH_SOURCE[0]}")/masking.sh"

# --- Logging ----------------------------------------------------------------
log_ts() { date '+%Y-%m-%d %H:%M:%S'; }
log()  { printf '[%s] ==> %s\n' "$(log_ts)" "$*"; }
warn() { printf '[%s] WARN: %s\n' "$(log_ts)" "$*" >&2; }
die()  { printf '[%s] ERROR: %s\n' "$(log_ts)" "$*" >&2; exit 1; }
diag() { printf '[%s] DIAG: %s\n' "$(log_ts)" "$*"; }

# --- dnf flags --------------------------------------------------------------
# Select dnf binary (prefer dnf5 if available)
if command -v dnf5 &>/dev/null; then
    export DNF_BIN="dnf5"
else
    export DNF_BIN="dnf"
fi

# Defense-in-depth: /etc/dnf/dnf.conf already carries install_weak_deps=False,
# but passing it on every invocation guarantees behaviour even if a script or
# transaction overrides the global default. Array form so elements are one-
# argv-each under `set -u`, and future flags can be added in one place.
if [[ -z "${DNF_SETOPT+x}" || "$(declare -p DNF_SETOPT 2>/dev/null)" != "declare -a"* ]]; then
    declare -ga DNF_SETOPT=(--setopt=install_weak_deps=False)
fi
if [[ -z "${DNF_OPTS+x}" || "$(declare -p DNF_OPTS 2>/dev/null)" != "declare -a"* ]]; then
    declare -ga DNF_OPTS=(--allowerasing --best)
fi
# String variant for legacy/debug visibility only. Do NOT use in commands.
export DNF_SETOPT_STR="${DNF_SETOPT[*]}"
export DNF_OPTS_STR="${DNF_OPTS[*]}"
```

---

## automation/lib/packages.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — Package extraction library
# Parses PACKAGES.md fenced code blocks tagged with ```packages-<category>
#
# Usage:
#   source automation/lib/packages.sh
#   install_packages "gnome"
# shellcheck source=lib/common.sh
#   install_packages_strict "kernel"   # fails if section is empty/missing

get_packages() {
    local category="$1"
    local packages_file="${2:-${PACKAGES_MD:-/ctx/PACKAGES.md}}"

    if [[ ! -f "$packages_file" ]]; then
        echo "[packages.sh] ERROR: $packages_file not found" >&2
        return 1
    fi

    # shellcheck disable=SC2001 # tr is intentionally used here to word-split packages
    sed -n "/^\`\`\`packages-${category}$/,/^\`\`\`$/{/^\`\`\`/d;/^$/d;/^#/d;p}" "$packages_file" \
        | tr '\n' ' '
}

get_packages_strict() {
    local result
    result=$(get_packages "$@")
    if [[ -z "$result" ]]; then
        echo "[packages.sh] ERROR: No packages found in section '$1'" >&2
        return 1
    fi
    echo "$result"
}

_PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${_PKG_DIR}/common.sh"

install_packages() {
    local category="$1"
    local packages_file="${2:-${PACKAGES_MD:-/ctx/PACKAGES.md}}"
    local packages
    packages=$(get_packages "$category" "$packages_file")
    if [[ -n "$packages" ]]; then
        echo "[packages.sh] Installing '$category' packages..."
        # Use subshell so set -e in parent doesn't kill entire script on failure.
        # shellcheck disable=SC2086 # $packages is intentionally word-split here
        ($DNF_BIN "${DNF_SETOPT[@]}" install -y "${DNF_OPTS[@]}" --skip-unavailable --exclude=PackageKit $packages) || {
            echo "[packages.sh] WARNING: Some '$category' packages failed to install" >&2
            echo "[packages.sh] Packages requested: $packages" >&2
        }
    else
        echo "[packages.sh] WARN: No packages in section '$category' — skipping"
    fi
}

install_packages_strict() {
    local category="$1"
    local packages_file="${2:-${PACKAGES_MD:-/ctx/PACKAGES.md}}"
    local packages
    packages=$(get_packages_strict "$category" "$packages_file") || return 1
    echo "[packages.sh] Installing '$category' packages (strict section)..."
    # shellcheck disable=SC2086 # $packages is intentionally word-split here
    $DNF_BIN "${DNF_SETOPT[@]}" install -y "${DNF_OPTS[@]}" --skip-unavailable --exclude=PackageKit $packages || {
        echo "[packages.sh] FATAL: Mandatory '$category' packages failed to install" >&2
        echo "[packages.sh] Packages requested: $packages" >&2
        return 1
    }
}

install_packages_optional() {
    local category="$1"
    local packages_file="${2:-${PACKAGES_MD:-/ctx/PACKAGES.md}}"

    # Check if section exists at all
    local raw_section
    raw_section=$(sed -n "/^\`\`\`packages-${category}$/,/^\`\`\`$/{/^\`\`\`/d;p}" "$packages_file")

    if [[ -z "$raw_section" ]]; then
        echo "[packages.sh] WARN: Section 'packages-${category}' not found — skipping"
        return 0
    fi

    # Check if ALL lines are comments (intentionally disabled)
    local uncommented
    uncommented=$(echo "$raw_section" | grep -v '^#' | grep -v '^$' || true)

    if [[ -z "$uncommented" ]]; then
        echo "[packages.sh] INFO: All packages in '${category}' are commented out (intentionally disabled)"
        return 0
    fi

    # Some packages are uncommented — install those
    local packages
    packages=$(get_packages "$category" "$packages_file")
    if [[ -n "$packages" ]]; then
        echo "[packages.sh] Installing optional '$category' packages..."
        # shellcheck disable=SC2086 # $packages is intentionally word-split here
        ($DNF_BIN "${DNF_SETOPT[@]}" install -y "${DNF_OPTS[@]}" --skip-unavailable --exclude=PackageKit $packages) || {
            echo "[packages.sh] WARNING: Some optional '$category' packages failed" >&2
        }
    fi
}
```

---

## automation/lib/masking.sh

```bash
#!/usr/bin/env bash
# ============================================================================
# automation/lib/masking.sh
# ----------------------------------------------------------------------------
# Credential masking and secure execution helpers.
# ============================================================================

# Internal array of strings to mask
declare -ga MASK_LIST=()

# Register a string to be masked in output
# Usage: add_mask "my-secret-string"
add_mask() {
    local secret="$1"
    if [[ -n "$secret" && "$secret" != "null" ]]; then
        # Avoid duplicates
        for m in "${MASK_LIST[@]}"; do
            [[ "$m" == "$secret" ]] && return 0
        done
        MASK_LIST+=("$secret")
    fi
}

# Register common sensitive environment variables
register_common_masks() {
    local vars=(
        GHCR_TOKEN
        GH_TOKEN
        GITHUB_TOKEN
        MIOS_PASSWORD
        MIOS_PASSWORD_HASH
        SIGNING_SECRET
        COSIGN_PASSWORD
    )
    for v in "${vars[@]}"; do
        if [[ -n "${!v:-}" ]]; then
            add_mask "${!v}"
        fi
    done
}

# Filter stdin to mask registered secrets
# Usage: some_command | mask_filter
mask_filter() {
    if [[ ${#MASK_LIST[@]} -eq 0 ]]; then
        cat
        return
    fi

    local sed_script=""
    for secret in "${MASK_LIST[@]}"; do
        # Escape characters that are special to sed's regex and the delimiter
        # We use '|' as the delimiter for 's' because it's less common in hashes
        # than '/', but we still must escape it if it appears in the secret.
        local escaped_secret=$(printf '%s' "$secret" | sed 's/[][\\.*^$|/]/\\&/g')
        sed_script+="s|$escaped_secret|[MASKED]|g;"
    done
    sed -u "$sed_script"
}

# Prompt for credentials if not set
# Usage: ensure_cred "GHCR_TOKEN" "Enter your GitHub Container Registry Token"
ensure_cred() {
    local var_name="$1"
    local prompt_msg="$2"
    if [[ -z "${!var_name:-}" ]]; then
        read -rsp "$prompt_msg: " val
        echo >&2 # Newline after silent read
        export "$var_name"="$val"
    fi
    add_mask "${!var_name}"
}

# Secure curl wrapper with optional credentials
# Usage: scurl [curl-args] URL
scurl() {
    local args=()
    local use_creds=false
    local url=""
    local is_binary=false
    
    # Simple parser to find the URL and check for binary download flags
    for arg in "$@"; do
        if [[ "$arg" =~ ^https?:// ]]; then
            url="$arg"
        elif [[ "$arg" == "-o" || "$arg" == "-O" || "$arg" == "--output" ]]; then
            is_binary=true
        fi
    done

    # Inherit credentials from environment if available and URL matches github/ghcr
    if [[ "$url" =~ github\.com|ghcr\.io ]]; then
        if [[ -n "${GH_TOKEN:-}" || -n "${GITHUB_TOKEN:-}" || -n "${GHCR_TOKEN:-}" ]]; then
            local token="${GH_TOKEN:-${GITHUB_TOKEN:-${GHCR_TOKEN:-}}}"
            # Use -H for token auth to avoid process list exposure of -u
            args+=("-H" "Authorization: token $token")
            add_mask "$token"
        fi
    fi

    if [[ "$is_binary" == "true" ]]; then
        curl "${args[@]}" "$@"
    else
        curl "${args[@]}" "$@" | mask_filter
    fi
}
```

# Layer 4b — Master orchestrator

---

## automation/build.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — Master build runner
# Executes all numbered scripts in order, then cleans up.
# Called from Containerfile RUN layer via bind mount.
#
# CHANGELOG v0.2.0:
#   - Standardized versioning across the entire stack.
#   - FIX: install_weakdeps=False (was True in v1.3 — contradicted docs)
#   - FIX: Safe arithmetic: VAR=$((VAR + 1)) not ((VAR++)) (set -e compat)
#   - Base: ucore-hci:stable-nvidia (Rawhide overlay in 01-repos.sh)
#   - Post-build validates malcontent-libs present (flatpak needs it)
#   - Footgun list includes malcontent-control/pam/tools
#   - PackageKit/gnome-tour removed via dnf (safe, no cascade)
#   - gnome-software KEPT (manages Flatpaks on immutable systems)
#   - malcontent-control hidden via NoDisplay (dnf remove cascades)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"
register_common_masks
export PACKAGES_MD="${PACKAGES_MD:-/ctx/PACKAGES.md}"
BUILD_LOG="/tmp/mios-build.log"

exec > >(mask_filter | tee -a "$BUILD_LOG") 2>&1

log_ts() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"
}

VERSION_STR="$(cat "${SCRIPT_DIR}/../VERSION" 2>/dev/null || cat /ctx/VERSION 2>/dev/null || echo 'v0.2.0')"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  MiOS ${VERSION_STR} — Building OS Image"
echo "  Base: ucore-hci:stable-nvidia + F44 + Rawhide kernel"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
log_ts "Build started"
log_ts "PACKAGES.MD : $PACKAGES_MD"
log_ts "SCRIPT_DIR  : $SCRIPT_DIR"
echo ""

if [[ ! -f "$PACKAGES_MD" ]]; then
    log_ts "FATAL: $PACKAGES_MD not found. Build context missing."
    exit 1
fi

# ── DNF config ──────────────────────────────────────────────────────────────
export SYSTEMD_OFFLINE=1
export container=podman

# ── Execute numbered scripts ────────────────────────────────────────────────
# Skip list:
#   08-system-files-overlay.sh  — called explicitly by the Containerfile BEFORE this script
#   37-ollama-prep.sh           — intentional local-only step (large model download; not for CI)
CONTAINERFILE_SCRIPTS="08-system-files-overlay.sh 37-ollama-prep.sh"

TOTAL_START=$SECONDS
SCRIPT_COUNT=0
SCRIPT_FAIL=0
FAILED_SCRIPTS=()

for script in "$SCRIPT_DIR"/[0-9][0-9]-*.sh; do
    SCRIPT_NAME="$(basename "$script")"
    if echo "$CONTAINERFILE_SCRIPTS" | grep -qF "$SCRIPT_NAME"; then
        log_ts "==> Skipping (Containerfile post-step): $SCRIPT_NAME"
        continue
    fi
    SCRIPT_COUNT=$((SCRIPT_COUNT + 1))
    echo "───────────────────────────────────────────────────────────────────"
    log_ts "==> STEP $SCRIPT_COUNT: $SCRIPT_NAME"
    echo "───────────────────────────────────────────────────────────────────"

    STEP_START=$SECONDS

    set +e
    bash "$script"
    SCRIPT_EXIT=$?
    set -e

    STEP_ELAPSED=$(( SECONDS - STEP_START ))

    if [[ $SCRIPT_EXIT -eq 0 ]]; then
        log_ts "✓ $SCRIPT_NAME completed (${STEP_ELAPSED}s)"
    else
        log_ts "✗ $SCRIPT_NAME FAILED (exit $SCRIPT_EXIT, ${STEP_ELAPSED}s)"
        SCRIPT_FAIL=$((SCRIPT_FAIL + 1))
        FAILED_SCRIPTS+=("$SCRIPT_NAME")
    fi
    echo ""
done

# ── Bloat Removal (active removal approach) ──────────
# Per user mandate: remove anything that's bloat.
# malcontent-libs must remain (gnome-control-center hard dep), but
# malcontent-control/pam/tools are UI/CLI components we don't need.
# Leaf apps like gnome-tour and gnome-initial-setup are safe to remove.
echo ""
log_ts "==> Removing known bloat packages..."
BLOAT_PACKAGES=$(source "${SCRIPT_DIR}/lib/packages.sh"; get_packages "bloat")
if [[ -n "$BLOAT_PACKAGES" ]]; then
    $DNF_BIN "${DNF_SETOPT[@]}" remove -y "${DNF_OPTS[@]}" $BLOAT_PACKAGES 2>/dev/null || true
else
    log_ts "NOTE: No bloat packages defined in manifest."
fi

# ── Suppress remaining ucore base bloat (mask/hide) ──────────
# For things that can't be easily removed without cascade, hide them.
echo ""
log_ts "==> Suppressing remaining base image bloat (mask/hide)..."
systemctl mask packagekit.service 2>/dev/null || true
for app in gnome-tour gnome-initial-setup; do
    desktop="/usr/share/applications/${app}.desktop"
    if [ -f "$desktop" ]; then
        # Ensure target directory exists for NoDisplay override
        mkdir -p /usr/local/share/applications
        grep -v '^NoDisplay=' "$desktop" > "/usr/local/share/applications/${app}.desktop"
        echo "NoDisplay=true" >> "/usr/local/share/applications/${app}.desktop"
        echo "  ✓ Hidden: $app (NoDisplay=true)"
    fi
done

# ── Post-build validation ──────────────────────────────────────────────────
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log_ts "Post-build validation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

source "${SCRIPT_DIR}/lib/packages.sh"
CRITICAL_PACKAGES=($(get_packages "critical"))
VALIDATION_FAIL=0
if [[ ${#CRITICAL_PACKAGES[@]} -eq 0 ]]; then
    log_ts "WARNING: No critical packages found in manifest validation section!"
else
    for pkg in "${CRITICAL_PACKAGES[@]}"; do
        if rpm -q "$pkg" > /dev/null 2>&1; then
            echo "  ✓ $pkg"
        else
            echo "  ✗ $pkg MISSING"
            VALIDATION_FAIL=$((VALIDATION_FAIL + 1))
        fi
    done
fi

# Hardware & Driver Verification (Moved from legacy 41-akmods-copy.sh)
if rpm -qa 'kmod-nvidia*' 2>/dev/null | grep -q . ; then
    echo "  ✓ NVIDIA kmod(s) present"
else
    echo "  ⚠ NVIDIA kmod(s) MISSING (using ucore base?)"
fi

if compgen -G "/etc/pki/akmods/certs/*.der" > /dev/null; then
    echo "  ✓ MOK certs present"
fi

# RTX 50 Blackwell Karg Check
if grep -q "vfio_pci.disable_idle_d3=1" /usr/lib/bootc/kargs.d/*.toml 2>/dev/null; then
    echo "  ✓ Blackwell VFIO workaround present in kargs.d"
else
    echo "  ⚠ Blackwell VFIO workaround missing in kargs.d"
fi

# malcontent-libs MUST be present (flatpak links against libmalcontent-0.so.0)
if rpm -q malcontent-libs > /dev/null 2>&1; then
    echo "  ✓ malcontent-libs (required by flatpak)"
else
    echo "  ⚠ malcontent-libs MISSING — flatpak may break"
fi

# gnome-software: expected (manages Flatpaks on immutable systems)
if rpm -q gnome-software > /dev/null 2>&1; then
    echo "  ✓ gnome-software (Flatpak manager)"
fi

# Footgun check — these should NOT be present after bloat removal
FOOTGUN_PACKAGES=($(get_packages "bloat"))
for pkg in "${FOOTGUN_PACKAGES[@]}"; do
    if rpm -q "$pkg" > /dev/null 2>&1; then
        echo "  ⚠ FOOTGUN: $pkg is installed (should not be in build-up image)"
    fi
done

if [[ $VALIDATION_FAIL -gt 0 ]]; then
    log_ts "WARNING: $VALIDATION_FAIL critical packages missing!"
fi

# ── Technical Invariant Validation ──
echo ""
log_ts "==> Running Technical Invariant Validation (99-postcheck.sh)..."
if [[ -f "${SCRIPT_DIR}/99-postcheck.sh" ]]; then
    bash "${SCRIPT_DIR}/99-postcheck.sh"
else
    log_ts "⚠ automation/99-postcheck.sh not found — skipping"
fi

# ── Cleanup ─────────────────────────────────────────────────────────────────

# Preserve logs in an immutable path for Day-2 diagnostics
echo ""
log_ts "Preserving build logs to /usr/lib/mios/logs/..."
mkdir -p /usr/lib/mios/logs
cp -v /var/log/dnf5.log* /var/log/hawkey.log /tmp/mios-build.log /usr/lib/mios/logs/ 2>/dev/null || true

echo ""
log_ts "Cleaning up..."
$DNF_BIN "${DNF_SETOPT[@]}" clean all
rm -rf /var/cache/dnf /var/cache/libdnf5 /tmp/geist-font /tmp/*.tar* /tmp/*.rpm 2>/dev/null || true
rm -rf /usr/share/doc/* /usr/share/man/* /usr/share/info/* 2>/dev/null || true
rm -rf /usr/share/gnome/help/* /usr/share/help/* 2>/dev/null || true

# Clean bootc lint triggers (logs now preserved in /usr/lib/mios/logs)
rm -f /var/log/dnf5.log* /var/log/hawkey.log 2>/dev/null || true
rm -rf /run/ceph /run/cockpit /run/k3s /tmp/* 2>/dev/null || true
rm -f /var/lib/systemd/random-seed 2>/dev/null || true

rm -f /tmp/mios-build.log

# ── Summary ─────────────────────────────────────────────────────────────────
TOTAL_ELAPSED=$(( SECONDS - TOTAL_START ))
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  BUILD SUMMARY"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Scripts:   $SCRIPT_COUNT executed, $SCRIPT_FAIL failed"
if [[ $SCRIPT_FAIL -gt 0 ]]; then
    echo "  Failed:    ${FAILED_SCRIPTS[*]}"
fi
echo "  Packages:  $VALIDATION_FAIL critical missing"
echo "  Duration:  ${TOTAL_ELAPSED}s ($((TOTAL_ELAPSED / 60))m $((TOTAL_ELAPSED % 60))s)"
echo "  Version:   $VERSION_STR"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if [[ $SCRIPT_FAIL -gt 0 ]]; then
    log_ts "FATAL: $SCRIPT_FAIL scripts failed — review build output above"
    exit 1
fi
```

# Layer 4c–j — Numbered phases (execution order)

---

## automation/01-repos.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 01-repos: Fedora 44 overlay on ucore (base kernel preserved)
#
# FIX v0.2.0: Two-phase distro-sync to handle filesystem scriptlet failure.
# The filesystem package's lua %posttrans fails in container builds, aborting
# the entire 1162-package transaction. Without this fix, the system boots with
# F43 core libs but F44 desktop packages — a broken ABI mismatch.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/packages.sh"
source "${SCRIPT_DIR}/lib/common.sh"

# ── Global DNF config ───────────────────────────────────────────────────────
echo "[01-repos] Setting install_weak_deps=False globally..."
DNF_CONF="/usr/lib/dnf/dnf.conf"
if [ ! -f "$DNF_CONF" ]; then
    DNF_CONF="/etc/dnf/dnf.conf"
fi

if [ -f "$DNF_CONF" ]; then
    if ! grep -q '^install_weak_deps=False' "$DNF_CONF"; then
        sed -i '/^install_weak_deps=/d' "$DNF_CONF" 2>/dev/null || true
        echo "install_weak_deps=False" >> "$DNF_CONF"
    fi
fi


# ── Protect Base Repos from Third-Party Ties ───────────────────────────────
echo "[01-repos] Elevating base repos to priority 98..."
if [ -d /etc/yum.repos.d ]; then
    for repo in /etc/yum.repos.d/fedora*.repo /etc/yum.repos.d/ublue-os*.repo; do
        if [ -f "$repo" ] && ! grep -q '^priority=' "$repo"; then
            sed -i '/^\[.*\]/a priority=98' "$repo"
        fi
    done
fi

# ── Fedora 44 repo overlay ─────────────────────────────────────────────────
echo "[01-repos] Adding Fedora 44 repository..."
cat > /etc/yum.repos.d/fedora-44.repo <<'EOREPO'
[fedora-44]
name=Fedora 44 - $basearch
metalink=https://mirrors.fedoraproject.org/metalink?repo=fedora-44&arch=$basearch
enabled=1
countme=1
metadata_expire=6h
repo_gpgcheck=0
type=rpm
gpgcheck=0
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-fedora-44-$basearch
skip_if_unavailable=False
priority=95

[fedora-44-updates]
name=Fedora 44 Updates - $basearch
metalink=https://mirrors.fedoraproject.org/metalink?repo=updates-released-f44&arch=$basearch
enabled=1
countme=1
metadata_expire=6h
repo_gpgcheck=0
type=rpm
gpgcheck=0
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-fedora-44-$basearch
skip_if_unavailable=True
priority=95
EOREPO

# ── Distro-sync to Fedora 44 (TWO-PHASE) ───────────────────────────────────
echo "[01-repos] Distro-sync to Fedora 44 (this takes a while)..."

echo "[01-repos] Phase 1: Pre-upgrading DNF, RPM, and core systemd/filesystem..."
# Isolate the problematic filesystem scriptlet and core package upgrades.
# By doing this first, a filesystem %posttrans failure won't abort the entire
# 1100+ package distro-sync transaction, preventing a fractured RPM database.
$DNF_BIN "${DNF_SETOPT[@]}" upgrade -y --allowerasing --best \
    dnf rpm fedora-release fedora-repos filesystem systemd glibc dbus-broker 2>&1 || {
    echo "[01-repos] NOTE: Pre-upgrade had warnings (likely filesystem lua scriptlet), continuing..."
}

echo "[01-repos] Phase 2: Distro-upgrade and userspace alignment..."
# We use 'upgrade --refresh' to ensure we have fresh metadata and catch latest
# userspace patches, followed by 'distro-sync' to align the remainder with F44.
$DNF_BIN "${DNF_SETOPT[@]}" --setopt=excludepkgs="shim-*,kernel*" upgrade --refresh -y || true
$DNF_BIN "${DNF_SETOPT[@]}" --setopt=excludepkgs="shim-*,kernel*" distro-sync -y --best --allowerasing || {
    echo "[01-repos] WARNING: Distro-sync to Fedora 44 failed. Repository might be unreachable."
    echo "[01-repos] Continuing with base image packages..."
}

echo "[01-repos] Verifying core package versions..."
rpm -q systemd glibc dbus-broker filesystem || true

# ── Pre-install F44 ca-certificates ────────────────────────────────────────
echo "[01-repos] Ensuring F44 ca-certificates is installed..."
$DNF_BIN "${DNF_SETOPT[@]}" install -y ca-certificates p11-kit-trust 2>&1 | tail -5 || true

# ── RPMFusion ───────────────────────────────────────────────────────────────
echo "[01-repos] Installing RPMFusion Free + Nonfree for Rawhide..."
$DNF_BIN "${DNF_SETOPT[@]}" install -y \
    "https://mirrors.rpmfusion.org/free/fedora/rpmfusion-free-release-rawhide.noarch.rpm" \
    "https://mirrors.rpmfusion.org/nonfree/fedora/rpmfusion-nonfree-release-rawhide.noarch.rpm" \
    2>&1 | tail -15 || true


for repo in rpmfusion-free rpmfusion-free-updates rpmfusion-nonfree rpmfusion-nonfree-updates; do
    if [ -f "/etc/yum.repos.d/${repo}.repo" ]; then
        if ! grep -q '^priority=' "/etc/yum.repos.d/${repo}.repo"; then
            sed -i '/^\['"$repo"'\]/a priority=90' "/etc/yum.repos.d/${repo}.repo"
        fi
    fi
done

# ── Terra repo ──────────────────────────────────────────────────────────────
echo "[01-repos] Installing Terra repo..."
$DNF_BIN "${DNF_SETOPT[@]}" install -y --repofrompath 'terra,https://repos.fyralabs.com/terra44' \
    --setopt='terra.gpgcheck=1' --setopt='terra.gpgkey=https://repos.fyralabs.com/terra44/key.asc' \
    terra-release 2>&1 | tail -10 || true

if [ -f /etc/yum.repos.d/terra.repo ]; then
    if ! grep -q '^priority=' /etc/yum.repos.d/terra.repo; then
        sed -i '/^\[terra\]/a priority=85' /etc/yum.repos.d/terra.repo
    fi
    # BIB (bootc-image-builder) runs in a CentOS Stream 10 container and cannot
    # resolve file:// GPG key paths that live inside the MiOS image.
    # Rewrite to https:// and disable repo_gpgcheck so Anaconda ISO manifest
    # generation succeeds without "Couldn't open file RPM-GPG-KEY-terra44".
    sed -i 's|^gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-terra44|gpgkey=https://repos.fyralabs.com/terra44/key.asc|' \
        /etc/yum.repos.d/terra.repo
    sed -i 's/^repo_gpgcheck=1/repo_gpgcheck=0/' /etc/yum.repos.d/terra.repo
fi

# ── CrowdSec repo ──────────────────────────────────────────────────────────
echo "[01-repos] Adding CrowdSec repo..."
cat > /etc/yum.repos.d/crowdsec.repo <<'EOREPO'
[crowdsec]
name=CrowdSec
baseurl=https://packagecloud.io/crowdsec/crowdsec/rpm_any/rpm_any/$basearch
enabled=1
gpgcheck=0
repo_gpgcheck=0
priority=80
EOREPO

# ── NVIDIA Container Toolkit repo ──────────────────────────────────────────
echo "[01-repos] Adding NVIDIA Container Toolkit repo..."
if ! [ -f /etc/yum.repos.d/nvidia-container-toolkit.repo ]; then
    cat > /etc/yum.repos.d/nvidia-container-toolkit.repo <<'EOREPO'
[nvidia-container-toolkit]
name=NVIDIA Container Toolkit
baseurl=https://nvidia.github.io/libnvidia-container/stable/rpm/$basearch
enabled=1
gpgcheck=1
gpgkey=https://nvidia.github.io/libnvidia-container/gpgkey
priority=70
EOREPO
fi

# Ensure all repo files have correct permissions
chmod 0644 /etc/yum.repos.d/*.repo 2>/dev/null || true

echo "[01-repos] Done. Protected base + F44 userspace + RPMFusion + Terra + CrowdSec."
echo "[01-repos] Priority: CrowdSec(80) < Terra(85) < RPMFusion(90) < F44(95) < Base(98) < Default(99)"
```

---

## automation/02-kernel.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 02-kernel: Kernel extras + development headers
# The base fedora-bootc:rawhide image ships the newest kernel with a working
# initramfs. We NEVER upgrade the base kernel packages inside the container —
# doing so triggers dracut under the tmpfs mount, which fails with
# "Invalid cross-device link (os error 18)" and produces a broken initramfs.
#
# This script installs ONLY the extras needed for:
#   - akmod-nvidia (kernel-devel, kernel-headers)
#   - DKMS/kvmfr (kernel-devel)
#   - kernel-modules-extra (VFIO, USB, storage modules not in base)
#   - kernel-tools (cpupower, turbostat, perf)
#
# CHANGELOG v0.2.0:
#   - REMOVED kernel/kernel-core/kernel-modules/kernel-modules-core
#     (base image already has them — upgrading broke dracut)
#   - kernel-modules-extra ensures VFIO/USB/storage modules are present
#   - kernel-devel enables akmod-nvidia and DKMS builds
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/packages.sh"

install_packages_strict "kernel"

# Capture KVER for akmod builds later.
# The base image kernel is the only one installed; grab it.
KVER=$(find /usr/lib/modules/ -mindepth 1 -maxdepth 1 -printf "%f\n" | sort -V | tail -1) # Explicitly use /usr
export KVER
echo "[02-kernel] Kernel version: $KVER"
echo "$KVER" > /tmp/mios-kver

# Verify kernel modules directory exists (akmod build will fail without it)
if [[ ! -d "/usr/lib/modules/$KVER" ]]; then # Explicitly check /usr
    echo "[02-kernel] FATAL: /usr/lib/modules/$KVER does not exist" # Explicitly refer to /usr
    exit 1
fi

# Verify kernel-devel is installed (akmod-nvidia needs it)
if [[ ! -d "/usr/lib/modules/$KVER/build" ]]; then
    echo "[02-kernel] WARNING: /usr/lib/modules/$KVER/build missing — akmod may fail"
fi

echo "[02-kernel] Kernel extras for $KVER installed successfully."
```

---

## automation/05-enable-external-repos.sh

```bash
#!/usr/bin/env bash
# ============================================================================
# automation/05-enable-external-repos.sh
# ----------------------------------------------------------------------------
# Enable external DNF repositories for MiOS (Fedora 44 / Rawhide).
# Idempotent; fails fast; uses ${DNF_SETOPT[@]} from automation/lib/common.sh.
# RPM Fusion is intentionally NOT handled here — see 01-repos.sh.
#
# v2.3 CHANGES:
#   - Added Kubernetes stable v1.32 repo (kubectl not in Fedora repos).
#   - Added ublue-os/packages COPR (uupd + greenboot; required by 43-uupd-installer.sh).
#
# v0.2.0 CHANGES:
#   - removed redundant RPM Fusion install block (was using `rpm -E %fedora`
#     which yielded 41/43 from the base image and clobbered 01-repos.sh's
#     explicit F44 pin).
#   - replaced dnf5 with dnf throughout (consistency with 01-repos.sh and
#     lib/packages.sh; on F44 `dnf` is dnf5 via symlink anyway).
#   - adopted ${DNF_SETOPT[@]} for every mutating invocation.
# ============================================================================
set -euo pipefail

# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"

REPO_DIR=/etc/yum.repos.d

# --- 1. Terra (fyralabs) ----------------------------------------------------
# Patched WINE/Mesa/miscellaneous packages missing from Fedora + RPM Fusion.
if [[ ! -f "${REPO_DIR}/terra.repo" ]]; then
    log "enabling Terra repo (fyralabs)"
    scurl -fsSL \
        https://github.com/terrapkg/subatomic-repos/raw/main/terra.repo \
        -o "${REPO_DIR}/terra.repo"
else
    log "Terra repo already present — skipping"
fi

# --- 2. VSCodium (FOSS) ------------------------------------------------------
if [[ ! -f "${REPO_DIR}/vscodium.repo" ]]; then
    log "enabling VSCodium repo (FOSS)"
    scurl -fsSL https://gitlab.com/paulcarroty/vscodium-deb-rpm-repo/raw/master/pub.gpg -o /tmp/vscodium.gpg
    rpm --import /tmp/vscodium.gpg && rm -f /tmp/vscodium.gpg
    cat > "${REPO_DIR}/vscodium.repo" <<'EOF'
[vscodium]
name=VSCodium
baseurl=https://download.vscodium.com/rpms/
enabled=1
autorefresh=1
type=rpm-md
gpgcheck=1
gpgkey=https://gitlab.com/paulcarroty/vscodium-deb-rpm-repo/raw/master/pub.gpg
EOF
else
    log "VSCodium repo already present — skipping"
fi

# --- 7. Kubernetes stable v1.32 (kubectl) -----------------------------------
# kubectl is NOT in standard Fedora repos — must come from the Kubernetes
# project's own RPM repository. Pinned to v1.32 (current stable).
# Only kubectl is installed from here; kubeadm/kubelet are intentionally
# excluded (k3s is used for the cluster runtime, not kubeadm).
if [[ ! -f "${REPO_DIR}/kubernetes.repo" ]]; then
    log "enabling Kubernetes stable v1.32 repo"
    cat > "${REPO_DIR}/kubernetes.repo" <<'EOF'
[kubernetes]
name=Kubernetes
baseurl=https://pkgs.k8s.io/core:/stable:/v1.32/rpm/
enabled=1
gpgcheck=1
gpgkey=https://pkgs.k8s.io/core:/stable:/v1.32/rpm/repodata/repomd.xml.key
repo_gpgcheck=1
exclude=kubelet kubeadm cri-tools kubernetes-cni
EOF
else
    log "Kubernetes repo already present — skipping"
fi

# --- 8. ublue-os/packages COPR (uupd + greenboot) ---------------------------
# uupd and greenboot ship from the Universal Blue packages COPR.
# 43-uupd-installer.sh explicitly requires this repo to be present first.
# Using Fedora 44 repo endpoint; COPR auto-publishes new packages as they land.
if [[ ! -f "${REPO_DIR}/ublue-os-packages.repo" ]]; then
    log "enabling ublue-os/packages COPR (uupd + greenboot)"
    scurl -fsSL \
        "https://copr.fedorainfracloud.org/coprs/ublue-os/packages/repo/fedora-44/ublue-os-packages-fedora-44.repo" \
        -o "${REPO_DIR}/ublue-os-packages.repo"
    # Lower priority than Fedora base so Fedora wins on conflicting packages.
    if ! grep -q '^priority=' "${REPO_DIR}/ublue-os-packages.repo"; then
        sed -i '/^\[/a priority=75' "${REPO_DIR}/ublue-os-packages.repo"
    fi
else
    log "ublue-os/packages COPR already present — skipping"
fi

# ── Waydroid (Aleasto) ───────────────────────────────────────────────────
if ! [ -f /etc/yum.repos.d/_copr:copr.fedorainfracloud.org:aleasto:waydroid.repo ]; then
    log "enabling aleasto/waydroid COPR (GNOME 50 fix)"
    $DNF_BIN "${DNF_SETOPT[@]}" copr enable -y aleasto/waydroid
else
    log "aleasto/waydroid COPR already present — skipping"
fi

log "external repos enabled; refreshing metadata"
$DNF_BIN "${DNF_SETOPT[@]}" makecache -y

log "05-enable-external-repos.sh complete"
```

---

## automation/08-system-files-overlay.sh

```bash
#!/bin/bash
# ============================================================================
# automation/08-system-files-overlay.sh - MiOS v0.2.0
# ----------------------------------------------------------------------------
# Overlay /ctx/ onto the rootfs during the Containerfile build,
# correctly handling the /usr/local -> /var/usrlocal symlink.
#
# v0.2.0 Architecture: Rootfs-Native
#   - Sources now directly from /ctx/usr, /ctx/etc, /ctx/var, /ctx/home
# ============================================================================
set -euo pipefail

# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"

CTX="${CTX:-/ctx}"

log "08-overlay: starting Rootfs-Native overlay"

# --- Stage 1: /usr (everything except /usr/local) --------------------------
if [[ -d "${CTX}/usr" ]]; then
    log "  stage 1: overlay usr content (excluding /usr/local)"
    tar -C "${CTX}/usr" -cf - --exclude='./local' . | tar -C /usr --no-overwrite-dir -xf -
fi

# --- Stage 2: /usr/local via /var/usrlocal ---------------------------------
if [[ -d "${CTX}/usr/local" ]]; then
    log "  stage 2: overlay /usr/local content"
    if [[ -L /usr/local ]]; then
        log "    /usr/local is a symlink -> $(readlink /usr/local); writing through"
        install -d -m 0755 /var/usrlocal
        tar -C "${CTX}/usr/local" -cf - . | tar -C /var/usrlocal --no-overwrite-dir -xf -
    else
        log "    /usr/local is a real directory; writing directly"
        tar -C "${CTX}/usr/local" -cf - . | tar -C /usr/local --no-overwrite-dir -xf -
    fi
fi

# --- Stage 3: /etc (System Config Templates) -------------------------------
if [[ -d "${CTX}/etc" ]]; then
    log "  stage 3: overlay etc content"
    tar -C "${CTX}/etc" -cf - . | tar -C /etc --no-overwrite-dir -xf -
fi

# --- Stage 4: /var (Mutable System State Templates) ------------------------
# DEPRECATED: /var population via tar overlay violates zero-trust immutability.
# All mandatory /var structure must be declared in /usr/lib/tmpfiles.d/*.conf.
# if [[ -d "${CTX}/var" ]]; then
#     log "  stage 4: overlay var content"
#     tar -C "${CTX}/var" -cf - . | tar -C /var --no-overwrite-dir -xf -
# fi

# --- Stage 5: /home (User Space Templates) ---------------------------------
if [[ -d "${CTX}/home" ]]; then
    log "  stage 5: overlay home content"
    mkdir -p /var/home
    tar -C "${CTX}/home" -cf - . | tar -C /var/home --no-overwrite-dir -xf -
fi

# Normalize permissions on systemd unit and config files.
log "08-overlay: normalizing systemd file permissions"
find /usr/lib/systemd -type f \( -name "*.service" -o -name "*.socket" -o -name "*.timer" -o -name "*.mount" -o -name "*.conf" -o -name "*.target" -o -name "*.path" -o -name "*.slice" -o -name "*.preset" -o -name "*.automount" -o -name "*.swap" \) -exec chmod 644 {} \; 2>/dev/null || true
find /usr/lib/systemd -type d -exec chmod 755 {} \; 2>/dev/null || true

# Logically Bound Images
QDIR="/usr/share/containers/systemd"
BDIR="/usr/lib/bootc/bound-images.d"
if [[ -d "${QDIR}" ]]; then
    install -d -m 0755 "${BDIR}"
    shopt -s nullglob
    for q in "${QDIR}"/*.container; do
        name="$(basename "$q")"
        ln -sf "${QDIR}/${name}" "${BDIR}/${name}"
        log "  LBI: bound ${name}"
    done
    shopt -u nullglob
fi

# ═══ Pathing Compatibility ═══
log "08-overlay: applying pathing compatibility symlinks"

# 1. WSL2 looks for /etc/wsl.conf, but we store it in /usr/lib/wsl.conf for immutability
if [[ -f /usr/lib/wsl.conf ]]; then
    ln -sf /usr/lib/wsl.conf /etc/wsl.conf
    log "  WSL: symlinked /etc/wsl.conf -> /usr/lib/wsl.conf"
fi

# 2. Standardize /home to /var/home (FCOS/bootc style)
if [ ! -L /home ] && [ -d /home ] && [ ! "$(ls -A /home)" ]; then
    rm -rf /home
    ln -sf /var/home /home
    log "  Path: symlinked /home -> /var/home"
elif [ ! -e /home ]; then
    ln -sf /var/home /home
    log "  Path: created /home -> /var/home symlink"
fi

log "08-overlay: relabeling overlaid files"
restorecon -RFv /usr/ 2>/dev/null || true
restorecon -RFv /etc/ 2>/dev/null || true

log "08-overlay: complete"
```

---

## automation/10-gnome.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 10-gnome: GNOME 50 desktop — PURE BUILD-UP
#
# STRATEGY: ucore has ZERO GNOME packages. We install exactly what we need.
# With install_weakdeps=False (set globally in 01-repos.sh), only hard deps
# get pulled in. This means:
#   - malcontent-libs comes in (gnome-control-center hard dep) — CORRECT
#   - malcontent-control/pam/tools do NOT come in (weak deps) — CORRECT
#   - No GNOME bloat apps get installed — nothing to remove
#
# The ~25 core packages from the docs produce a fully functional GNOME 50
# Wayland desktop with GDM, all portals, audio, Bluetooth, networking,
# security, and proper theming across GTK3/GTK4/Qt.
#
# CHANGELOG v0.2.0:
#   - MANDATORY Bibata cursor download — retries 3x, FAILS BUILD if missing
#   - dconf profiles for user + GDM added to 
#   - Flatpak: 7 apps (added Flatseal + LocalSend)
#   - adw-gtk3 theme for GTK3 visual consistency
set -euo pipefail
# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/packages.sh"

# ═════════════════════════════════════════════════════════════════════════════
# GNOME 50 — Install from PACKAGES.md (build-up, NOT strip-down)
# ═════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Installing GNOME 50 desktop (pure build-up)..."
install_packages "gnome"

# Optional GNOME Core Apps (all commented out by default in PACKAGES.md)
install_packages_optional "gnome-core-apps"

# ═════════════════════════════════════════════════════════════════════════════
# Localsearch/tracker — disable indexing without removing
# Removing localsearch breaks Nautilus search + Activities Overview.
# Hide via autostart overrides in usr/share/xdg/autostart/
# ═════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Disabling localsearch/tracker indexing (keep package, hide autostart)..."

# ═════════════════════════════════════════════════════════════════════════════
# Qt Adwaita theming — required for Qt apps to match GNOME look
# Managed via usr/lib/environment.d/60-mios-qt-adwaita.conf
# ═════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Setting Qt Adwaita environment variables (managed via overlay)..."

# ═════════════════════════════════════════════════════════════════════════════
# Geist Font (Vercel)
# ═════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Installing Geist font family..."
mkdir -p /usr/share/fonts/geist
git clone --depth=1 https://github.com/vercel/geist-font.git /tmp/geist-font 2>/dev/null || true
if [ -d /tmp/geist-font ]; then
    find /tmp/geist-font \( -name "*.otf" -o -name "*.ttf" \) -exec cp {} /usr/share/fonts/geist/ \; 2>/dev/null || true
    rm -rf /tmp/geist-font
fi
fc-cache -f /usr/share/fonts/geist 2>/dev/null || true

# ═════════════════════════════════════════════════════════════════════════════
# Bibata Cursor Theme — MANDATORY (build fails if download fails)
#
# The cursor shows as a SQUARE when:
#   - /usr/share/icons/Bibata-Modern-Classic/ doesn't exist (download failed)
#   - /usr/share/icons/default/index.theme points to nonexistent theme
#   - dconf cursor-theme references a theme with no files
#
# FIX: Retry download 3 times. VERIFY the cursors directory exists.
#      FAIL THE BUILD if cursors are missing — a square cursor is unacceptable.
# ═════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Installing Bibata-Modern-Classic cursor (MANDATORY)..."
BIBATA_VER=""
BIBATA_FALLBACK="2.0.7"

# Try GitHub API for latest release tag (strips leading 'v')
# v0.2.0: Wrap in subshell + || true to prevent pipefail from killing the script if API is down
BIBATA_VER=$( (scurl -sL -H "Accept: application/vnd.github+json" "https://api.github.com/repos/ful1e5/Bibata_Cursor/releases/latest" \
    | grep -m1 '"tag_name"' | sed 's/.*"v\?\([^"]*\)".*/\1/') 2>/dev/null || true)

# Fallback if API fails (rate limit, network issue)
if [ -z "$BIBATA_VER" ]; then
    BIBATA_VER="$BIBATA_FALLBACK"
    echo "[10-gnome]   GitHub API unavailable — using fallback v${BIBATA_VER}"
else
    echo "[10-gnome]   Latest release: v${BIBATA_VER}"
fi

BIBATA_URL="https://github.com/ful1e5/Bibata_Cursor/releases/download/v${BIBATA_VER}/Bibata-Modern-Classic.tar.xz"
BIBATA_DIR="/usr/share/icons/Bibata-Modern-Classic"
mkdir -p /usr/share/icons

# Download with retries — DO NOT silence errors
BIBATA_OK=0
for attempt in 1 2 3; do
    echo "[10-gnome]   Download attempt $attempt/3..."
    if scurl -fSL --retry 3 --retry-delay 5 "$BIBATA_URL" -o /tmp/bibata.tar.xz; then
        if tar -xf /tmp/bibata.tar.xz -C /usr/share/icons/; then
            rm -f /tmp/bibata.tar.xz
            BIBATA_OK=1
            break
        fi
    fi
    echo "[10-gnome]   Attempt $attempt failed, retrying..."
    sleep 5
done

# VERIFY cursor files actually exist — log warning if missing but DO NOT fail build
if [ "$BIBATA_OK" -eq 0 ] || [ ! -d "$BIBATA_DIR/cursors" ]; then
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  WARNING: Bibata cursor theme download FAILED after 3 attempts"
    echo "  URL: $BIBATA_URL"
    echo "  The cursor will show as a SQUARE until the theme is installed."
    echo "  This failure is non-fatal for the build; users can install later."
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
else
    echo "[10-gnome] ✓ Bibata cursor installed: $(find "$BIBATA_DIR/cursors/" -mindepth 1 -maxdepth 1 | wc -l) cursors"
fi

# Comprehensive cursor default — every layer that reads cursor theme
# Managed via usr/share/icons/default/index.theme
# and usr/share/X11/icons/default/index.theme

# 3. update-alternatives for x-cursor-theme (Fedora cursor resolution)
if [ -d "$BIBATA_DIR/cursors" ]; then
    update-alternatives --install /usr/share/icons/default/index.theme \
        x-cursor-theme /usr/share/icons/Bibata-Modern-Classic/cursor.theme 100 2>/dev/null || true
    echo "[10-gnome] ✓ x-cursor-theme alternative set to Bibata"
fi

# 4. Symlink into /usr/share/cursors/xorg-x11 (legacy X11 cursor path)
mkdir -p /usr/share/cursors/xorg-x11
ln -sf /usr/share/icons/Bibata-Modern-Classic /usr/share/cursors/xorg-x11/Bibata-Modern-Classic 2>/dev/null || true

# 5. GDM user cursor — ensure cursor files are world-readable
chmod -R a+rX "$BIBATA_DIR" 2>/dev/null || true

# 6. Xresources fallback (oldest X11 cursor method)
# Managed via usr/lib/X11/Xresources


# ═══════════════════════════════════════════════════════════════════════════════
# Phosh — Mobile session for portrait/tablet remote access
# ═══════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Installing Phosh mobile session..."
install_packages_optional "phosh"
# Make session wrapper executable
chmod +x /usr/local/bin/phosh-session-wrapper 2>/dev/null || true
# ═════════════════════════════════════════════════════════════════════════════
# Flatpak Remotes
# Disable filtered Fedora remote, use unfiltered Flathub for full catalog
# ═════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Configuring Flatpak remotes..."
if command -v flatpak &>/dev/null; then
    flatpak remote-add --system --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo || true
    flatpak remote-add --system --if-not-exists flathub-beta https://flathub.org/beta-repo/flathub-beta.flatpakrepo || true
    flatpak remote-add --system --if-not-exists gnome-nightly https://nightly.gnome.org/gnome-nightly.flatpakrepo 2>/dev/null || true
    flatpak remote-modify --system --disable fedora 2>/dev/null || true
else
    echo "[10-gnome] WARN: flatpak binary not found, skipping remote configuration"
fi

# ═════════════════════════════════════════════════════════════════════════════
# Essential Flatpaks
# ═════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Flatpaks will be installed on first boot (mios-flatpak-install.service)..."
# NOTE: mios-flatpak-install.service is enabled in Containerfile STEP D
# (unit file lives in , not available during script execution)

exit 0

```

---

## automation/11-hardware.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 11-hardware: GPU drivers (Mesa + AMD ROCm + Intel + NVIDIA)
#
# NVIDIA strategy (v0.2.0):
#   Primary:  ucore-hci:stable-nvidia ships pre-signed kmods for the base
#             kernel. If modinfo finds them for `uname -r`, we keep them.
#   Fallback: akmod rebuild from RPMFusion (requires matching kernel-devel).
#             If that fails or kernel-devel is unavailable, we accept no
#             NVIDIA acceleration - image still works for everything else.
#
# Mesa (AMD/Intel/software fallback) and ROCm + intel-compute-runtime are
# installed from PACKAGES.md. They have no kernel-version coupling.
#
# CHANGELOG:
#   v0.2.0: Dropped COPY-layer fallback. ucore-hci IS already built from
#           ublue's akmods-nvidia pipeline - copying those same RPMs on top
#           would create RPM conflicts, not redundancy. Kernel-mismatch
#           recovery falls to akmod rebuild + graceful skip.
#   v0.2.0: (attempted COPY-layer, reverted)
#   v2.0:   NVIDIA akmod baseline removed (ucore base provides pre-signed)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/packages.sh"

KVER=$(cat /tmp/mios-kver 2>/dev/null || find /lib/modules/ -mindepth 1 -maxdepth 1 -printf "%f\n" | sort -V | tail -1)

# ── Mesa (AMD / Intel / software fallback) ──────────────────────────────────
echo "[11-hardware] Installing Mesa GPU stack..."
install_packages_strict "gpu-mesa"

# ── AMD ROCm (fault-tolerant) ───────────────────────────────────────────────
echo "[11-hardware] Installing ROCm (optional)..."
install_packages "gpu-amd-compute"

# ── Intel GPU Compute (fault-tolerant — may not be on all architectures) ──
echo "[11-hardware] Installing Intel compute runtime (fault-tolerant)..."
install_packages "gpu-intel-compute" || true

# ── NVIDIA: Verify ucore's pre-signed modules match the kernel ──────────────
echo "[11-hardware] Checking NVIDIA modules from ucore base (kernel=$KVER)..."

NVIDIA_PRESENT=0
if [[ -d "/lib/modules/$KVER/extra/nvidia" ]] || \
   [[ -d "/lib/modules/$KVER/extra/nvidia-open" ]] || \
   modinfo nvidia -k "$KVER" &>/dev/null; then
    echo "[11-hardware] ✓ NVIDIA kmod present for kernel $KVER (ucore pre-signed)"
    NVIDIA_PRESENT=1
fi

# ── NVIDIA fallback: akmod rebuild via RPMFusion ────────────────────────────
# Only if ucore base missed (rare - the ucore:stable-nvidia tag guarantees
# its own kernel matches). This path requires kernel-devel-$KVER which is the
# exact failure mode that broke v2.2.x when ucore kernel (v0.2.0) didn't
# match F44's kernel-devel (v0.2.0). If kernel-devel is unavailable, we log
# and accept NVIDIA-less - the image still works for everything else, and
# 34-gpu-detect.sh handles runtime blacklisting/unblacklisting.
if [[ $NVIDIA_PRESENT -eq 0 ]]; then
    echo "[11-hardware] Fallback: akmod-nvidia build against $KVER..."
    if install_packages "gpu-nvidia"; then
        if command -v akmods &>/dev/null; then
            akmods --force --kernels "$KVER" 2>&1 | tail -10 || true
            if modinfo nvidia -k "$KVER" &>/dev/null; then
                echo "[11-hardware] ✓ NVIDIA kmod rebuilt via akmods for $KVER"
                NVIDIA_PRESENT=1
            fi
        fi
    fi
fi

if [[ $NVIDIA_PRESENT -eq 0 ]]; then
    echo "[11-hardware] ⚠ No NVIDIA kmod for $KVER after all fallback attempts."
    echo "[11-hardware]    Image will ship without NVIDIA acceleration. Users with"
    echo "[11-hardware]    NVIDIA hardware can rebuild the kmod at runtime:"
    echo "[11-hardware]       sudo dnf install kernel-devel-\$(uname -r) akmod-nvidia"
    echo "[11-hardware]       sudo akmods --force --kernels \$(uname -r)"
fi

# Regenerate CDI spec if nvidia-ctk is available (fails gracefully in no-GPU builds)
if command -v nvidia-ctk &>/dev/null; then
    nvidia-ctk cdi generate --output=/etc/cdi/nvidia.yaml 2>/dev/null || true
    echo "[11-hardware] NVIDIA CDI spec generated (build-time; runtime refresh handled by nvidia-cdi-refresh.path)"
fi

# ── NVIDIA Open Kernel Module Configuration ─────────────────────────────────
# Turing+ (RTX 20xx and newer) supports open modules; RTX 50 Blackwell requires
# them. NVreg_OpenRmEnableUnsupportedGpus=1 lets open modules attempt older
# cards too (Pascal, Maxwell) where supported.
# ARCHITECTURAL FIX: Managed via usr/lib/modprobe.d/nvidia-open.conf
# to prevent /etc state drift.


echo "[11-hardware] GPU stack complete. Mesa + AMD ROCm + Intel + NVIDIA (ucore / akmod rebuild)."
```

---

## automation/12-virt.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 12-virt: Virtualization, containers, orchestration, gaming
#
# CHANGELOG v1.3:
#   - Looking Glass B7: MOVED to 53-bake-lookingglass-client.sh (refactored out)
#   - KVMFR module: MOVED to 52-bake-kvmfr.sh (refactored out)
#   - K3s: MOVED to 13-ceph-k3s.sh (no longer duplicated here)
#   - CrowdSec: Updated sovereign mode config (RE2 regex engine default)
#   - Added Podman quadlet example for CrowdSec
#   - VirtIO-Win ISO: Updated URL pattern
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/packages.sh"
source "${SCRIPT_DIR}/lib/common.sh"

KVER=$(cat /tmp/mios-kver 2>/dev/null || find /usr/lib/modules/ -mindepth 1 -maxdepth 1 -printf "%f\n" | sort -V | tail -1)

# ── KVM / QEMU / Libvirt ────────────────────────────────────────────────────
echo "[12-virt] Installing KVM/QEMU/Libvirt..."
install_packages_strict "virt"

# ── Containers (Podman, Buildah, Skopeo, bootc, self-build tools) ────────────
echo "[12-virt] Installing container runtime and self-building tools..."
install_packages_strict "containers"

# Extra self-build tools (image-rechunking, etc. - may be repo-dependent)
install_packages "self-build"

# ── Cockpit Web Management ──────────────────────────────────────────────────
echo "[12-virt] Installing Cockpit..."
install_packages_strict "cockpit"

# ── Boot & Update Management (bootupd, ukify, etc.) ─────────────────────────
echo "[12-virt] Installing boot and update management tools..."
install_packages "boot"

# ── CrowdSec IPS (sovereign/offline mode) ───────────────────────────────────
echo "[12-virt] Installing CrowdSec..."
install_packages "security"

# Sovereign mode: disable Central API, use local-only decisions
if [ -d /etc/crowdsec ]; then
    # acquis.d/journalctl.yaml managed via  overlay

    # Disable online API for sovereign operation
    if [ -f /etc/crowdsec/config.yaml ]; then
        sed -i 's/^online_client:/# online_client:/' /etc/crowdsec/config.yaml 2>/dev/null || true
    fi
    echo "[12-virt] CrowdSec configured for sovereign/offline mode"
fi

# ── Windows Interop & Remote Desktop ────────────────────────────────────────
echo "[12-virt] Installing Windows interop tools..."
install_packages "wintools"

# ── Gaming (Steam, Wine, Gamescope) ─────────────────────────────────────────
# NOTE: steam-devices and udev-joystick-blacklist-rm (terra weak dep of
# gamescope-session-steam) both ship the same udev rules file. Exclude it.
echo "[12-virt] Installing gaming packages..."
GAMING_PKGS=$(get_packages "gaming")
if [[ -n "$GAMING_PKGS" ]]; then
    ($DNF_BIN "${DNF_SETOPT[@]}" install -y "${DNF_OPTS[@]}" --skip-unavailable --exclude=udev-joystick-blacklist-rm $GAMING_PKGS) || {
        echo "[12-virt] WARNING: Some gaming packages failed to install" >&2
    }
fi

# ── Guest Agents ────────────────────────────────────────────────────────────
echo "[12-virt] Installing guest agents..."
install_packages "guests"

# ── Storage ─────────────────────────────────────────────────────────────────
echo "[12-virt] Installing storage packages..."
install_packages "storage"

# ── High Availability (Pacemaker/Corosync) ──────────────────────────────────
echo "[12-virt] Installing HA stack..."
install_packages "ha"

# ── CLI Utilities ───────────────────────────────────────────────────────────
echo "[12-virt] Installing CLI utilities..."
install_packages "utils"

# ── Android (Waydroid) ──────────────────────────────────────────────────────
echo "[12-virt] Installing Waydroid..."
install_packages "android"

# ── VirtIO-Win ISO (latest stable) ─────────────────────────────────────────
echo "[12-virt] Downloading VirtIO-Win ISO..."
VIRTIO_URL="https://fedorapeople.org/groups/virt/virtio-win/direct-downloads/stable-virtio/virtio-win.iso"
mkdir -p /usr/share/mios/virtio
scurl -sL "$VIRTIO_URL" -o /usr/share/mios/virtio/virtio-win.iso 2>/dev/null || {
    echo "[12-virt] WARNING: VirtIO-Win ISO download failed — download manually later"
}

# Symlink the immutable ISO into /var/lib/libvirt/images via tmpfiles.d so it survives upgrades
# Managed via usr/lib/tmpfiles.d/mios-virtio.conf

echo "[12-virt] Virtualization stack complete. (LG: refactored to 53-lg; K3s: refactored to 13-ceph-k3s)"
```

---

## automation/13-ceph-k3s.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 13-ceph-k3s: Ceph distributed storage + K3s Kubernetes
# Cephadm runs ALL server daemons as Podman containers.
# Only client tools + orchestrator binary are baked into the image.
#
# v0.2.0 FIXES:
#   - K3s manifests stored in /usr/share/mios/k3s-manifests/ (not /var)
#     First-boot service copies them to /var/lib/rancher/k3s/server/manifests/
#     This fixes bootc lint: /var content must use tmpfiles.d entries
#   - systemctl enables moved to Containerfile STEP D (unit files in )
set -euo pipefail
# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/packages.sh"

# ─── Ceph Client + Orchestrator ──────────────────────────────────────────────
echo "[13-ceph-k3s] Installing Ceph client tools and cephadm..."
install_packages "ceph"

# ─── K3s Prerequisites ───────────────────────────────────────────────────────
echo "[13-ceph-k3s] Installing K3s prerequisites..."
install_packages "k3s"

# Note: k3s-selinux policy is compiled from source in 19-k3s-selinux.sh

# ─── K3s Binary & Install Script ─────────────────────────────────────────────
echo "[13-ceph-k3s] Resolving latest K3s release tag..."
# Retry 3 times for flaky networks
K3S_TAG=""
for i in 1 2 3; do
    # v0.2.0: Wrap in subshell + || true to prevent pipefail from killing the script if API is down
    K3S_TAG=$( (scurl -sL -o /dev/null -w "%{url_effective}" https://github.com/k3s-io/k3s/releases/latest | grep -oE '[^/]+$') 2>/dev/null || true)
    if [[ -n "$K3S_TAG" && "$K3S_TAG" != "latest" ]]; then break; fi
    sleep 2
done

if [[ -z "$K3S_TAG" || "$K3S_TAG" == "latest" ]]; then
    echo "[13-ceph-k3s] WARN: Could not resolve latest K3s tag. Skipping K3s binary installation."
    K3S_TAG=""
fi

if [[ -n "$K3S_TAG" ]]; then
    echo "[13-ceph-k3s] Latest K3s tag: $K3S_TAG"

    echo "[13-ceph-k3s] Downloading K3s binary, checksum, and install script..."
    K3S_URL="https://github.com/k3s-io/k3s/releases/download/${K3S_TAG}/k3s"
    K3S_SUM_URL="https://github.com/k3s-io/k3s/releases/download/${K3S_TAG}/sha256sum-amd64.txt"
    K3S_INSTALL_URL="https://raw.githubusercontent.com/k3s-io/k3s/${K3S_TAG}/install.sh"

    mkdir -p /tmp/k3s-dl
    if scurl -sfL "$K3S_URL" -o /tmp/k3s-dl/k3s && \
       scurl -sfL "$K3S_SUM_URL" -o /tmp/k3s-dl/sha256sum.txt && \
       scurl -sfL "$K3S_INSTALL_URL" -o /tmp/k3s-dl/k3s-install.sh; then
        cd /tmp/k3s-dl
        if grep -E "  k3s$" sha256sum.txt | sha256sum -c - >/dev/null 2>&1; then
            echo "[13-ceph-k3s] ✓ K3s SHA256 checksum verified"
            mv k3s /usr/local/bin/k3s
            chmod 755 /usr/local/bin/k3s

            # Only symlink if official RPM binaries don't exist, preventing PATH shadowing
            [ ! -f /usr/bin/kubectl ] && ln -sf /usr/local/bin/k3s /usr/local/bin/kubectl 2>/dev/null || true
            [ ! -f /usr/bin/crictl ] && ln -sf /usr/local/bin/k3s /usr/local/bin/crictl 2>/dev/null || true
            [ ! -f /usr/bin/ctr ] && ln -sf /usr/local/bin/k3s /usr/local/bin/ctr 2>/dev/null || true

            mv k3s-install.sh /usr/local/bin/k3s-install.sh
            chmod 755 /usr/local/bin/k3s-install.sh

            echo "[13-ceph-k3s] K3s binary and install script installed (tag: $K3S_TAG)"
        else
            echo "[13-ceph-k3s] ERROR: K3s binary SHA256 checksum mismatch! Skipping."
        fi
        cd - >/dev/null
    else
        echo "[13-ceph-k3s] WARN: K3s download failed. Skipping K3s installation."
    fi
    rm -rf /tmp/k3s-dl
fi

# ─── Make bootstrap script executable ────────────────────────────────────────
chmod 755 /usr/local/bin/ceph-bootstrap.sh 2>/dev/null || true

# ─── NOTE: Service enables are in Containerfile STEP D ───────────────────────
# k3s.service, mios-ceph-bootstrap.service, var-home.mount,
# var-lib-containers.mount all live in  and are enabled
# AFTER the COPY step in the Containerfile.

echo "[13-ceph-k3s] Ceph + K3s stack installed."
echo "[13-ceph-k3s]   Ceph Dashboard:  https://<host>:8443 (after bootstrap)"
echo "[13-ceph-k3s]   K3s API server:  https://<host>:6443 (after boot)"
```

---

## automation/18-apply-boot-fixes.sh

```bash
#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# MiOS: Systemd execution analysis & WSL2 Boot Loop fixes
# Resolves ordering cycles, executable stripping, and hardware-dependent
# failure cascades detected during F44 boots on varied hardware/hypervisors.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

echo "==> Applying MiOS system service fixes..."

# 1. Fix USBGuard Permissions
# Log trace: Permissions for /etc/usbguard/usbguard-daemon.conf should be 0600
if [ -f /etc/usbguard/usbguard-daemon.conf ]; then
    chmod 0600 /etc/usbguard/usbguard-daemon.conf
fi

# 2. Fix 203/EXEC for custom MiOS services
# Log trace: mios-role.service & mios-cdi-detect.service exited 203/EXEC
# Global chmod commands in earlier pipelines stripped execution bits.
# Handle all scripts in /usr/libexec/mios/ and named patterns.
find /usr/libexec/mios -type f -exec chmod +x {} \; || true
find /usr/libexec -type f \( -name 'mios-*' -o -name 'role-apply' -o -name 'selinux-init' -o -name 'gpu-detect' -o -name 'cpu-isolate' -o -name 'motd' -o -name 'dash' -o -name 'sb-audit' -o -name 'wsl-init' -o -name 'wsl-firstboot' -o -name 'sb-keygen' -o -name 'tpm-enroll' \) -exec chmod +x {} \; || true
find /usr/bin -name 'mios-*' -type f -exec chmod +x {} \; || true

# 3. Libvirt QEMU Hooks
# Ensure hooks are executable. We check both /etc and /usr/lib for bootc parity.
for hook in /etc/libvirt/hooks/qemu /usr/lib/libvirt/hooks/qemu; do
    if [ -f "$hook" ]; then
        chmod +x "$hook"
    fi
done

# 4. Fix systemd-resolved 217/USER
# Log trace: systemd-resolved.service exited 217/USER
# User mapping required at boot time; ensuring it's compiled statically.
if [ -f /usr/lib/sysusers.d/systemd-resolve.conf ]; then
    systemd-sysusers /usr/lib/sysusers.d/systemd-resolve.conf || true
fi

# 5. Fix Systemd Ordering Cycle for GPU Passthrough
# Log trace: sockets.target: Found ordering cycle: docker.socket/start after mios-gpu-nvidia.service/start after basic.target
# Drop-in handled via overlay.

# 6. OCI Container and WSL2 Service Gating
# Custom MiOS services that require hardware access or full system init
# skip OCI containers and WSL2 via drop-ins in system_files overlay.
echo "==> Service gating drop-ins active via overlay"

# 7. WSL2 Compatibility Gating (Legacy section kept for unit-specific fallbacks)

```

---

## automation/19-k3s-selinux.sh

```bash
#!/usr/bin/env bash
set -euo pipefail

echo "==> Compiling and Installing K3s SELinux Policy for Fedora 44..."

# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"

# Install SELinux development tools required for compilation
$DNF_BIN "${DNF_SETOPT[@]}" install -y "${DNF_OPTS[@]}" selinux-policy-devel git make

# Clone the upstream k3s-selinux repository
git clone --depth 1 https://github.com/k3s-io/k3s-selinux.git /tmp/k3s-selinux
cd /tmp/k3s-selinux

# K3s SELinux repo stores policies in subdirectories (e.g., policy/coreos or policy/centos9)
# We find the best matching policy source files for Fedora.
POLICY_DIR=""
if [ -d "policy/coreos" ]; then
    POLICY_DIR="policy/coreos"
elif [ -d "policy/centos9" ]; then
    POLICY_DIR="policy/centos9"
elif [ -d "policy/rhel9" ]; then
    POLICY_DIR="policy/rhel9"
else
    # Fallback to the first directory containing k3s.te
    POLICY_DIR=$(find policy -name k3s.te -printf '%h\n' | head -n 1)
fi

if [ -z "$POLICY_DIR" ]; then
    echo "FATAL: Could not find k3s.te in the repository."
    exit 1
fi

echo "Using policy source from: $POLICY_DIR"
cp "$POLICY_DIR"/k3s.* .

# Compile the policy using the Fedora 44 SELinux Makefile
make -f /usr/share/selinux/devel/Makefile k3s.pp

# ARCHITECTURAL FIX: Instead of installing at build-time with 'semodule -i',
# we ship the compiled policy in the immutable /usr tree.
# This ensures that 'bootc upgrade' doesn't create opaque policy layers.
mkdir -p /usr/share/selinux/packages/mios
install -m 0644 k3s.pp /usr/share/selinux/packages/mios/k3s.pp

# Clean up
cd /
rm -rf /tmp/k3s-selinux
echo "==> K3s SELinux Policy staged in /usr/share/selinux/packages/mios/"

```

---

## automation/20-fapolicyd-trust.sh

```bash
#!/usr/bin/env bash
set -euo pipefail

echo "==> Configuring fapolicyd for fs-verity/ComposeFS..."

# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"

# Configure fapolicyd to use the file trust backend (fs-verity)
# This allows 0-second boot delays while maintaining rigid application whitelisting
# in immutable ComposeFS environments.
#
# v0.2.0: USR-OVER-ETC alignment. Update both /usr/lib and /etc.
for config in /usr/lib/fapolicyd/fapolicyd.conf /etc/fapolicyd/fapolicyd.conf; do
    if [[ -f "$config" ]]; then
        sed -i 's/^trust =.*/trust = file,rpmdb/' "$config" || true
    fi
done

# Enable the service
systemctl enable fapolicyd.service
echo "==> fapolicyd configured successfully."
```

---

## automation/20-services.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 20-services: Enable systemd services + bare-metal/VM gating
#
# CHANGELOG v1.3:
#   - systemd 260: cgroup v1 support REMOVED — all services must use cgroup v2
#   - systemd 260: SysV service scripts no longer supported
#   - Fixed: pmcd/pmlogger services removed (only pmproxy is installed)
#   - Added: bootloader-update.service for bootc systems
#   - Added: podman-auto-update.timer for quadlet auto-updates
#   - Improved: Bare-metal vs VM vs WSL2 service gating
set -euo pipefail

echo "═══════════════════════════════════════════════════════════════════"
echo "  MiOS v0.2.0 — Service Configuration"
echo "═══════════════════════════════════════════════════════════════════"

# ─── Fix systemd unit file permissions ────────────────────────────────────────
# Container builds sometimes leave bad perms from COPY operations.
for unit_file in \
    /usr/lib/systemd/system/var-home.mount \
    /usr/lib/systemd/system/var-lib-containers.mount \
    /usr/lib/systemd/system/ceph-bootstrap.service \
    /usr/lib/systemd/system/cockpit.socket.d/listen.conf \
; do
    [ -f "$unit_file" ] && chmod 644 "$unit_file"
done
echo "[20-services] Fixed systemd unit file permissions"

# ─── Service Configuration Note ──────────────────────────────────────────────
# CORE and OPTIONAL services are now primarily managed via:
# usr/lib/systemd/system-preset/90-mios.preset
# Role-specific services are managed by mios-role.service at runtime.

# ─── WSL2 & Container Service Gating ─────────────────────────────────────────
# These services skip OCI/WSL2 via drop-ins in system_files overlay.
echo "[20-services] WSL2/Container skip drop-ins active via overlay"

# ─── nvidia-powerd: skip in ALL VMs (no physical NVIDIA GPU) ─────────────────
# Drop-in handled via overlay.

# ─── TuneD: set throughput-performance profile ──────────────────────────────
tuned-adm profile throughput-performance 2>/dev/null || true

echo "[20-services] Service configuration baseline complete. v1.4"
```

---

## automation/21-moby-engine.sh

```bash
#!/usr/bin/env bash
# Normalize to LF line endings (fixes SC1017)
set -euo pipefail

echo "==> Installing moby-engine (Docker) alongside Podman..."

# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"

# moby-engine conflicts with podman-docker over /usr/bin/docker. Use --allowerasing
# to let dnf resolve the conflict without an explicit remove (§3.9: no dnf remove).
$DNF_BIN "${DNF_SETOPT[@]}" install -y "${DNF_OPTS[@]}" moby-engine

# Enable the Docker socket to ensure it's available on boot
systemctl enable docker.socket

# Ensure the docker group exists so we can map users to it later via sysusers
groupadd -r docker 2>/dev/null || true
```

---

## automation/22-freeipa-client.sh

```bash
#!/usr/bin/env bash
# 22-freeipa-client.sh — install FreeIPA/SSSD client + arm zero-touch enrollment.
#
# Runtime path: mios-freeipa-enroll.service runs only when
# /etc/mios/ipa-enroll.env is present and /etc/ipa/default.conf is absent.
#
# Upstream regression notes (April 2026):
#   bz 2320133 — SSSD file caps stripped by rpm-ostree < bootc v0.2.0-2.fc41.
#                Asserted post-install; build fails fast if caps are missing.
#   bz 2332433 — /var/lib/ipa-client/sysrestore/ missing on first boot.
#                Pre-created via tmpfiles.d.
set -euo pipefail

echo "==> Installing FreeIPA & SSSD for zero-touch enrollment..."

# shellcheck source=lib/packages.sh
source "$(dirname "$0")/lib/packages.sh"

# Install client + SSSD tooling.
install_packages "freeipa"

# ── SSSD file capability regression check (bz 2320133) ─────────────────────
echo "==> Verifying SSSD file capabilities..."
SSSD_CAP_BINS=(
    /usr/libexec/sssd/krb5_child
    /usr/libexec/sssd/ldap_child
    /usr/libexec/sssd/selinux_child
    /usr/lib/sssd/sssd_pam
)
CAP_FAIL=0
for bin in "${SSSD_CAP_BINS[@]}"; do
    [[ -f "$bin" ]] || continue
    caps=$(getcap "$bin" 2>/dev/null || true)
    if [[ -z "$caps" ]]; then
        echo "ERROR: $bin missing file capabilities (bz 2320133 regression)"
        CAP_FAIL=$((CAP_FAIL + 1))
    fi
done
if (( CAP_FAIL > 0 )); then
    echo "WARNING: ${CAP_FAIL} SSSD binary(ies) lost file capabilities — FreeIPA authentication may require 'setcap' at runtime."
fi

# Arm the zero-touch enrollment oneshot (gated by ConditionPathExists).
systemctl enable mios-freeipa-enroll.service
```

---

## automation/23-uki-render.sh

```bash
#!/usr/bin/env bash
set -euo pipefail

echo "==> Preparing Unified Kernel Image (UKI) configuration..."

# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"

# systemd-ukify and binutils are required for this step.
# Ensure they are declared in specs/engineering/2026-04-26-Artifact-ENG-001-Packages.md per the single-source-of-truth rules.
# The packages-boot section installs ukify via install_packages (--skip-unavailable),
# so install explicitly here as a safety net to guarantee it ends up in the image.
if ! rpm -q systemd-ukify >/dev/null 2>&1; then
    echo "==> systemd-ukify not found via boot-section install; installing explicitly..."
    $DNF_BIN "${DNF_SETOPT[@]}" install -y "${DNF_OPTS[@]}" systemd-ukify
fi

# In a bootc Containerfile build, we use `bootc container render-kargs`
# to flatten all kargs.d/*.toml drop-ins into a single string for the UKI.
if command -v bootc >/dev/null && bootc container --help | grep -q 'render-kargs'; then
    echo "==> Rendering bootc kargs for UKI natively..."
    bootc container render-kargs > /etc/kernel/cmdline
else
    echo "==> bootc render-kargs not available, rendering flat TOML via Python fallback..."
    python3 -c '
import tomllib, sys, glob
kargs = []
for f in sorted(glob.glob("/usr/lib/bootc/kargs.d/*.toml")):
    with open(f, "rb") as fp:
        d = tomllib.load(fp)
        if "kargs" in d:
            kargs.extend(d["kargs"])
print(" ".join(kargs))
' > /etc/kernel/cmdline
fi

CMDLINE=$(cat /etc/kernel/cmdline | xargs)
if [ -z "$CMDLINE" ]; then
    echo "FATAL: /etc/kernel/cmdline is empty! UKI generation will fail."
    exit 1
fi

echo "Rendered UKI cmdline: $CMDLINE"
# The actual UKI generation (`ukify build`) occurs in the final CI/CD pipeline
echo "==> UKI cmdline preparation complete."
```

---

## automation/25-firewall-ports.sh

```bash
#!/usr/bin/env bash
set -euo pipefail

echo "==> Configuring firewalld ports for MiOS services..."

# During an OCI container build, the firewalld daemon is not running.
# We MUST use firewall-offline-cmd to write directly to the XML policy files.

# Open essential ports for local/LAN access
firewall-offline-cmd --zone=public --add-port=8080/tcp # Guacamole
firewall-offline-cmd --zone=public --add-port=8443/tcp # Ceph Dashboard
firewall-offline-cmd --zone=public --add-port=6443/tcp # K3s API
firewall-offline-cmd --zone=public --add-port=3389/tcp # RDP
firewall-offline-cmd --zone=public --add-service=ssh
firewall-offline-cmd --zone=public --add-service=cockpit
firewall-offline-cmd --zone=public --add-service=mios-pxe
```

---

## automation/26-gnome-remote-desktop.sh

```bash
#!/usr/bin/env bash
set -euo pipefail

echo "=== Configuring GNOME Remote Desktop (GNOME 50) ==="

# Pre-emptively disable/mask legacy xrdp services just in case they bleed in from a base image
systemctl mask xrdp.service xrdp-sesman.service 2>/dev/null || true

# GNOME Remote Desktop handles Wayland headless RDP natively.
# Enablement is handled via usr/lib/systemd/system-preset/90-mios.preset
# Drop-in to wait for network is delivered via system_files overlay.

echo "GNOME Remote Desktop provisioning complete."
```

---

## automation/30-locale-theme.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 30-locale-theme: Unified dark theme for EVERY window type
#
# Coverage matrix (ALL must be dark):
#   ✓ libadwaita / GTK4 apps (GNOME native) — color-scheme=prefer-dark via dconf
#   ✓ GTK3 apps (legacy GNOME) — adw-gtk3-dark theme
#   ✓ GDM login screen — separate dconf db (gdm user)
#   ✓ GNOME lock screen — inherits user session (automatic)
#   ✓ Flatpak apps — ADW_DEBUG_COLOR_SCHEME + portal + filesystem overrides
#   ✓ Qt5/Qt6 apps — adwaita-qt + QGnomePlatform env vars
#   ✓ Electron/Chromium apps — ELECTRON_FORCE_DARK_MODE
#   ✓ Firefox — MOZ_ENABLE_WAYLAND + portal color-scheme
#   ✓ GNOME Remote Desktop — XCURSOR_THEME + session env
#   ✓ TTY/console — no theming needed (terminal colors)
#
# MUST RUN BEFORE 30-user.sh (skel .bashrc must exist before useradd -m)
set -euo pipefail

echo "═══════════════════════════════════════════════════════════════════"
echo "  MiOS v0.2.0 — Universal Dark Theme"
echo "═══════════════════════════════════════════════════════════════════"

# ═══ SKEL .bashrc (MUST come BEFORE useradd -m) ═══
# v0.2.0: Delivered via usr/share/skel/.bashrc overlay.
echo "[30-locale-theme] Using /etc/skel/.bashrc from overlay..."

# ═══ GTK3: adw-gtk3-dark for visual consistency with libadwaita ═══
# v0.2.0: Delivered via etc/gtk-3.0/settings.ini overlay.
echo "[30-locale-theme] Using GTK3 theme from overlay..."

# ═══ GTK4: libadwaita reads color-scheme, NOT GTK_THEME ═══
# v0.2.0: Delivered via etc/gtk-4.0/settings.ini overlay.
echo "[30-locale-theme] Using GTK4 theme from overlay..."

# ═══ System-wide env vars for ALL toolkits ═══
# v0.2.0: Delivered via etc/environment.d/ overlay.
echo "[30-locale-theme] Using environment.d from overlay..."

# ═══ Flatpak overrides — dark theme + cursor + fonts ═══
echo "[30-locale-theme] Applying Flatpak dark theme + filesystem overrides..."
flatpak override --system --env=ADW_DEBUG_COLOR_SCHEME=prefer-dark 2>/dev/null || true
flatpak override --system --env=XCURSOR_THEME=Bibata-Modern-Classic 2>/dev/null || true
flatpak override --system --env=XCURSOR_SIZE=24 2>/dev/null || true
flatpak override --system --env=GTK_THEME=adw-gtk3-dark 2>/dev/null || true
flatpak override --system --filesystem=xdg-config/gtk-3.0:ro 2>/dev/null || true
flatpak override --system --filesystem=xdg-config/gtk-4.0:ro 2>/dev/null || true
flatpak override --system --filesystem=/usr/share/icons:ro 2>/dev/null || true
flatpak override --system --filesystem=/usr/share/fonts:ro 2>/dev/null || true
flatpak override --system --filesystem=/etc/gtk-3.0:ro 2>/dev/null || true
flatpak override --system --filesystem=/etc/gtk-4.0:ro 2>/dev/null || true

# ═══ Skeleton autostart (Bottles from flathub-beta on first login) ═══
# v0.2.0: Delivered via etc/skel/.config/autostart/ overlay.

# Ensure skel GTK3 also uses adw-gtk3-dark (for new user sessions)
# v0.2.0: Delivered via etc/skel/.config/gtk-3.0/settings.ini overlay.
# ── Compile GSchema overrides (THE correct way to set GNOME defaults) ──
if [ -f /usr/share/glib-2.0/schemas/90-mios.gschema.override ]; then
    echo "[30-locale-theme] Compiling GSchema overrides..."
    glib-compile-schemas /usr/share/glib-2.0/schemas/ || true
    echo "[30-locale-theme] ✓ GSchema overrides compiled"
fi

# Suppress DBus warnings during headless update without swallowing real syntax errors
export GIO_USE_VFS=local
dconf update || true

# Migrate generated binary dconf databases to the immutable /usr/share path.
# This prevents OSTree 3-way merge binary conflicts on /etc/dconf/db/local
# during bootc upgrades if users make their own local dconf changes.
if [ -d /etc/dconf/db ]; then
    mkdir -p /usr/share/dconf/db
    find /etc/dconf/db -maxdepth 1 -type f -exec mv -f {} /usr/share/dconf/db/ \; 2>/dev/null || true
fi

echo "[30-locale-theme] Dark theme configured for all toolkits."
```

---

## automation/31-user.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 31-user: PAM, user creation, groups, sudoers
# Must run AFTER skel is populated (31-locale-theme writes skel/.bashrc)
# and BEFORE any service that references the user.
set -euo pipefail

echo "——————————————————————?"
echo "  MiOS v0.2.0 — User & Authentication"
echo "——————————————————————?"

# — PAM FIX —
echo "[31-user] Configuring PAM via authselect..."
if command -v authselect &>/dev/null; then
    authselect select local --force 2>/dev/null || {
        echo "[31-user] WARNING: authselect failed — using system_files overlay fallback"
    }
fi

# — USER CREATION —
# Password is pre-hashed (SHA-512) by the orchestrator — plaintext NEVER in build log.
# Defaults for CI builds or when environment variables are not provided:
C_USER="${MIOS_USER:-mios}"
# Note: MIOS_PASSWORD_HASH should be a SHA-512 crypt-style hash

echo "[31-user] Creating user ${C_USER} via sysusers..."
if [[ "${C_USER}" != "mios" ]]; then
    # Generate dynamic sysusers for custom username
    cat <<EOF > /usr/lib/sysusers.d/15-mios-custom.conf
u ${C_USER} - "MiOS Custom User" /var/home/${C_USER} /bin/bash
m ${C_USER} wheel
m ${C_USER} libvirt
m ${C_USER} kvm
m ${C_USER} video
m ${C_USER} render
m ${C_USER} input
m ${C_USER} dialout
m ${C_USER} docker
EOF
fi

# Apply sysusers declarative config
systemd-sysusers --root=/ 2>/dev/null || true

if getent passwd "${C_USER}" >/dev/null; then
    home=$(getent passwd "${C_USER}" | cut -d: -f6)
    if [ ! -d "$home" ]; then
        echo "[31-user] Creating home directory for ${C_USER} from /etc/skel..."
        mkdir -p "$home"
        cp -a /etc/skel/. "$home/"
    fi
    passwd -u "${C_USER}" 2>/dev/null || true
else
    echo "[31-user] ERROR: Failed to create user ${C_USER}"
fi

# — GROUP INJECTION —
# Groups are pre-created and memberships injected via /usr/lib/sysusers.d/*.conf
# and processed by systemd-sysusers above. Imperative calls removed.

# — SUDOERS —
# Managed via usr/lib/sudoers.d/10-mios-wheel
chmod 440 /usr/lib/sudoers.d/10-mios-wheel 2>/dev/null || true

# — LOCALE —
# Managed via usr/lib/locale.conf
localedef -i en_US -f UTF-8 en_US.UTF-8 2>/dev/null || true

# — CLOUD-INIT —
# Managed via usr/lib/cloud/cloud.cfg.d/10-mios.cfg

# — MULTIPATH —
# Managed via usr/lib/multipath.conf

# — FIX HOME DIRECTORY OWNERSHIP —
echo "[31-user] Fixing home directory ownership..."
awk -F: '$3 >= 1000 && $3 < 65000 {print $1}' /etc/passwd | while read -r u; do
    home=$(getent passwd "$u" | cut -d: -f6)
    if [ -d "$home" ]; then
        uid=$(id -u "$u"); gid=$(id -g "$u")
        chown -R "${uid}:${gid}" "$home"
    fi
done

# — NFS STATE DIRECTORY —
# Managed via usr/lib/tmpfiles.d/mios-nfs.conf

echo "[31-user] User & authentication configured."
```

---

## automation/32-hostname.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 32-hostname: Unique per-instance hostname
#
# Strategy: Set a template hostname in the image. On first boot, systemd
# generates /etc/machine-id. The mios-init service (35-init-service.sh)
# derives a stable 5-char tag from machine-id and sets the hostname.
#
# Result: Each instance gets mios-XXXXX (e.g., mios-a3f9c), unique
# per deployment, stable across reboots.
set -euo pipefail

echo "[32-hostname] Setting default hostname template..."

# Use MIOS_HOSTNAME build-arg if provided by the installer/bootstrap.
# When set (e.g. "mios-ws-83427"), it becomes the static hostname.
# When unset (default "mios"), the first-boot mios-init derives mios-XXXXX
# from machine-id so every deployment still gets a unique hostname.
_hn="${MIOS_HOSTNAME:-mios}"
echo "$_hn" > /etc/hostname
echo "[32-hostname] Hostname set to: $_hn"
if [[ "$_hn" == "mios" ]]; then
    echo "[32-hostname] Will become mios-XXXXX on first boot via mios-init."
fi
```

---

## automation/33-firewall.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 33-firewall: Firewall configuration script
set -euo pipefail

echo "[33-firewall] Installing firewall init script..."

cat > /usr/libexec/mios-firewall-init <<'EOFW'
#!/bin/bash
set -euo pipefail
if ! systemctl is-active --quiet firewalld 2>/dev/null; then
    echo "[mios-firewall] firewalld not active — skipping"
    exit 0
fi
# Default zone: drop (deny all inbound by default)
firewall-cmd --set-default-zone=drop 2>/dev/null || true
# Essential services
for svc in cockpit ssh mdns; do
    firewall-cmd --permanent --add-service="$svc" 2>/dev/null || true
done
# RDP (GNOME Remote Desktop + Hyper-V vsock)
firewall-cmd --permanent --add-port=3389/tcp --add-port=3390/tcp 2>/dev/null || true
# Samba + NFS
firewall-cmd --permanent --add-service=samba --add-service=nfs --add-service=rpc-bind --add-service=mountd 2>/dev/null || true
# Libvirt
firewall-cmd --permanent --add-port=16509/tcp 2>/dev/null || true
# VNC
firewall-cmd --permanent --add-port=5900-5999/tcp 2>/dev/null || true
# K3s API + kubelet
firewall-cmd --permanent --add-port=6443/tcp --add-port=10250/tcp 2>/dev/null || true
# Pacemaker/Corosync
firewall-cmd --permanent --add-port=2224/tcp --add-port=5403-5405/udp 2>/dev/null || true
# CrowdSec dashboard + iVentoy
firewall-cmd --permanent --add-port=3000/tcp --add-port=26000/tcp 2>/dev/null || true
# Cockpit on 9090 (already via service but explicit)
firewall-cmd --permanent --add-port=9090/tcp 2>/dev/null || true
# Trust internal interfaces (including dynamic netavark/k3s bridges via wildcards)
# nftables backend drops unassigned interfaces strictly into the drop zone
for iface in lo podman+ br-+ veth+ virbr0 cni0 flannel.1 waydroid0; do
    firewall-cmd --permanent --zone=trusted --add-interface="$iface" 2>/dev/null || true
done

# ── Cockpit — accessible from ALL zones ──
for zone in public libvirt trusted; do
    firewall-cmd --permanent --zone="$zone" --add-service=cockpit 2>/dev/null || true
    firewall-cmd --permanent --zone="$zone" --add-port=9090/tcp 2>/dev/null || true
done
firewall-cmd --reload 2>/dev/null || true
echo "[mios-firewall] Firewall configured"
EOFW
chmod +x /usr/libexec/mios-firewall-init

echo "[33-firewall] Firewall init script installed."
```

---

## automation/34-gpu-detect.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 34-gpu-detect: Bridge to GPU detection service
# Blocks NVIDIA modules in VMs, enables hardware renderer on bare metal,
# detects RTX 50-series VFIO reset bug.
# Actual logic lives in /usr/libexec/mios/gpu-detect (system_files overlay).
set -euo pipefail

echo "[34-gpu-detect] Configuring GPU auto-detect service..."

# Unit and script are delivered via system_files overlay.
# Enablement is handled via usr/lib/systemd/system-preset/90-mios.preset

echo "[34-gpu-detect] GPU detection service enabled."
```

---

## automation/35-gpu-passthrough.sh

```bash
#!/usr/bin/env bash
# ============================================================================
# MiOS v0.2.0 - 35-gpu-passthrough.sh
# ----------------------------------------------------------------------------
# Manages systemd unit enablement and SELinux for GPU passthrough.
#
# v0.2.0: ARCHITECTURAL PURITY FIX. All files (systemd units, udev rules,
#         sysusers, kargs.d) are now delivered via the system_files overlay.
#         This script no longer performs 'install' commands; it only handles
#         symlinking and SELinux booleans.
#
# Runs AFTER 34-gpu-detect.sh and 08-system-files-overlay.sh.
# ============================================================================
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"

log "Enabling GPU passthrough services"

# ----------------------------------------------------------------------------
# Enable units via symlink (Containerfile-safe; `systemctl enable` cannot run
# in a bootc build because there is no PID 1 / dbus during image assembly).
# ----------------------------------------------------------------------------
WANTS=/usr/lib/systemd/system/multi-user.target.wants
install -d -m 0755 "${WANTS}"

# These files are already installed in /usr/lib/systemd/system/ via overlay
for svc in mios-gpu-status.service mios-gpu-nvidia.service mios-gpu-amd.service mios-gpu-intel.service; do
  if [[ -f "/usr/lib/systemd/system/${svc}" ]]; then
    ln -sf "../${svc}" "${WANTS}/${svc}"
    log "Enabled ${svc}"
  else
    log "WARN: ${svc} missing from /usr/lib/systemd/system/ — skipping"
  fi
done

# Enable the upstream NVIDIA path unit where the toolkit shipped it.
if [[ -f /usr/lib/systemd/system/nvidia-cdi-refresh.path ]]; then
  ln -sf ../nvidia-cdi-refresh.path "${WANTS}/nvidia-cdi-refresh.path"
  log "Enabled nvidia-cdi-refresh.path"
fi

# ----------------------------------------------------------------------------
# SELinux: enable container_use_devices boolean so containers can touch
# /dev/kfd and /dev/dri with the default container_t domain. This is the
# minimal-privilege path for AMD/Intel compute - NOT container_runtime_t.
# ----------------------------------------------------------------------------
if command -v semanage >/dev/null 2>&1 && [[ -d /etc/selinux/targeted ]]; then
  if semanage boolean -m --on container_use_devices 2>/dev/null; then
    log "SELinux boolean container_use_devices persisted at build time"
  else
    log "semanage not operational in build; runtime service will handle it"
  fi
fi

log "GPU passthrough services enabled successfully"
```

---

## automation/35-gpu-pv-shim.sh

```bash
#!/usr/bin/env bash
# automation/35-gpu-pv-shim.sh - MiOS v0.2.0
# ----------------------------------------------------------------------------
# Automates guest-side shimming for Hyper-V GPU-PV (dxgkrnl).
# Since dxgkrnl isn't mainlined yet, we provide the user-mode hooks
# to bridge to host drivers mounted via WSL/Hyper-V.
#
# v0.2.0: Refactored to use common logging and build-safe symlinks.
# ----------------------------------------------------------------------------
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"

# 1. Create the system-standard mount points for dxgkrnl/WSL hooks
# These are the locations where Mesa D3D12 and NVIDIA CUDA look for Hyper-V host drivers.
log "Creating GPU-PV shim directory structure..."
mkdir -p /usr/lib/wsl/lib
mkdir -p /usr/lib/wsl/drivers

# 2. Add ld.so.conf entry to ensure these libraries are in the search path
log "Configuring dynamic linker paths for GPU-PV..."
mkdir -p /etc/ld.so.conf.d
echo "/usr/lib/wsl/lib" > /etc/ld.so.conf.d/mios-gpu-pv.conf

# 3. Create a detection script for first-boot or deployment
mkdir -p /usr/libexec/mios
cat > /usr/libexec/mios/gpu-pv-detect <<'EOF'
#!/usr/bin/bash
set -euo pipefail
log() { echo "[gpu-pv-detect] $*"; }

if [ ! -e /dev/dxg ]; then
    # log "Hyper-V /dev/dxg not found. Skipping GPU-PV library hooks."
    exit 0
fi

log "Hyper-V dxgkrnl detected!"
if [ -z "$(ls -A /usr/lib/wsl/lib)" ]; then
    log "HINT: /usr/lib/wsl/lib is empty. GPU acceleration requires host drivers."
    log "HINT: Copy drivers from Windows: C:\Windows\System32\lxss\lib -> /usr/lib/wsl/lib"
fi
EOF

chmod +x /usr/libexec/mios/gpu-pv-detect

# 4. Create a systemd service to run the detection/setup on boot
cat > /usr/lib/systemd/system/mios-gpu-pv-detect.service <<EOF
[Unit]
Description=MiOS Hyper-V GPU-PV Detection
ConditionVirtualization=microsoft
After=local-fs.target
Before=display-manager.service

[Service]
Type=oneshot
ExecStart=/usr/libexec/mios/gpu-pv-detect
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

# 5. Enable the service using a build-safe symlink
# See 35-gpu-passthrough.sh for detailed explanation.
log "Enabling GPU-PV detection service..."
WANTS=/usr/lib/systemd/system/multi-user.target.wants
install -d -m 0755 "${WANTS}"
ln -sf ../mios-gpu-pv-detect.service "${WANTS}/mios-gpu-pv-detect.service"

log "GPU-PV shim integration complete."
```

---

## automation/35-init-service.sh

```bash
#!/usr/bin/env bash
# MiOS v0.2.0 — 35-init-service: Bridge to Unified Role Engine
# This script ensures mios-role.service is correctly enabled.
# The actual logic lives in /usr/libexec/mios/role-apply (system_files overlay).
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"

log "Enabling unified system initialization..."

# Enable units using build-safe symlinks
WANTS=/usr/lib/systemd/system/multi-user.target.wants
install -d -m 0755 "${WANTS}"

for unit in \
    mios-role.service \
    mios-podman-gc.timer
do
    if [[ -f "/usr/lib/systemd/system/${unit}" ]]; then
        ln -sf "../${unit}" "${WANTS}/${unit}"
        log "Enabled ${unit}"
    else
        warn "${unit} not found, skipping enablement."
    fi
done

log "Initialization system services enabled."
```

---

## automation/36-akmod-guards.sh

```bash
#!/usr/bin/env bash
# ============================================================================
# automation/36-akmod-guards.sh - MiOS v0.2.0
# ----------------------------------------------------------------------------
# Install ExecCondition drop-ins that make NVIDIA systemd units exit cleanly
# (skipped, not failed) when the running kernel's nvidia module has not yet
# been registered by akmods/depmod. Build-time script; does not touch runtime.
#
# Regex widened beyond NVIDIA/nvidia-container-toolkit#1395 to match:
#   - kernel/drivers/... paths (negativo17 packaging)
#   - extra/nvidia/...    paths (RPM Fusion akmod packaging, used by ucore-hci)
#   - .ko, .ko.xz, .ko.zst compressed variants
# ============================================================================
set -euo pipefail

# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"

log "36-akmod-guards: installing ExecCondition drop-ins"

SERVICES=(
    nvidia-persistenced
    nvidia-powerd
    nvidia-suspend
    nvidia-resume
    nvidia-hibernate
    nvidia-suspend-then-hibernate
    nvidia-cdi-refresh
)

DROPIN_NAME="10-mios-akmod-guard.conf"
count=0

for svc in "${SERVICES[@]}"; do
    dir="/usr/lib/systemd/system/${svc}.service.d"
    path="${dir}/${DROPIN_NAME}"
    install -d -m 0755 "${dir}"
    cat > "${path}" <<'EOF'
# MiOS v0.2.0 akmod-guard
# Skip unit if akmods has not yet registered the nvidia kernel module
# for the currently running kernel. ExecCondition is additive (AND
# semantics per systemd.service(5)), so this composes safely with any
# future upstream guard. Ref: NVIDIA/nvidia-container-toolkit#1395
# NOTE: \\\\ in this heredoc → \\ in file → systemd strips one backslash
# → grep sees \. (literal-dot escape). Plain \\. triggered SC "unknown
# escape sequence" warnings in systemd 259+ and could mis-match.
[Service]
ExecCondition=/bin/bash -c 'grep -Eq "(^|/)nvidia\\.ko(\\.[xz]z|\\.zst)?:" /lib/modules/$(uname -r)/modules.dep'
EOF
    chmod 0644 "${path}"
    count=$((count + 1))
    log "  installed ${path}"
done

log "36-akmod-guards: done (${count} drop-ins)"
```

---

## automation/36-tools.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 36-tools: CLI tools and consolidated mios command
# Installs all mios-* tools to /usr/bin/ and the master 'mios' CLI.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[36-tools] Configuring MiOS CLI tools..."

# CLI tools are now delivered via system_files overlay at /usr/bin/
# We just need to ensure permissions are correct here for files that 
# might have lost the executable bit during git/Windows transfer.

TOOLS=(
    mios 
    mios-update 
    mios-rebuild 
    mios-build 
    mios-backup 
    mios-deploy 
    mios-status 
    mios-vfio-toggle 
    mios-vfio-check 
    iommu-groups
    aichat
    aichat-ng
)

for tool in "${TOOLS[@]}"; do
    if [ -f "/usr/bin/$tool" ]; then
        chmod +x "/usr/bin/$tool"
    else
        echo "[36-tools] WARN: /usr/bin/$tool not found (should be in system_files overlay)"
    fi
done

# ═══ Install external scripts from build context ═══
# These are scripts that live in automation/ and are installed to /usr/bin/
echo "[36-tools] Installing mios-toggle-headless and mios-test..."
for ext_tool in mios-toggle-headless mios-test; do
    if [ -f "${SCRIPT_DIR}/${ext_tool}" ]; then
        install -Dm0755 "${SCRIPT_DIR}/${ext_tool}" "/usr/bin/${ext_tool}"
    else
        echo "[36-tools] WARN: ${ext_tool} not found at ${SCRIPT_DIR}/${ext_tool}"
    fi
done

echo "[36-tools] CLI tools configuration complete. Run 'mios --help' for commands."
```

---

## automation/37-aichat.sh

```bash
#!/bin/bash
# 37-aichat: Install AIChat and AIChat-NG Rust CLI tools
set -euo pipefail
# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/packages.sh"

echo "[37-aichat] Installing AI-related packages (redis, sqlite)..."
install_packages "ai"

echo "[37-aichat] Installing AIChat and AIChat-NG binaries..."
# ... (rest of the script)

# Fetch latest release tags
# v0.2.0: Wrap in subshell + || true to prevent pipefail from killing the script if API is down
AICHAT_TAG=$( (scurl -s https://api.github.com/repos/sigoden/aichat/releases/latest | grep -Po '"tag_name": "\K.*?(?=")') 2>/dev/null || true)
AICHAT_NG_TAG=$( (scurl -s https://api.github.com/repos/blob42/aichat-ng/releases/latest | grep -Po '"tag_name": "\K.*?(?=")') 2>/dev/null || true)

# Fallbacks if API fails
if [[ -z "$AICHAT_TAG" ]]; then
    AICHAT_TAG="v0.25.0"
    echo "[37-aichat]   AIChat API unavailable — using fallback ${AICHAT_TAG}"
else
    echo "[37-aichat]   Detected AIChat version: ${AICHAT_TAG}"
fi

if [[ -z "$AICHAT_NG_TAG" ]]; then
    AICHAT_NG_TAG="v0.25.0"
    echo "[37-aichat]   AIChat-NG API unavailable — using fallback ${AICHAT_NG_TAG}"
else
    echo "[37-aichat]   Detected AIChat-NG version: ${AICHAT_NG_TAG}"
fi

# Download and install AIChat
scurl -L -o /tmp/aichat.tar.gz "https://github.com/sigoden/aichat/releases/download/${AICHAT_TAG}/aichat-${AICHAT_TAG}-x86_64-unknown-linux-musl.tar.gz"
tar -xzf /tmp/aichat.tar.gz -C /usr/bin/ aichat
chmod +x /usr/bin/aichat

# Download and install AIChat-NG
scurl -L -o /tmp/aichat-ng.tar.gz "https://github.com/blob42/aichat-ng/releases/download/${AICHAT_NG_TAG}/aichat-ng-${AICHAT_NG_TAG}-x86_64-unknown-linux-musl.tar.gz"
tar -xzf /tmp/aichat-ng.tar.gz -C /usr/bin/ aichat-ng
chmod +x /usr/bin/aichat-ng

# Cleanup
rm -f /tmp/aichat.tar.gz /tmp/aichat-ng.tar.gz

echo "[37-aichat] AIChat and AIChat-NG installed successfully."
```

---

## automation/37-flatpak-env.sh

```bash
#!/bin/bash
# MiOS v0.2.0  37-flatpak-env: Capture Flatpak environment for boot-time install
set -euo pipefail

echo "?"
echo "  MiOS v0.2.0  Flatpak Environment"
echo "?"

# Directory for MiOS system-level environment definitions (USR-OVER-ETC compliance)
# Using /usr/lib/mios/env.d as a "venv/env" style storage
mkdir -p /usr/lib/mios/env.d

# Capture MIOS_FLATPAKS if set (from build-arg)
# This creates a system-baked environment file that mios-flatpak-install can read.
ENV_FILE="/usr/lib/mios/env.d/flatpaks.env"

echo "# MiOS System Environment Definition" > "$ENV_FILE"
echo "# Generated at build time: $(date -u)" >> "$ENV_FILE"

if [[ -n "${MIOS_FLATPAKS:-}" ]]; then
    echo "MIOS_FLATPAKS=\"${MIOS_FLATPAKS}\"" >> "$ENV_FILE"
    echo "[37-flatpak-env] Captured MIOS_FLATPAKS to ${ENV_FILE}"
else
    echo "MIOS_FLATPAKS=\"\"" >> "$ENV_FILE"
    echo "[37-flatpak-env] MIOS_FLATPAKS not set, created empty env file."
fi

chmod 644 "$ENV_FILE"

echo "[37-flatpak-env] Flatpak environment configured in /usr."
```

---

## automation/37-ollama-prep.sh

```bash
#!/bin/bash
# 37-ollama-prep: Embed default LLM models during build
set -euo pipefail

# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"

# This script is intended for local builds to "bake in" the default coding model.
# It installs a temporary ollama binary, pulls the model, and cleans up.

# Only run if not already present (idempotency)
if [ -d "/var/lib/ollama/models" ] && [ "$(ls -A /var/lib/ollama/models)" ]; then
    log "Default models already present, skipping."
    exit 0
fi

log "Downloading default model: deepseek-coder-v2:lite..."

# Install temporary ollama binary from GitHub releases (.tar.zst archive)
# Standalone binary is no longer provided.
OLLAMA_URL="https://github.com/ollama/ollama/releases/latest/download/ollama-linux-amd64.tar.zst"
log "URL: $OLLAMA_URL"
scurl -L "$OLLAMA_URL" -o /tmp/ollama.tar.zst

# Extract archive to /usr (contains bin/ollama)
# Requires zstd to be installed in the build environment
if ! command -v zstd &>/dev/null; then
    log "ERROR: zstd not found. Installing explicitly..."
    $DNF_BIN "${DNF_SETOPT[@]}" install -y zstd
fi

diag "Extracting Ollama archive..."
# Create a temporary directory for extraction
mkdir -p /tmp/ollama-extract
tar --zstd -xvf /tmp/ollama.tar.zst -C /tmp/ollama-extract

# Find the binary and move it to /usr/bin/ollama
OLLAMA_BIN=$(find /tmp/ollama-extract -type f -name "ollama" | head -n 1)
if [[ -z "$OLLAMA_BIN" ]]; then
    log "ERROR: ollama binary not found in archive."
    diag "Archive contents:"
    tar --zstd -tvf /tmp/ollama.tar.zst
    exit 1
fi

mv "$OLLAMA_BIN" /usr/bin/ollama
chmod +x /usr/bin/ollama
rm -rf /tmp/ollama-extract

# Validation
if ! command -v ollama &>/dev/null; then
    log "ERROR: ollama binary not found in PATH."
    exit 1
fi

if ! file /usr/bin/ollama | grep -q "ELF"; then
    log "ERROR: /usr/bin/ollama is not a valid ELF binary."
    exit 1
fi

# Start ollama serve in background
# We bake models into /usr/share to ensure they are captured by bootc/composefs
# and then link them into /var/lib/ollama at runtime.
BAKE_PATH="/usr/share/ollama/models"
mkdir -p "$BAKE_PATH"
export OLLAMA_MODELS="$BAKE_PATH"

/usr/bin/ollama serve &
OLLAMA_PID=$!

# Wait for server to be ready
log "Waiting for Ollama server to start..."
MAX_RETRIES=15
COUNT=0
while ! scurl -s http://localhost:11434/api/tags > /dev/null; do
    sleep 2
    COUNT=$((COUNT + 1))
    if [ $COUNT -ge $MAX_RETRIES ]; then
        log "ERROR: Ollama server failed to start."
        kill $OLLAMA_PID
        exit 1
    fi
done

# Pull the model
/usr/bin/ollama pull deepseek-coder-v2:lite

# Shutdown server
kill $OLLAMA_PID
wait $OLLAMA_PID || true

# Cleanup
rm -f /tmp/ollama.tar.zst
# We keep the binary in /usr/bin as it's part of the image now
# unless the user wanted it temporary? The script previously rm -f /tmp/ollama.
# Let's keep it temporary to match original intent of "prep" if needed, 
# but usually we want ollama available. 
# Original script: rm -f /tmp/ollama.
# If I want to match original intent: rm -f /usr/bin/ollama
# But wait, 37-ollama.sh (if it exists) would install it. 
# Let's check if ollama is in PACKAGES.md as a permanent package.

echo "[37-ollama-prep] Model embedded successfully."
```

---

## automation/37-selinux.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 37-selinux: Build-time SELinux policy fixes
# Custom per-rule modules for known Fedora Rawhide / systemd 260 denials.
set -euo pipefail

echo "[37-selinux] Applying SELinux build-time fixes..."

# ═══ Restorecon — fix labels for all major trees ═══
if command -v restorecon &>/dev/null; then
    echo "[37-selinux] Running restorecon on /boot /etc /usr /var..."
    restorecon -R /boot /etc /usr /var 2>/dev/null || true
fi

# ═══ Semanage import — atomic booleans + fcontexts ═══
if command -v semanage &>/dev/null; then
    echo "[37-selinux] Applying SELinux booleans and fcontexts..."
    semanage import <<'EOSEM' 2>/dev/null || true
boolean -m --on container_manage_cgroup
boolean -m --on container_use_cephfs
boolean -m --on daemons_dump_core
boolean -m --on domain_can_mmap_files
boolean -m --on virt_sandbox_use_all_caps
boolean -m --on virt_use_nfs
boolean -m --on virt_use_samba
boolean -m --on nis_enabled
fcontext -a -t boot_t '/boot/bootupd-state.json'
fcontext -a -t accountsd_var_lib_t '/usr/share/accountsservice/interfaces(/.*)?'
fcontext -a -t ceph_var_lib_t '/var/lib/ceph(/.*)?'
fcontext -a -t ceph_log_t '/var/log/ceph(/.*)?'
fcontext -a -t xdm_var_lib_t '/var/lib/gnome-remote-desktop(/.*)?'
EOSEM
    restorecon -v /boot/bootupd-state.json 2>/dev/null || true
    restorecon -R /usr/share/accountsservice 2>/dev/null || true
    restorecon -R /var/lib/gnome-remote-desktop 2>/dev/null || true
    echo "[37-selinux] ✓ Booleans and fcontexts applied"
fi

# ═══ Custom policy modules ═══
if command -v checkmodule &>/dev/null && command -v semodule_package &>/dev/null; then
    echo "[37-selinux] Building custom SELinux policy modules..."

    SELINUX_OK=0
    SELINUX_FAIL=0

    declare -A MIOS_POLICIES

    MIOS_POLICIES[bootupd]='
module mios_bootupd 1.0;
require { type boot_t; type bootupd_t; class file { read getattr open }; }
allow bootupd_t boot_t:file { read getattr open };'

    MIOS_POLICIES[accountsd]='
module mios_accountsd 1.0;
require { type accountsd_t; class lnk_file { read getattr }; }
allow accountsd_t self:lnk_file { read getattr };'

    MIOS_POLICIES[resolved]='
module mios_resolved 1.0;
require { type systemd_resolved_t; type init_var_run_t; class sock_file write; }
allow systemd_resolved_t init_var_run_t:sock_file write;'

    MIOS_POLICIES[fapolicyd]='
module mios_fapolicyd 1.0;
require { type fapolicyd_t; type xdm_var_run_t; class sock_file write; }
allow fapolicyd_t xdm_var_run_t:sock_file write;'

    MIOS_POLICIES[chcon]='
module mios_chcon 1.0;
require { type chcon_t; class capability mac_admin; }
allow chcon_t self:capability mac_admin;'

    MIOS_POLICIES[accountsd_homed]='
module mios_accountsd_homed 1.0;
require { type accountsd_t; type systemd_homed_t; class dbus send_msg; }
allow accountsd_t systemd_homed_t:dbus send_msg;
allow systemd_homed_t accountsd_t:dbus send_msg;'

    MIOS_POLICIES[accountsd_watch]='
module mios_accountsd_watch 1.0;
require { type accountsd_t; type usr_t; class dir { watch watch_reads }; }
allow accountsd_t usr_t:dir { watch watch_reads };'

    MIOS_POLICIES[fapolicyd_gdm]='
module mios_fapolicyd_gdm 1.1;
require { type fapolicyd_t; type xdm_t; class unix_stream_socket connectto; class fd use; class fifo_file write; }
allow fapolicyd_t xdm_t:unix_stream_socket connectto;
allow fapolicyd_t xdm_t:fd use;
allow fapolicyd_t xdm_t:fifo_file write;'

    MIOS_POLICIES[fapolicyd_grd]='
module mios_fapolicyd_grd 1.0;
require { type fapolicyd_t; type gnome_remote_desktop_t; class unix_stream_socket connectto; class fd use; class fifo_file write; }
allow fapolicyd_t gnome_remote_desktop_t:unix_stream_socket connectto;
allow fapolicyd_t gnome_remote_desktop_t:fd use;
allow fapolicyd_t gnome_remote_desktop_t:fifo_file write;'

    MIOS_POLICIES[portabled]='
module mios_portabled 1.0;
require { type init_t; type systemd_portabled_t; class dbus send_msg; }
allow init_t systemd_portabled_t:dbus send_msg;
allow systemd_portabled_t init_t:dbus send_msg;'

    MIOS_POLICIES[kvmfr]='
module mios_kvmfr 1.0;
require { type svirt_t; type device_t; class chr_file { open read write map getattr }; }
allow svirt_t device_t:chr_file { open read write map getattr };'

    MIOS_POLICIES[coreos_bootmount]='
module mios_coreos_bootmount 1.0;
require { type coreos_boot_mount_generator_t; type systemd_generator_unit_file_t; class dir { write add_name remove_name }; class file { create write open rename unlink }; }
allow coreos_boot_mount_generator_t systemd_generator_unit_file_t:dir { write add_name remove_name };
allow coreos_boot_mount_generator_t systemd_generator_unit_file_t:file { create write open rename unlink };'

    MIOS_POLICIES[gdm_cache]='
module mios_gdm_cache 1.0;
require { type xdm_t; type cache_home_t; class dir { add_name write create setattr }; class file { create write open getattr setattr }; }
allow xdm_t cache_home_t:dir { add_name write create setattr };
allow xdm_t cache_home_t:file { create write open getattr setattr };'

    MIOS_POLICIES[homed_varhome]='
module mios_homed_varhome 1.0;
require { type systemd_homed_t; type home_root_t; class dir { read getattr open search }; }
allow systemd_homed_t home_root_t:dir { read getattr open search };'

    MIOS_POLICIES[bootupd_state]='
module mios_bootupd_state 1.1;
require { type bootupd_t; type boot_t; class file { read open getattr lock ioctl }; class dir { read open getattr search }; }
allow bootupd_t boot_t:file { read open getattr lock ioctl };
allow bootupd_t boot_t:dir { read open getattr search };'

    MIOS_POLICIES[resolved_hook]='
module mios_resolved_hook 1.0;
require { type systemd_resolved_t; type init_t; class unix_stream_socket connectto; class sock_file write; }
allow systemd_resolved_t init_t:unix_stream_socket connectto;
allow systemd_resolved_t init_t:sock_file write;'

    MIOS_POLICIES[accountsd_malcontent]='
module mios_accountsd_malcontent 1.0;
require { type accountsd_t; type usr_t; class lnk_file { read getattr }; class file { read open getattr ioctl }; class dir { read open getattr search }; }
allow accountsd_t usr_t:lnk_file { read getattr };
allow accountsd_t usr_t:file { read open getattr ioctl };
allow accountsd_t usr_t:dir { read open getattr search };'

    MIOS_POLICIES[chcon_macadmin]='
module mios_chcon_macadmin 1.0;
require { type chcon_t; class capability2 mac_admin; }
allow chcon_t self:capability2 mac_admin;'

    MIOS_POLICIES[gdm_session_cache]='
module mios_gdm_session_cache 1.0;
require { type xdm_t; type cache_home_t; class dir { add_name write create read open getattr search setattr }; class file { create write read open getattr setattr }; }
allow xdm_t cache_home_t:dir { add_name write create read open getattr search setattr };
allow xdm_t cache_home_t:file { create write read open getattr setattr };'

    mkdir -p /usr/share/selinux/packages/mios

    for name in "${!MIOS_POLICIES[@]}"; do
        echo "${MIOS_POLICIES[$name]}" > "/tmp/mios_${name}.te"
        if checkmodule -M -m -o "/tmp/mios_${name}.mod" "/tmp/mios_${name}.te" 2>/dev/null && \
           semodule_package -o "/tmp/mios_${name}.pp" -m "/tmp/mios_${name}.mod" 2>/dev/null; then
            install -m 0644 "/tmp/mios_${name}.pp" "/usr/share/selinux/packages/mios/mios_${name}.pp"
            echo "[37-selinux] mios_${name}: Staged"
            SELINUX_OK=$((SELINUX_OK + 1))
        else
            echo "[37-selinux] mios_${name}: SKIPPED (type missing in current policy)"
            SELINUX_FAIL=$((SELINUX_FAIL + 1))
        fi
        rm -f "/tmp/mios_${name}".{te,mod,pp}
    done

    echo "[37-selinux] ${SELINUX_OK} policies staged in /usr/share/selinux/packages/mios/, ${SELINUX_FAIL} skipped"
fi

echo "[37-selinux] SELinux configuration complete."
```

---

## automation/38-vm-gating.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 38-vm-gating: VM service gating + Hyper-V Enhanced Session
#
# v0.2.0 CRITICAL FIX: GNOME 50 / Mutter 50 completely removed the X11 backend.
# xorgxrdp is an X11 technology — it CANNOT work with Wayland-only Mutter 50.
# The old approach caused a GDM crash loop on Hyper-V, preventing boot.
#
# NEW APPROACH: Use gnome-remote-desktop (GRD) for Enhanced Session.
# GRD provides Wayland-native RDP and can bind to vsock for Hyper-V transport.
# xrdp is kept installed but NOT auto-enabled — it's available as a manual
# fallback for non-GNOME sessions (XFCE, Phosh) only.
#
# HYPER-V BOOT PATH (without Enhanced Session):
#   hyperv_drm → KMS → GDM (Wayland) → llvmpipe software rendering → login
# HYPER-V ENHANCED SESSION PATH:
#   vmconnect → vsock:3389 → gnome-remote-desktop (Wayland RDP) → login
set -euo pipefail

echo "[38-vm-gating] Configuring VM-specific service gating..."

# ═══ GDM / nvidia-powerd / Waydroid + binder gating ═══
# Drop-ins for gdm, nvidia-powerd, waydroid-container, dev-binderfs.mount are
# created by 20-services.sh (WSL_SKIP_SERVICES + bare-metal nvidia-powerd block).
# Do NOT duplicate them here — last writer wins and we want 20's canonical drop-ins.

# ═══ Polkit container workaround ═══
# Managed via usr/lib/systemd/system/polkit.service.d/10-mios-container.conf

# ═══ Cockpit socket drop-in permissions ═══
if [ -f /usr/lib/systemd/system/cockpit.socket.d/listen.conf ]; then
    chmod 644 /usr/lib/systemd/system/cockpit.socket.d/listen.conf
fi

# ═══════════════════════════════════════════════════════════════════════════
# HYPER-V ENHANCED SESSION — WAYLAND-NATIVE VIA GNOME REMOTE DESKTOP
# ═══════════════════════════════════════════════════════════════════════════
echo "[38-vm-gating] Configuring Hyper-V Enhanced Session (gnome-remote-desktop)..."

# 1. Blacklist VMware vsock (conflicts with Hyper-V hv_sock)
# Managed via usr/lib/modprobe.d/blacklist-vmw_vsock.conf

# 2. Ensure hv_sock loads on boot (required for vsock RDP transport)
if ! grep -q 'hv_sock' /usr/lib/modules-load.d/mios.conf 2>/dev/null; then
    echo "hv_sock" >> /usr/lib/modules-load.d/mios.conf
fi

# 3. Polkit rule for colord (prevents "not authorized" errors in RDP sessions)
# Managed via usr/share/polkit-1/rules.d/45-allow-colord.rules

# 4. Hyper-V Enhanced Session service — uses gnome-remote-desktop
# Managed via usr/lib/systemd/system/mios-hyperv-enhanced.service
# and usr/libexec/mios-hyperv-enhanced
systemctl enable mios-hyperv-enhanced.service 2>/dev/null || true

# 5. GNOME Remote Desktop — first-boot setup script
# mios-grd-setup is installed via system_files overlay (08-system-files-overlay.sh)
# into /usr/libexec/mios-grd-setup. No copy needed here.
chmod +x /usr/libexec/mios-grd-setup 2>/dev/null || true

# ── WSL2 systemd-machined gating ─────────────────────────────────────────
# dbus-broker.service.d/wsl2-fix.conf is provided by system_files overlay
# (OOMScoreAdjust only; --audit removal is in 10-mios-no-audit.conf).
# Do NOT overwrite it here — previous versions wrote a broken drop-in with
# ConditionPathExists=|/proc/version which is always true and caused dbus
# to be misconfigured on bare metal.

# Ensure systemd-machined doesn't block dbus in WSL2
# Managed via usr/lib/systemd/system/systemd-machined.service.d/wsl2-optional.conf

echo "[38-vm-gating] VM gating + Hyper-V Enhanced Session (gnome-remote-desktop) configured."
```

---

## automation/39-desktop-polish.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 39-desktop-polish: Desktop entries, Cockpit webapp, MOTD
#
# CHANGELOG v0.2.0:
#   - FIX: mios-motd source path was /tmp/automation/automation/ (never exists).
#     Scripts run from /ctx/automation/ in the buildroot. The bogus path + the
#     `|| true` swallowed the failure silently, so /usr/libexec/mios-motd
#     was never created. profile.d/mios-motd.sh falls back to it when
#     fastfetch is missing, so terminal MOTD printed nothing on every
#     v2.0-v2.2 image.
#   - FIX: SCRIPT_DIR-relative copy so this works whether build.sh invokes
#     us from /ctx/automation/ or any other future path. If the source is
#     missing, FAIL LOUDLY (remove the silencing `|| true`) so it can't
#     regress unnoticed.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[39-desktop-polish] Final desktop polish..."

# ═══ COCKPIT DESKTOP ENTRY — uses cockpit-desktop (no TLS warnings) ═══
echo "[39-desktop-polish] Cockpit desktop entry delivered via overlay."

# ═══ NVIDIA SETTINGS DESKTOP ENTRY ═══
echo "[39-desktop-polish] NVIDIA Settings desktop entry delivered via overlay."

# ═══ CEPH DASHBOARD — update to use correct app name ═══
echo "[39-desktop-polish] Ceph Dashboard desktop entry delivered via overlay."

# ═══ MOTD DASHBOARD ═══
# v0.2.0: ARCHITECTURAL PURITY FIX. The MOTD script is now delivered via the
# system_files overlay to /usr/libexec/mios/motd. We no longer perform
# manual 'install' calls here.
echo "[39-desktop-polish] MOTD dashboard delivered via overlay."

# ═══ FASTFETCH CONFIG — services dashboard on terminal open ═══
echo "[39-desktop-polish] Fastfetch config delivered via overlay."

# ═══ PROFILE.D — fastfetch + MOTD on terminal/TTY open ═══
echo "[39-desktop-polish] Profile.d MOTD script delivered via overlay."

echo "[39-desktop-polish] Desktop polish complete."
```

---

## automation/40-composefs-verity.sh

```bash
#!/usr/bin/env bash
# 40-composefs-verity.sh - promote composefs from default (yes) to verity mode
# Tamper-evident root. Requires ext4 or btrfs target FS (NOT xfs).
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"

conf=/usr/lib/ostree/prepare-root.conf
if [[ -f "$conf" ]]; then
    log "backing up existing $conf -> ${conf}.orig"
    cp -a "$conf" "${conf}.orig"
fi

cat > "$conf" <<'EOF'
# MiOS: composefs in verity mode. Tamper-evident root.
# Target filesystems must support fsverity (ext4, btrfs). XFS is NOT supported.
[composefs]
enabled = verity

[root]
transient = false

[etc]
transient = false
EOF

# Mask systemd-remount-fs (known-broken with composefs on F42+)
log "masking systemd-remount-fs.service (composefs interop bug)"
ln -sf /dev/null /etc/systemd/system/systemd-remount-fs.service

log "composefs verity mode configured"```

---

## automation/42-cosign-policy.sh

```bash
#!/usr/bin/env bash
# ============================================================================
# automation/42-cosign-policy.sh - MiOS v0.2.0
# ----------------------------------------------------------------------------
# Consolidates cosign binary installation, Sigstore trust roots, and policy.json.
# Supercedes 37-cosign-policy.sh.
#
# Note: we pin to v0.2.0 because v3 breaks rpm-ostree bundle format (OCI 1.1).
# ============================================================================
set -euo pipefail

# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"

log "42-cosign-policy: ensuring cosign + trust roots + policy.json"

# 1. Install cosign binary (pinned to v2.x for rpm-ostree compatibility)
if ! command -v cosign >/dev/null 2>&1; then
    log "  downloading cosign v0.2.0 static binary..."
    scurl "https://github.com/sigstore/cosign/releases/download/v0.2.0/cosign-linux-amd64" -o /usr/local/bin/cosign
    chmod +x /usr/local/bin/cosign
fi

SYSFILES="/ctx/system_files"
# Paths updated to /usr/share/pki and /usr/lib/containers as per USR-OVER-ETC
install -d -m 0755 /usr/share/pki/containers
install -d -m 0755 /usr/lib/containers/registries.d

# 2. Install policy.json
# v0.2.0: Moved from etc/ to usr/lib/ in system_files
if [[ -f "${SYSFILES}/usr/lib/containers/policy.json" ]]; then
    install -m 0644 "${SYSFILES}/usr/lib/containers/policy.json" /usr/lib/containers/policy.json
    log "  installed /usr/lib/containers/policy.json"
else
    # Fallback to in-image path if ctx is missing (unlikely in build)
    [[ -f /usr/lib/containers/policy.json ]] || warn "missing policy.json"
fi

# 3. Install Sigstore TUF roots and public keys
# These ship via the usr/share/pki/containers/ overlay
for f in fulcio_v1.crt.pem rekor.pub ublue-os.pub ublue-cosign.pub mios-cosign.pub; do
    src="${SYSFILES}/usr/share/pki/containers/${f}"
    dst="/usr/share/pki/containers/${f}"
    if [[ -f "${src}" ]]; then
        install -m 0644 "${src}" "${dst}"
        log "  installed ${dst}"
    fi
done

# 4. JSON Sanity Check
if command -v jq >/dev/null 2>&1 && [[ -f /usr/lib/containers/policy.json ]]; then
    jq -e . /usr/lib/containers/policy.json >/dev/null || die "policy.json failed jq parse"
    log "  policy.json parses cleanly"
fi

log "42-cosign-policy: validation complete"
```

---

## automation/43-uupd-installer.sh

```bash
#!/usr/bin/env bash
# 43-uupd-installer.sh - install uupd + greenboot (from PACKAGES.md
# packages-updater section) and disable the updaters it supersedes.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/lib/common.sh"
# shellcheck disable=SC1091
source "${SCRIPT_DIR}/lib/packages.sh"

# COPR already enabled by 05-enable-external-repos.sh (runs earlier)
install_packages "updater"

# Disable the updaters uupd supersedes
systemctl disable bootc-fetch-apply-updates.timer 2>/dev/null || true
systemctl disable rpm-ostreed-automatic.timer     2>/dev/null || true

# Enable uupd.timer (shipped by the package)
WANTS=/usr/lib/systemd/system/multi-user.target.wants
install -d -m 0755 "${WANTS}"
if [[ -f "/usr/lib/systemd/system/uupd.timer" ]]; then
    ln -sf ../uupd.timer "${WANTS}/uupd.timer"
    log "Enabled uupd.timer"
else
    warn "uupd.timer not present (uupd install may have failed)"
fi

log "uupd configured; bootc-fetch-apply-updates.timer and rpm-ostreed-automatic.timer disabled"```

---

## automation/44-podman-machine-compat.sh

```bash
#!/usr/bin/env bash
# 44-podman-machine-compat.sh - Podman-machine backend compatibility.
# Package installs moved to PACKAGES.md (packages-containers, packages-utils).
# This script only does the runtime config that cannot be expressed as packages:
#   - create the 'core' user (Podman machine convention)
#   - enable services needed for machine backend operation
#
# v0.2.0 fix:
#   - Pre-create the `video`, `render`, `kvm`, `libvirt` groups if missing so
#     useradd -G doesn't die with "group does not exist". The ucore-hci base
#     ships udev rules that create these groups dynamically at runtime, but
#     during the image build they're absent.
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"

log "Hardware groups are pre-created globally by 31-user.sh"

# Create the 'core' user if missing (Podman machine convention).
# Managed via /usr/lib/sysusers.d/20-podman-machine.conf (declarative).
# We apply sysusers here to ensure 'core' exists for any subsequent operations.
systemd-sysusers --root=/ 2>/dev/null || true

if id -u core >/dev/null 2>&1; then
    passwd -l core 2>/dev/null || true
    log "user 'core' initialized (declarative; key-auth only)"
else
    warn "Failed to initialize 'core' user via sysusers"
fi

# Enable core services for Podman-machine and cloud-init entry
WANTS=/usr/lib/systemd/system/multi-user.target.wants
install -d -m 0755 "${WANTS}"

log "Enabling Podman Machine and cloud-init services..."
for unit in \
    sshd.service \
    podman.socket \
    qemu-guest-agent.service \
    cloud-init.service \
    cloud-final.service
do
    if [[ -f "/usr/lib/systemd/system/${unit}" ]]; then
        ln -sf "../${unit}" "${WANTS}/${unit}"
        log "Enabled ${unit}"
    else
        warn "${unit} not found, skipping enablement."
    fi
done

log "podman-machine compatibility wired"
```

---

## automation/45-nvidia-cdi-refresh.sh

```bash
#!/usr/bin/env bash
# 45-nvidia-cdi-refresh.sh - wire up NVIDIA CDI auto-refresh services.
# Package installs live in PACKAGES.md (packages-gpu-nvidia section).
#
# Key invariants:
#   - nvidia-container-toolkit ≥ 1.18 for nvidia-cdi-refresh.service/path.
#   - Avoid NCT 1.16.2: "unresolvable CDI devices" regression. Use 1.16.1 or 1.18+.
#   - Remove oci-nvidia-hook.json: dual injection with CDI causes conflicts.
#   - CDI canonical path: /var/run/cdi/nvidia.yaml (runtime) or /etc/cdi/nvidia.yaml (persistent).
#   - NVIDIA kmods blacklisted by default; 34-gpu-detect.sh removes blacklist on bare metal.
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"

# Remove legacy OCI hook — conflicts with CDI when both are present.
OCI_HOOK=/usr/share/containers/oci/hooks.d/oci-nvidia-hook.json
if [[ -f "$OCI_HOOK" ]]; then
    log "removing legacy OCI nvidia hook (conflicts with CDI)"
    rm -f "$OCI_HOOK"
fi

# Pin nvidia-container-toolkit version in the CDI env file.
# The systemd service reads this at boot via EnvironmentFile.
install -d -m 0755 /etc/nvidia-container-toolkit
cat >/etc/nvidia-container-toolkit/cdi-refresh.env <<'EOF'
# Managed by 45-nvidia-cdi-refresh.sh
# CDI output path — runtime location preferred by bootc (ephemeral, cleared on boot).
CDI_OUTPUT_PATH=/var/run/cdi/nvidia.yaml
# Debug logging — set to 1 for troubleshooting.
NVIDIA_CTK_DEBUG=0
EOF
chmod 0644 /etc/nvidia-container-toolkit/cdi-refresh.env

# Enable units using build-safe symlinks
WANTS=/usr/lib/systemd/system/multi-user.target.wants
install -d -m 0755 "${WANTS}"

log "Enabling NVIDIA CDI units..."
for unit in \
    nvidia-cdi-refresh.path \
    nvidia-cdi-refresh.service \
    nvidia-persistenced.service \
    mios-nvidia-cdi.service
do
    if [[ -f "/usr/lib/systemd/system/${unit}" ]]; then
        ln -sf "../${unit}" "${WANTS}/${unit}"
        log "Enabled ${unit}"
    else
        warn "${unit} not found, skipping enablement."
    fi
done

# Ensure CDI persistent dir exists; tmpfiles.d/mios-gpu.conf creates the runtime dir.
install -d -m 0755 /etc/cdi

log "CDI refresh pipeline configured"
```

---

## automation/46-greenboot.sh

```bash
#!/usr/bin/env bash
# 46-greenboot.sh - wire greenboot services; package installs via PACKAGES.md
# (packages-updater section: greenboot, greenboot-default-health-checks).
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"

# Enable core greenboot services
WANTS=/usr/lib/systemd/system/multi-user.target.wants
install -d -m 0755 "${WANTS}"

log "Enabling Greenboot services..."
for unit in \
    greenboot-healthcheck.service \
    greenboot-rpm-ostree-grub2-check-fallback.service \
    greenboot-grub2-set-counter.service \
    greenboot-grub2-set-success.service \
    greenboot-status.service \
    redboot-auto-reboot.service
do
    if [[ -f "/usr/lib/systemd/system/${unit}" ]]; then
        ln -sf "../${unit}" "${WANTS}/${unit}"
        log "Enabled ${unit}"
    else
        warn "${unit} not installed, skipping enablement."
    fi
done

# Make health-check scripts executable (shipped via )
# Directory creation and config installation moved to  overlay.
chmod +x /etc/greenboot/check/required.d/*.sh 2>/dev/null || true
chmod +x /etc/greenboot/check/wanted.d/*.sh   2>/dev/null || true
chmod +x /etc/greenboot/green.d/*.sh          2>/dev/null || true
chmod +x /etc/greenboot/red.d/*.sh            2>/dev/null || true

log "greenboot wired"
```

---

## automation/47-hardening.sh

```bash
#!/usr/bin/env bash
# 47-hardening.sh - enable hardening services (USBGuard, auditd).
# Package installs moved to PACKAGES.md (packages-security).
# sysctl drop-in shipped via usr/lib/sysctl.d/99-mios-hardening.conf.
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"

# USBGuard config is at /usr/lib/usbguard/usbguard-daemon.conf (managed via overlay).
chmod 0600 /usr/lib/usbguard/usbguard-daemon.conf 2>/dev/null || true

# Enable hardening services using build-safe symlinks
WANTS=/usr/lib/systemd/system/multi-user.target.wants
install -d -m 0755 "${WANTS}"

log "Enabling hardening services..."
for unit in \
    usbguard.service \
    auditd.service \
    fapolicyd.service
do
    if [[ -f "/usr/lib/systemd/system/${unit}" ]]; then
        ln -sf "../${unit}" "${WANTS}/${unit}"
        log "Enabled ${unit}"
    else
        warn "${unit} not installed, skipping enablement."
    fi
done

# Pre-generate fapolicyd trust database for bootc systems
# fapolicyd config is at /usr/lib/fapolicyd/fapolicyd.conf (managed via overlay).
if command -v fagenrules &>/dev/null; then
    log "Pre-generating fapolicyd trust database..."
    # Ensure correct permissions for the fapolicyd directory
    chown -R fapolicyd:fapolicyd /etc/fapolicyd 2>/dev/null || true
    fagenrules --load 2>/dev/null || true
    fapolicyd-cli --update 2>/dev/null || true
fi

log "hardening services wired"```

---

## automation/49-finalize.sh

```bash
#!/usr/bin/env bash
# 49-finalize.sh - final cleanup, systemd preset application, image linting
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"

# Apply all shipped presets now (so `systemctl is-enabled` reflects intent)
systemctl preset-all 2>/dev/null || true

# Set a safe build-time default target. Containers will reach this quickly.
# Bare-metal/VM roles will switch this to graphical.target/etc. at runtime.
systemctl set-default multi-user.target 2>/dev/null || true

# Ensure role directory exists with example config
mkdir -p /etc/mios
if [[ ! -f /etc/mios/role.conf ]]; then
    cp -a /usr/share/mios/role.conf.example /etc/mios/role.conf 2>/dev/null || true
fi

# Scrub potential credential leaks from build-time placeholder injections
log "scrubbing build-time credentials and override scripts"
rm -f /etc/containers/auth.json \
      /root/.docker/config.json \
      /root/.containers/auth.json \
      /ctx/automation/99-overrides.sh \
      /usr/local/bin/99-overrides.sh \
      /usr/bin/99-overrides.sh 2>/dev/null || true

# Trim dnf caches
dnf5 clean all || true
rm -rf /var/cache/libdnf5 /var/cache/dnf /var/log/dnf5.log* 2>/dev/null || true

# Set image metadata
MIOS_VERSION=$(cat /ctx/VERSION 2>/dev/null || echo "unknown")
echo "${MIOS_VERSION}" > /etc/mios-version
cat > /etc/mios/version <<EOF
MIOS_VERSION=${MIOS_VERSION}
MIOS_BASE=ucore-hci-stable-nvidia
MIOS_BUILT=$(date -u +%Y-%m-%dT%H:%M:%SZ)
EOF

log "finalize complete"
```

---

## automation/50-enable-log-copy-service.sh

```bash
#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"

log "Enabling MiOS build log copy service..."

WANTS=/usr/lib/systemd/system/multi-user.target.wants
install -d -m 0755 "${WANTS}"

if [[ -f "/usr/lib/systemd/system/mios-copy-build-log.service" ]]; then
    ln -sf ../mios-copy-build-log.service "${WANTS}/mios-copy-build-log.service"
    log "Enabled mios-copy-build-log.service"
else
    warn "mios-copy-build-log.service not found, skipping enablement."
fi
```

---

## automation/52-bake-kvmfr.sh

```bash
#!/usr/bin/env bash
# 52-bake-kvmfr.sh - compile Looking Glass kvmfr kmod against the ucore-hci
# kernel shipped in the base image, sign it with the ublue MOK, and bake the
# .ko into /usr/lib/modules/$KVER/extra/kvmfr/.
#
# This runs INSIDE the Containerfile build. No runtime compile. BAKED IN -
# WHEN POSSIBLE.
#
# v0.2.0 fix (supersedes 1.3.0):
#   The previous `if ! dnf5 -y install ... 2>/dev/null; then ... fi` plus
#
#       AVAIL_REPO="$(dnf5 --showduplicates repoquery ... | tail -5 | tr ...)"
#
#   was tripping the whole script with exit 2 BEFORE reaching the graceful-
#   skip block. Root cause: `VAR="$(failing-pipeline)"` under set -euo pipefail
#   causes set -e to fire on the assignment when the pipeline's first command
#   exits non-zero (pipefail promotes the failure). Verified with a reproducer.
#
#   Fix: wrap every dnf5/rpm/dnf5-repoquery call in an explicit
#   `set +e` / `RC=$?` / `set -e` guard. Drop the unreliable repoquery
#   diagnostic entirely - the log line is still informative without it.
#   Looking Glass still runs IVSHMEM-only without kvmfr.
set -euo pipefail

# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"

# --- Detect the kernel version shipped in the base image -------------------
KVER="$(find /usr/lib/modules/ -mindepth 1 -maxdepth 1 -printf "%f\n" 2>/dev/null | sort -V | tail -1)"
if [[ -z "$KVER" ]]; then
    warn "no kernel modules directory; cannot determine kernel version"
    warn "skipping kvmfr bake - Looking Glass will run in IVSHMEM-only mode"
    exit 0
fi
log "building against kernel: $KVER"

# --- Try to get kernel-devel-$KVER exactly matched -------------------------
if [[ ! -d "/usr/src/kernels/$KVER" ]]; then
    log "installing kernel-devel-$KVER"
    set +e
    $DNF_BIN "${DNF_SETOPT[@]}" install -y "${DNF_OPTS[@]}" "kernel-devel-$KVER" >/dev/null 2>&1
    RC=$?
    set -e
    if [[ $RC -ne 0 ]]; then
        set +e
        AVAIL="$(rpm -qa 'kernel-devel*' 2>/dev/null | tr '\n' ' ')"
        set -e
        warn "SKIP: no exact kernel-devel for $KVER (dnf rc=$RC; installed: ${AVAIL:-none})"
        warn "      The ucore-hci base kernel $KVER is typically newer/older than"
        warn "      F44's repo-published kernel-devel. Project principle is 'never"
        warn "      upgrade base kernel in-container', so kvmfr is skipped here."
        warn "      Looking Glass still works in IVSHMEM-only mode. To enable kvmfr"
        warn "      on the booted image once the kernel matches, run:"
        warn "         sudo dnf install kernel-devel-\$(uname -r) akmod-kvmfr"
        warn "         sudo akmods --force --kernels \$(uname -r)"
        exit 0
    fi
fi

# --- Install akmod-kvmfr (from hikariknight/looking-glass-kvmfr COPR) ------
log "installing akmod-kvmfr"
set +e
$DNF_BIN "${DNF_SETOPT[@]}" install -y "${DNF_OPTS[@]}" akmod-kvmfr >/dev/null 2>&1
RC=$?
set -e
if [[ $RC -ne 0 ]]; then
    warn "SKIP: akmod-kvmfr install failed (rc=$RC; COPR unreachable or package missing)"
    warn "      verify COPR enabled: dnf5 copr list | grep looking-glass-kvmfr"
    exit 0
fi

# --- Force-build kvmfr kmod for this kernel --------------------------------
log "running akmods --force --kernels $KVER"
set +e
akmods --force --kernels "$KVER" 2>&1 | sed 's/^/[akmods] /'
RC=${PIPESTATUS[0]}
set -e
if [[ $RC -ne 0 ]]; then
    warn "SKIP: akmods build failed (rc=$RC)"
    warn "      checking /var/cache/akmods/kvmfr/ for build log..."
    find /var/cache/akmods/ -name '*.log' -exec tail -50 {} \; 2>/dev/null || true
    exit 0
fi

# --- Verify the kmod landed -------------------------------------------------
KMOD_PATH="/usr/lib/modules/$KVER/extra/kvmfr/kvmfr.ko"
if [[ -f "$KMOD_PATH" ]] || [[ -f "${KMOD_PATH}.xz" ]] || [[ -f "${KMOD_PATH}.zst" ]]; then
    log "OK: kvmfr.ko baked in at /usr/lib/modules/$KVER/extra/kvmfr/"
    ls -la "/usr/lib/modules/$KVER/extra/kvmfr/"
else
    warn "SKIP: kvmfr.ko NOT FOUND after akmods build"
    warn "      listing /usr/lib/modules/$KVER/extra/:"
    ls -la "/usr/lib/modules/$KVER/extra/" 2>/dev/null || warn "  (no extra/ dir)"
    exit 0
fi

# --- Update module dependencies --------------------------------------------
log "running depmod -a -b /usr $KVER"
depmod -a -b /usr "$KVER" || warn "depmod failed (non-fatal)"

# --- Sign the module with ublue MOK (if present, for Secure Boot) ----------
PRIV_KEY="/etc/pki/akmods/private/private_key.priv"
PUB_KEY="/etc/pki/akmods/certs/public_key.der"
if [[ -f "$PRIV_KEY" && -f "$PUB_KEY" ]]; then
    log "signing kvmfr.ko with akmods private key"
    SIGN_FILE="/usr/src/kernels/$KVER/automation/sign-file"
    if [[ -x "$SIGN_FILE" ]]; then
        for ko in /usr/lib/modules/$KVER/extra/kvmfr/*.ko; do
            [[ -f "$ko" ]] && "$SIGN_FILE" sha256 "$PRIV_KEY" "$PUB_KEY" "$ko" && \
                log "  signed: $ko"
        done
    else
        warn "sign-file script not found at $SIGN_FILE; kvmfr unsigned"
    fi
else
    log "NOTE: ublue MOK private key not in image (expected); users enroll MOK"
    log "      and kvmfr will use the public cert shipped by ublue-os-akmods-addons"
fi

log "kvmfr kmod BAKED IN"
```

---

## automation/53-bake-lookingglass-client.sh

```bash
#!/usr/bin/env bash
# 53-bake-lookingglass-client.sh - git clone Looking Glass B7, cmake/make,
# install looking-glass-client binary to /usr/bin/. BAKED IN - WHEN POSSIBLE.
#
# v0.2.0 fix:
#   - SKIP (don't fail) when cmake or required dev libraries are missing.
#     12-virt.sh already builds Looking Glass as part of its virtualization
#     stack and then removes cmake/gcc/*-devel to shrink the image. By the
#     time this script runs the toolchain is gone. Skipping here is safe
#     because the binary is already installed by 12-virt.sh; a hard-fail
#     aborted the whole build for a redundant second build attempt.
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"

# --- If 12-virt.sh already baked it in, declare success and exit -----------
if [[ -x /usr/bin/looking-glass-client ]]; then
    log "OK: looking-glass-client already present (installed by 12-virt.sh)"
    /usr/bin/looking-glass-client --version 2>&1 | head -5 || true
    exit 0
fi

# --- Check toolchain availability ------------------------------------------
MISSING=""
for tool in cmake make gcc git; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        MISSING="${MISSING}${tool} "
    fi
done

if [[ -n "$MISSING" ]]; then
    warn "SKIP: missing toolchain: $MISSING"
    warn "      12-virt.sh normally builds Looking Glass and removes cmake/gcc"
    warn "      afterwards. If 12-virt.sh failed, fix it first - the LG build"
    warn "      there is the canonical path."
    exit 0
fi

LG_BRANCH="${LG_BRANCH:-B7}"
BUILD_DIR="/tmp/LookingGlass-build"

# --- Clone -----------------------------------------------------------------
log "cloning Looking Glass $LG_BRANCH"
rm -rf "$BUILD_DIR"
if ! git clone --depth 1 --branch "$LG_BRANCH" --recurse-submodules \
        https://github.com/gnif/LookingGlass.git "$BUILD_DIR"; then
    warn "SKIP: git clone failed (network or branch issue)"
    exit 0
fi

# --- Configure + build client ---------------------------------------------
log "configuring client build"
mkdir -p "$BUILD_DIR/client/build"
cd "$BUILD_DIR/client/build"
if ! cmake -DCMAKE_INSTALL_PREFIX=/usr \
           -DCMAKE_INSTALL_LIBDIR=/usr/lib \
           -DCMAKE_BUILD_TYPE=Release \
           -DENABLE_LIBDECOR=ON \
           -DENABLE_PIPEWIRE=ON \
           -DENABLE_PULSEAUDIO=OFF \
           -DENABLE_BACKTRACE=OFF \
           ..; then
    warn "SKIP: cmake configure failed - check -devel packages"
    exit 0
fi

log "building looking-glass-client (jobs=$(nproc))"
if ! make -j"$(nproc)"; then
    warn "SKIP: make failed"
    exit 0
fi

# --- Install binary + desktop file ----------------------------------------
log "installing binary to /usr/bin/looking-glass-client"
install -Dm0755 looking-glass-client /usr/bin/looking-glass-client

# Ship a .desktop entry
install -Dm0644 /dev/stdin /usr/share/applications/looking-glass.desktop <<'DESK'
[Desktop Entry]
Type=Application
Name=Looking Glass
Comment=Low-latency KVM display from a VM via shared memory
Icon=video-display
Exec=looking-glass-client
Terminal=false
Categories=System;Utility;
Keywords=KVM;VFIO;Passthrough;
DESK

# --- Cleanup build tree (keep toolchain in image per self-building principle) ---
log "cleaning up source tree"
cd /
rm -rf "$BUILD_DIR"

# --- Verify ----------------------------------------------------------------
if [[ -x /usr/bin/looking-glass-client ]]; then
    log "OK: looking-glass-client baked in at /usr/bin/looking-glass-client"
    /usr/bin/looking-glass-client --version 2>&1 | head -5 || true
else
    warn "SKIP: binary missing after install (non-fatal)"
    exit 0
fi

log "Looking Glass client BAKED IN"
```

---

## automation/90-generate-sbom.sh

```bash
#!/bin/bash
# MiOS v0.2.0  90-generate-sbom: Generate Software Bill of Materials (SBOM)
# Uses Syft to generate CycloneDX and SPDX manifests for the final image.
set -euo pipefail

# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"

echo "[90-generate-sbom] Starting SBOM generation..."

ARTIFACT_DIR="/usr/lib/mios/artifacts/sbom"
mkdir -p "$ARTIFACT_DIR"

# Check if syft is available
if ! command -v syft &> /dev/null; then
    echo "[90-generate-sbom] WARN: Syft not found. Attempting to install..."
    # Syft is in packages-utils, but if it's missing for some reason, try to install it.
    dnf install -y syft || {
        echo "[90-generate-sbom] ERROR: Failed to install Syft. Skipping SBOM generation."
        exit 0 # Non-fatal
    }
fi

VERSION=$(cat /ctx/VERSION 2>/dev/null || echo "v0.2.0")
TIMESTAMP=$(date -u +%Y%m%dT%H%M%SZ)

echo "[90-generate-sbom] Scanning root filesystem..."

# Generate CycloneDX (JSON) - Primary for AI and automation
syft scan dir:/ \
    --output cyclonedx-json \
    --file "${ARTIFACT_DIR}/mios-sbom-${VERSION}-${TIMESTAMP}.cyclonedx.json" \
    --exclude "/ctx" \
    --exclude "/var/cache"

# Generate SPDX (Tag-Value) - Standard compliance
syft scan dir:/ \
    --output spdx-tag-value \
    --file "${ARTIFACT_DIR}/mios-sbom-${VERSION}-${TIMESTAMP}.spdx.txt" \
    --exclude "/ctx" \
    --exclude "/var/cache"

# Create latest symlinks
ln -sf "mios-sbom-${VERSION}-${TIMESTAMP}.cyclonedx.json" "${ARTIFACT_DIR}/latest.cyclonedx.json"
ln -sf "mios-sbom-${VERSION}-${TIMESTAMP}.spdx.txt" "${ARTIFACT_DIR}/latest.spdx.txt"

echo "[90-generate-sbom] SBOMs generated in ${ARTIFACT_DIR}:"
ls -lh "$ARTIFACT_DIR"

echo "[90-generate-sbom] Done."
```

---

## automation/98-boot-config.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 98-boot-config: Boot console + service configuration
# Plymouth disable is handled by usr/lib/bootc/kargs.d/10-mios-console.toml
# Console verbosity is handled by usr/lib/bootc/kargs.d/00-mios.toml + 10-mios-verbose.toml
set -euo pipefail

echo "[98-boot-config] Configuring boot console output..."

# ── Verify kargs TOML files exist ──────────────────────────────────────────
# These are static files from  — if missing, the overlay step failed.
if [ -f /usr/lib/bootc/kargs.d/10-mios-console.toml ]; then
    echo "[98-boot-config] Configuring plymouth disable via kernel cmdline..."
else
    echo "[98-boot-config] ERROR: 10-mios-console.toml not found — check overlay!"
fi

# ── Ensure agetty on tty1 ─────────────────────────────────────────────────
# Even if GDM fails, we need a text console to diagnose.
echo "[98-boot-config] Enabling getty on tty1 (fallback console)..."
systemctl enable getty@tty1.service 2>/dev/null || true

# ── Emergency shell access ────────────────────────────────────────────────
echo "[98-boot-config] Enabling emergency/rescue shell access..."
systemctl enable emergency.service 2>/dev/null || true
systemctl enable rescue.service 2>/dev/null || true

# ── Serial console for Hyper-V / QEMU ────────────────────────────────────
echo "[98-boot-config] Enabling serial-getty on ttyS0..."
systemctl enable serial-getty@ttyS0.service 2>/dev/null || true

# ── NetworkManager-wait-online timeout ────────────────────────────────────
echo "[98-boot-config] NetworkManager-wait-online timeout delivered via overlay."

echo "[98-boot-config] ✓ Boot console configured"
echo "[98-boot-config]   plymouth: disabled (kernel cmdline plymouth.enable=0)"
echo "[98-boot-config]   getty@tty1: enabled (fallback text console)"
echo "[98-boot-config]   serial-getty@ttyS0: enabled (serial console)"
echo "[98-boot-config]   NM-wait-online: 10s timeout (was 90s)"```

---

## automation/99-cleanup.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 99-cleanup: Final image cleanup (mirrors ucore/cleanup.sh)
#
# MANDATORY for bootc images. Every ublue-os image runs this pattern.
# Without it, BIB deployment fails or the booted system has broken /var state.
#
# v0.2.0: Added targeted lint cleanup for dnf5.log, ldconfig aux-cache,
# and any stray files in /var that trigger bootc container lint warnings.
#
# Reference: https://github.com/ublue-os/ucore/blob/main/cleanup.sh
set -euo pipefail

# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"

echo "[99-cleanup] Running final image cleanup..."

# 1. Clean /boot — BIB generates fresh bootloader, stale content causes conflicts
echo "[99-cleanup] Cleaning /boot..."
find /boot/ -maxdepth 1 -mindepth 1 -exec rm -fr {} \; || true

# 2. Clean /var — bootc treats /var as persistent state (like Docker VOLUME)
# We remove content but KEEP directories to preserve permissions/labels.
echo "[99-cleanup] Cleaning /var content (preserving structure)..."
# Remove all files and subdirs in /var/tmp and /var/log
rm -rf /var/tmp/* /var/log/* 2>/dev/null || true
# Clean /var/lib excluding critical paths if any (mostly dnf/rpm-ostree cache)
find /var/cache/* -maxdepth 0 -type d \! -name libdnf5 \! -name rpm-ostree -exec rm -fr {} \; 2>/dev/null || true

# 3. Lint-specific cleanup: remove files that trigger bootc container lint warnings
echo "[99-cleanup] Cleaning lint triggers..."
rm -f /var/log/lastlog /var/log/dnf5.log* 2>/dev/null || true
rm -rf /var/cache/ldconfig 2>/dev/null || true
rm -f /var/lib/systemd/random-seed 2>/dev/null || true
# MiOS v0.2.0: additional lint cleanup based on Cloud Build observations
rm -rf /var/lib/glusterd 2>/dev/null || true
rm -f /var/lib/containers/storage/db.sql 2>/dev/null || true
rm -f /var/lib/flatpak/.changed 2>/dev/null || true
rm -rf /var/lib/flatpak/repo/tmp/* 2>/dev/null || true

# 4. Restore system skeleton via systemd-tmpfiles
# This ensures all /var and /tmp directories exist with correct metadata.
echo "[99-cleanup] Restoring system skeleton..."
systemd-tmpfiles --create --boot --root=/ 2>/dev/null || true

# 5. ostree container commit — CRITICAL: finalizes OSTree layer metadata
echo "[99-cleanup] Running ostree container commit..."
ostree container commit 2>&1 || true

# 6. Clean DNF caches
echo "[99-cleanup] Cleaning package manager caches..."
$DNF_BIN "${DNF_SETOPT[@]}" clean all 2>/dev/null || true

echo "[99-cleanup] ✓ Image cleanup complete"
```

---

## automation/99-postcheck.sh

```bash
#!/usr/bin/env bash
# 99-postcheck.sh - build-time technical invariant validation
# 
# This script runs at the very end of the Containerfile build (before cleanup).
# It enforces mandatory version requirements, security postures, and 
# architectural purity. Failures here ABORT THE BUILD to prevent shipping
# a regressed or vulnerable image.
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"

echo "════════════ MiOS Build-Time Validation ════════════"

# 1. OpenSSH Version Check (CVE-2026-4631 / Cockpit RCE mitigation)
# Requirement: ≥ 9.6
log "Checking OpenSSH version..."
if ! command -v sshd >/dev/null 2>&1; then
    die "sshd not found in image (required for Podman-machine & remote mgmt)"
fi

SSH_VER_RAW=$(sshd -V 2>&1 | head -n1 | grep -oP 'OpenSSH_\K[0-9.]+')
log "  Found: OpenSSH $SSH_VER_RAW"

# Compare version (simple dot-split comparison)
if [[ $(printf '%s\n9.6' "$SSH_VER_RAW" | sort -V | head -n1) != "9.6" ]]; then
    die "OpenSSH version $SSH_VER_RAW is below required 9.6 (Vulnerable to CVE-2026-4631 in Cockpit context)"
fi
log "  ✓ OpenSSH version is safe"

# 2. Cockpit Security Posture
log "Checking Cockpit configuration..."
# In Rootfs-Native, config might be in /etc or /usr/lib
if [[ -f "/etc/cockpit/cockpit.conf" ]]; then
    COCKPIT_CONF="/etc/cockpit/cockpit.conf"
elif [[ -f "/usr/lib/cockpit/cockpit.conf" ]]; then
    COCKPIT_CONF="/usr/lib/cockpit/cockpit.conf"
else
    COCKPIT_CONF=""
fi

if [[ -f "$COCKPIT_CONF" ]]; then
    if ! grep -q "LoginTo = false" "$COCKPIT_CONF"; then
        die "Cockpit LoginTo mitigation missing in $COCKPIT_CONF (CVE-2026-4631)"
    fi
    log "  ✓ Cockpit LoginTo = false is enforced"
else
    log "  ⚠ Cockpit config not found at expected paths; skipping check"
fi

# 3. Kernel Argument Validation (Schema Strictness Preparation)
log "Validating kargs.d files..."
if [[ -d /usr/lib/bootc/kargs.d ]]; then
    for f in /usr/lib/bootc/kargs.d/*; do
        [[ -e "$f" ]] || continue
        # Future: run 'bootc container lint' or specialized schema check
        log "  found karg: $(basename "$f")"
    done
    log "  ✓ kargs.d presence verified"
fi

# 4. Critical Package Verification
log "Verifying critical system binaries..."
CRITICAL_TOOLS=(podman bootc cockpit-bridge rpm-ostree)
for tool in "${CRITICAL_TOOLS[@]}"; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        die "Critical tool '$tool' is missing from the image"
    fi
    log "  ✓ $tool present"
done

# 5. NVIDIA Container Toolkit Version Check
log "Checking NVIDIA Container Toolkit version..."
if command -v nvidia-ctk >/dev/null 2>&1; then
    NCT_VER=$(nvidia-ctk --version | head -n1 | grep -oP 'version \K[0-9.]+')
    log "  Found: $NCT_VER"
    if [[ $(printf '%s\n1.18' "$NCT_VER" | sort -V | head -n1) != "1.18" ]]; then
        die "nvidia-container-toolkit version $NCT_VER is below required 1.18"
    fi
    log "  ✓ NVIDIA Container Toolkit version is safe"
fi

# 6. Cockpit Version Check (for CVE-2026-4631)
log "Checking Cockpit version..."
if rpm -q cockpit >/dev/null 2>&1; then
    COCKPIT_VER=$(rpm -q cockpit --queryformat '%{VERSION}')
    log "  Found: Cockpit $COCKPIT_VER"
    # CVE fixed in 360. MiOS targets 361+ for Fedora 44 GA stability.
    if [[ $(printf '%s\n361' "$COCKPIT_VER" | sort -V | head -n1) != "361" ]]; then
        log "  ⚠ Cockpit version $COCKPIT_VER is below 361 (Risk: CVE-2026-4631 / Regressions)"
    else
        log "  ✓ Cockpit version is safe"
    fi
fi

echo "═════════════ Validation SUCCESSFUL ═════════════"
exit 0
```

# Layer 4k — Helpers

---

## automation/ai-bootstrap.sh

```bash
#!/bin/bash
# MiOS Omni-Agent Bootstrap Script
# Synchronizes manifests and initializes sub-project environments.

set -euo pipefail

echo "🚀 Initializing MiOS Agent Workspace..."

# 0. Load Unified Environment
if [[ -f ".env.mios" ]]; then
    echo "📜 Loading unified environment from .env.mios..."
    # Export all variables defined in .env.mios
    set -a
    source .env.mios
    set +a
fi

# 1. Generate Manifests
if [[ -f "tools/generate-ai-manifest.py" ]]; then
    echo "📄 Generating directory manifests..."
    python3 tools/generate-ai-manifest.py
else
    echo "⚠️ Warning: tools/generate-ai-manifest.py not found."
fi

# 2. Sync Wiki Documentation
if [[ -f "tools/sync-wiki.py" ]]; then
    echo "📖 Syncing Wiki..."
    python3 tools/sync-wiki.py
else
    echo "⚠️ Warning: tools/sync-wiki.py not found."
fi

# 3. Generate Unified Knowledge Base (RAG Snapshot)
if [[ -f "tools/generate-unified-knowledge.py" ]]; then
    echo "🧠 Generating Unified Knowledge Base (RAG Snapshot)..."
    if [[ -f "tools/journal-sync.py" ]]; then
        python3 tools/journal-sync.py
    fi
    python3 tools/generate-unified-knowledge.py
else
    echo "⚠️ Warning: tools/generate-unified-knowledge.py not found."
fi

# 4. Initialize agents/research
if [[ -d "agents/research" ]]; then
    echo "🧪 Initializing agents/research (Agent Starter Pack)..."
    # Placeholder for future agent initialization logic
    # (cd agents/research && make install)
else
    echo "⚠️ Warning: agents/research directory not found."
fi

# 3. Persistence: Refresh environment configs and dotfiles
echo "💾 Persisting environment state..."
if [[ -f "tools/refresh-env.py" ]]; then
    python3 tools/refresh-env.py
else
    echo "⚠️ Warning: tools/refresh-env.py not found."
fi

echo "✅ Workspace initialization complete."

# 6. Seed Artifacts for Agents
echo "🌱 Seeding latest MiOS Artifacts for initialized agents..."
if [[ -f "artifacts/repo-rag-snapshot.json.gz" ]]; then
    # Shared scratchpad for cross-agent IPC
    mkdir -p .ai/foundation/shared-tmp/
    cp artifacts/repo-rag-snapshot.json.gz .ai/foundation/shared-tmp/latest-context.json.gz
    # Sub-project local context
    cp artifacts/repo-rag-snapshot.json.gz agents/research/latest-context.json.gz
    echo "✅ Context seeded to .ai/foundation/shared-tmp/ and agents/research/"
else
    echo "⚠️ Warning: artifacts/repo-rag-snapshot.json.gz not found. Skip seeding."
fi
```

---

## automation/bcvk-wrapper.sh

```bash
#!/usr/bin/env bash
set -euo pipefail
# MiOS v0.2.0 — Ephemeral QEMU boot test
# Usage: bcvk-wrapper.sh <qcow2-path> [serial-log-path]
#
# Boots a QCOW2 image in headless QEMU with KVM, captures serial console,
# waits for systemd to reach a login target, then exits.
# Returns 0 on success, non-zero on timeout or boot failure.

QCOW="${1:-}"
SERIAL_LOG="${2:-/tmp/mios-serial.log}"
TIMEOUT_SECS=240
POLL_INTERVAL=3

if [[ -z "$QCOW" ]]; then
    echo "Usage: $0 <qcow2-path> [serial-log-path]"
    exit 2
fi

if [[ ! -f "$QCOW" ]]; then
    echo "ERROR: QCOW2 not found: $QCOW"
    exit 3
fi

: > "$SERIAL_LOG"

echo "[bcvk] Booting $QCOW (timeout: ${TIMEOUT_SECS}s)"

QEMU_ARGS=(
    qemu-system-x86_64
    -m 16384
    -smp 8
    -cpu host
    -enable-kvm
    -drive "file=$QCOW,if=virtio,cache=none,format=qcow2"
    -nic "user,model=virtio"
    -nographic
    -serial "file:$SERIAL_LOG"
    -no-reboot
    -display none
)

"${QEMU_ARGS[@]}" &
QEMU_PID=$!

cleanup() { kill "$QEMU_PID" 2>/dev/null; wait "$QEMU_PID" 2>/dev/null; }
trap cleanup EXIT

ELAPSED=0
while [[ $ELAPSED -lt $TIMEOUT_SECS ]]; do
    if grep -qE "(Reached target (Graphical|Multi-User)|login:)" "$SERIAL_LOG" 2>/dev/null; then
        echo "[bcvk] Boot successful (${ELAPSED}s)"
        exit 0
    fi
    if grep -qi "kernel panic" "$SERIAL_LOG" 2>/dev/null; then
        echo "[bcvk] KERNEL PANIC detected"
        tail -50 "$SERIAL_LOG"
        exit 5
    fi
    sleep "$POLL_INTERVAL"
    ELAPSED=$((ELAPSED + POLL_INTERVAL))
done

echo "[bcvk] TIMEOUT after ${TIMEOUT_SECS}s — boot did not reach target"
echo "[bcvk] Last 100 lines of serial log:"
tail -100 "$SERIAL_LOG"
exit 4```

---

## automation/enroll-mok.sh

```bash
#!/usr/bin/bash
# enroll-mok.sh — MiOS Secure Boot MOK enrollment helper.
#
# Uses mokutil throughout. sbctl is the WRONG tool for Fedora bootc
# (GRUB2+shim chain, not systemd-boot+UKI). See specs/SECUREBOOT.md.
#
# Variant-aware:
#   MiOS-2 (ucore-hci): prefers /etc/pki/akmods/certs/akmods-ublue.der (ublue key)
#                           if /etc/pki/mios/mok.der absent.
#
# Idempotent: exits 0 if key is already enrolled or pending enrollment.
#
# Usage:
#   enroll-mok.sh [--status] [--key /path/to/key.der]
#
# Exit codes:
#   0 = enrolled / pending / no-secureboot (no action needed)
#   1 = error
#   2 = key not found
#   3 = conflict (key CN matches but fingerprint differs — manual intervention)
set -euo pipefail

STATUS_ONLY=0
KEY_OVERRIDE=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --status)  STATUS_ONLY=1; shift ;;
        --key)     KEY_OVERRIDE="$2"; shift 2 ;;
        -*)        echo "Unknown option: $1" >&2; exit 1 ;;
        *)         break ;;
    esac
done

LOG_DIR=/var/log/mios
LOG_FILE="${LOG_DIR}/mok-enroll-$(date -u +%Y%m%dT%H%M%SZ).log"
install -d -m 0750 "$LOG_DIR"

log() {
    local msg="[mok-enroll] $*"
    echo "$msg"
    echo "$msg" >> "$LOG_FILE"
}

status_probe() {
    # Emit one of: enrolled | pending | not-enrolled | no-secureboot | conflict
    if ! command -v mokutil >/dev/null 2>&1; then
        echo "no-secureboot"
        return
    fi
    local sb_state
    sb_state=$(mokutil --sb-state 2>/dev/null || true)
    if echo "$sb_state" | grep -qi "SecureBoot disabled"; then
        echo "no-secureboot"
        return
    fi

    local key_path
    key_path=$(pick_key)
    if [[ -z "$key_path" ]]; then
        echo "not-enrolled"
        return
    fi

    local fingerprint
    fingerprint=$(openssl x509 -inform DER -in "$key_path" -fingerprint -sha256 -noout 2>/dev/null | sed 's/.*=//') || {
        echo "error"
        return
    }

    local enrolled_fps
    enrolled_fps=$(mokutil --list-enrolled 2>/dev/null | grep -i "SHA256 Fingerprint" | sed 's/.*: //' | tr -d ':' | tr '[:upper:]' '[:lower:]' || true)
    local pending_fps
    pending_fps=$(mokutil --list-new 2>/dev/null | grep -i "SHA256 Fingerprint" | sed 's/.*: //' | tr -d ':' | tr '[:upper:]' '[:lower:]' || true)
    local target_fp
    target_fp=$(echo "$fingerprint" | tr -d ':' | tr '[:upper:]' '[:lower:]')

    if echo "$enrolled_fps" | grep -qF "$target_fp"; then
        echo "enrolled"
    elif echo "$pending_fps" | grep -qF "$target_fp"; then
        echo "pending"
    else
        # Check if CN matches but fingerprint differs (key rotation conflict).
        local key_cn
        key_cn=$(openssl x509 -inform DER -in "$key_path" -subject -noout 2>/dev/null | sed 's/.*CN\s*=\s*//' | cut -d'/' -f1 || true)
        if [[ -n "$key_cn" ]]; then
            local enrolled_subjects
            enrolled_subjects=$(mokutil --list-enrolled 2>/dev/null || true)
            if echo "$enrolled_subjects" | grep -qF "$key_cn"; then
                echo "conflict"
                return
            fi
        fi
        echo "not-enrolled"
    fi
}

pick_key() {
    if [[ -n "$KEY_OVERRIDE" ]]; then
        echo "$KEY_OVERRIDE"
        return
    fi
    # MiOS-specific key (generated by generate-mok-key.sh)
    [[ -f /etc/pki/mios/mok.der ]] && { echo /etc/pki/mios/mok.der; return; }
    # MiOS-2 (ucore-hci): ublue pre-signed NVIDIA kmods key
    [[ -f /etc/pki/akmods/certs/akmods-ublue.der ]] && { echo /etc/pki/akmods/certs/akmods-ublue.der; return; }
    echo ""
}

# ── status probe mode ─────────────────────────────────────────────────────────

if (( STATUS_ONLY == 1 )); then
    status_probe
    exit 0
fi

# ── runtime checks ────────────────────────────────────────────────────────────

log "=== MiOS MOK Enrollment ==="

if ! command -v mokutil >/dev/null 2>&1; then
    log "mokutil not found — install it: sudo dnf install mokutil"
    exit 1
fi

# Secure Boot state check
sb_state=$(mokutil --sb-state 2>/dev/null || true)
if echo "$sb_state" | grep -qi "SecureBoot disabled"; then
    log "Secure Boot is disabled — MOK enrollment not required"
    exit 0
fi
log "Secure Boot state: $sb_state"

# Pick key
KEY=$(pick_key)
if [[ -z "$KEY" ]]; then
    log "No MOK key found. Generate one with:"
    log "  sudo automation/generate-mok-key.sh"
    exit 2
fi
log "Using key: $KEY"

FINGERPRINT=$(openssl x509 -inform DER -in "$KEY" -fingerprint -sha256 -noout | sed 's/.*=//') || {
    log "Cannot read key fingerprint from $KEY"
    exit 1
}
log "Key fingerprint: $FINGERPRINT"

# Idempotency check
CURRENT_STATUS=$(status_probe)
log "Current status: $CURRENT_STATUS"

case "$CURRENT_STATUS" in
    enrolled)
        log "Key already enrolled — no action needed"
        exit 0
        ;;
    pending)
        log "Key already queued for enrollment — reboot to complete in MokManager"
        exit 0
        ;;
    conflict)
        log "ERROR: A key with the same CN is already enrolled but with a different fingerprint."
        log "This indicates a key rotation. Manual steps required:"
        log "  1. mokutil --delete /etc/pki/mios/mok.old.der  (previous key)"
        log "  2. Reboot and complete deletion in MokManager"
        log "  3. Re-run this script"
        exit 3
        ;;
    no-secureboot)
        log "Secure Boot appears disabled — nothing to enroll"
        exit 0
        ;;
esac

# ── enroll ────────────────────────────────────────────────────────────────────

log "Queuing $KEY for MOK enrollment (using --root-pw)"
log ""
log "You will be prompted to confirm using the system root password."
log "On next reboot, MokManager will ask for this same password."
log ""

# --root-pw binds the enrollment to the current root password hash in /etc/shadow.
# This avoids shipping a hardcoded secret (unlike ublue's 'universalblue' default).
if ! mokutil --import "$KEY" --root-pw; then
    log "mokutil --import failed"
    # Attempt rollback
    log "Attempting to revoke pending import (rollback)..."
    mokutil --revoke-import "$KEY" 2>/dev/null || log "revoke-import also failed — check mokutil state manually"
    exit 1
fi

# Optional: set MokManager timeout (non-fatal — known to fail on some ASUS boards)
mokutil --timeout 10 2>/dev/null || log "note: --timeout ignored on this firmware (non-fatal)"

log ""
log "✓ Key queued for enrollment."
log ""
log "NEXT STEPS:"
log "  1. Reboot the system."
log "  2. In MokManager, choose 'Enroll MOK' and enter the root password."
log "  3. Reboot again. The key will be active."
log ""
log "── TPM2 WARNING ────────────────────────────────────────────────────────────"
log "If you have LUKS volumes sealed to TPM2 PCR 7 (systemd-cryptenroll),"
log "every MOK mutation changes PCR 7 and WILL break automatic unlock."
log "After this reboot completes enrollment, re-seal with:"
log "  systemd-cryptenroll --wipe-slot=tpm2 /dev/DISK"
log "  systemd-cryptenroll --tpm2-device=auto --tpm2-pcrs=7+14 /dev/DISK"
log "────────────────────────────────────────────────────────────────────────────"
log ""
log "Full log: $LOG_FILE"
```

---

## automation/generate-mok-key.sh

```bash
#!/usr/bin/bash
# generate-mok-key.sh — one-shot MiOS MOK key generator.
#
# Generates a 2048-bit RSA key (NOT 4096: shim compatibility) with:
#   - codeSigning EKU
#   - 1.3.6.1.5.5.7.3.3 (Standard Code Signing)
#   - 1.3.6.1.4.1.311.61.1.1 (MS Kernel Module Code Signing)
#   - 1.3.6.1.4.1.311.10.3.5 (WHQL Driver Verification)
#   - 10-year validity
#
# Output: /etc/pki/mios/mok.{priv,der,pem,pub.b64,sha256}
# Refuses to overwrite an existing key.
#
# Store the encrypted private key in GitHub secret MIOS_MOK_KEY_B64
# and the passphrase in MIOS_MOK_KEY_PASSWORD. Never regenerate per-build.
set -euo pipefail

KEY_DIR=/etc/pki/mios
PRIV_KEY="${KEY_DIR}/mok.priv"
DER_CERT="${KEY_DIR}/mok.der"
PEM_CERT="${KEY_DIR}/mok.pem"
B64_PRIV="${KEY_DIR}/mok.priv.b64"
SHA256_OUT="${KEY_DIR}/mok.sha256"

if [[ -f "$DER_CERT" ]]; then
    echo "ERROR: $DER_CERT already exists. MOK keys are generated once."
    echo "If you need to rotate, delete the old key files first, re-enroll with mokutil,"
    echo "and then re-run this script."
    exit 1
fi

if [[ "$(id -u)" -ne 0 ]]; then
    echo "ERROR: run as root (sudo automation/generate-mok-key.sh)"
    exit 1
fi

install -d -m 0700 "$KEY_DIR"

echo "=== MiOS MOK Key Generation ==="
echo ""
echo "Generating 2048-bit RSA key (shim-compatible) with 10-year validity..."
echo "You will be prompted for an encryption passphrase for the private key."
echo "Store this passphrase in GitHub secret MIOS_MOK_KEY_PASSWORD."
echo ""

# Create EKU extension config
EXTFILE=$(mktemp /tmp/mok-ext.XXXXXX.conf)
cat >"$EXTFILE" <<'EOF'
[req]
default_bits       = 2048
default_md         = sha256
distinguished_name = dn
x509_extensions    = v3_ca
prompt             = no

[dn]
CN = MiOS Module Signing Key

[v3_ca]
basicConstraints       = CA:FALSE
keyUsage               = digitalSignature
extendedKeyUsage       = codeSigning, 1.3.6.1.5.5.7.3.3, 1.3.6.1.4.1.311.61.1.1, 1.3.6.1.4.1.311.10.3.5
subjectKeyIdentifier   = hash
authorityKeyIdentifier = keyid:always
EOF

# Generate encrypted key + self-signed cert
openssl req \
    -newkey rsa:2048 \
    -nodes \
    -keyout "${PRIV_KEY}.plain" \
    -x509 \
    -outform PEM \
    -out "$PEM_CERT" \
    -days 3650 \
    -config "$EXTFILE"

# Convert cert to DER (the format mokutil needs)
openssl x509 -in "$PEM_CERT" -outform DER -out "$DER_CERT"

# Encrypt the private key
echo ""
echo "Enter a passphrase to encrypt the private key (for GitHub secret storage):"
openssl pkcs8 -topk8 -inform PEM -outform PEM \
    -in "${PRIV_KEY}.plain" \
    -out "$PRIV_KEY"
rm -f "${PRIV_KEY}.plain"

# Base64-encode encrypted PEM for GitHub secret
base64 -w0 "$PRIV_KEY" > "$B64_PRIV"

# SHA-256 fingerprint of the DER cert
FINGERPRINT=$(openssl x509 -inform DER -in "$DER_CERT" -fingerprint -sha256 -noout | sed 's/.*=//')
echo "$FINGERPRINT" > "$SHA256_OUT"

chmod 0600 "$PRIV_KEY" "$B64_PRIV" "$SHA256_OUT"
chmod 0644 "$DER_CERT" "$PEM_CERT"

rm -f "$EXTFILE"

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "Key files created:"
echo "  Private key (encrypted PEM): $PRIV_KEY"
echo "  Certificate (DER):           $DER_CERT"
echo "  Certificate (PEM):           $PEM_CERT"
echo "  Base64 private key:          $B64_PRIV"
echo "  SHA-256 fingerprint:         $SHA256_OUT"
echo ""
echo "Fingerprint: $FINGERPRINT"
echo ""
echo "GitHub secrets to set:"
echo "  COSIGN_PRIVATE_KEY  — for cosign key-based signing (separate cosign keypair)"
echo "  MIOS_MOK_KEY_B64 — content of $B64_PRIV"
echo "  MIOS_MOK_KEY_PASSWORD — your passphrase"
echo ""
echo "Commit the DER cert to the repo:"
echo "  cp $DER_CERT etc/pki/mios/mok.der"
echo "  git add etc/pki/mios/mok.der"
echo ""
echo "Never commit the private key. Add to .gitignore:"
echo "  /etc/pki/mios/mok.priv"
echo "═══════════════════════════════════════════════════════════════"
```

---

*End of MiOS Full Build Stack — 7680 total lines*
