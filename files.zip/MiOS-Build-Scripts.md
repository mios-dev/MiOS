# MiOS — Build Scripts (full source)

This bundle contains the actual build-pipeline source from `mios-dev/mios@v0.2.0`, in execution order. Read top-to-bottom to follow what the Containerfile triggers.

| Script | Lines | Role |
|---|---|---|
| `Containerfile` | 58 | OCI build entry — invokes everything below |
| `automation/build.sh` | 235 | Master orchestrator — runs every numbered phase |
| `automation/lib/common.sh` | 39 | Shared logging + dnf flags |
| `automation/lib/packages.sh` | 102 | PACKAGES.md fenced-block parser |
| `automation/lib/masking.sh` | 106 | Credential masking + secure curl |
| `automation/01-repos.sh` | 161 | F44 overlay, RPMFusion, Terra, CrowdSec, NVIDIA repos |
| `automation/08-system-files-overlay.sh` | 102 | Rootfs-native overlay (`/usr`, `/etc`, `/home`) |
| `automation/10-gnome.sh` | 170 | GNOME 50 minimal install + Bibata cursor + Flatpak remotes |
| `automation/12-virt.sh` | 98 | KVM/QEMU/Podman/Cockpit/Gaming/Storage/HA install |
| `automation/13-ceph-k3s.sh` | 90 | Ceph clients + cephadm + K3s binary (sha256-verified) |
| `automation/37-selinux.sh` | 174 | 19 custom SELinux policy modules + booleans + fcontexts |
| `automation/42-cosign-policy.sh` | 56 | cosign v2 install + Sigstore trust roots + policy.json |
| `automation/52-bake-kvmfr.sh` | 120 | KVMFR kernel module via akmod (signed with MOK) |
| `automation/53-bake-lookingglass-client.sh` | 103 | Looking Glass B7 from-source build |
| `automation/99-postcheck.sh` | 95 | Build-time invariant validation (CVE checks, version gates) |

---

## Containerfile

```dockerfile
# syntax=docker/dockerfile:1.9
# ============================================================================
# MiOS - Unified Image (v0.2.0)
# ============================================================================
# One image. Every role. Every surface. Every GPU vendor.
#
# Base:     Controlled by MIOS_BASE_IMAGE in .env.mios
#           Default: ghcr.io/ublue-os/ucore-hci:stable-nvidia
# ============================================================================

ARG BASE_IMAGE=ghcr.io/ublue-os/ucore-hci:stable-nvidia # @track:IMG_BASE

# ----------------------------------------------------------------------------
# ctx stage: build context
# ----------------------------------------------------------------------------
FROM scratch AS ctx
COPY automation/           /ctx/automation/
COPY usr/                  /ctx/usr/
COPY etc/                  /ctx/etc/
COPY home/                 /ctx/home/
COPY usr/share/mios/PACKAGES.md                          /ctx/PACKAGES.md
COPY VERSION            /ctx/VERSION
COPY config/artifacts/       /ctx/bib-configs/
COPY tools/             /ctx/tools/

# ----------------------------------------------------------------------------
# main stage
# ----------------------------------------------------------------------------
FROM ${BASE_IMAGE}

LABEL org.opencontainers.image.title="MiOS"
LABEL org.opencontainers.image.description="Unified immutable cloud-native workstation OS"
LABEL org.opencontainers.image.source="https://github.com/MiOS-DEV/MiOS-bootstrap"
LABEL org.opencontainers.image.licenses="Apache-2.0"
LABEL org.opencontainers.image.version="v0.2.0"
LABEL containers.bootc="1"
LABEL ostree.bootable="1"

CMD ["/sbin/init"]

ARG MIOS_USER=mios
ARG MIOS_HOSTNAME=mios
ARG MIOS_FLATPAKS=

# Build context mounted read-only
COPY --from=ctx /ctx /ctx

# Unified Build Pipeline: Install -> Overlay -> Automation -> Cleanup
RUN --mount=type=cache,dst=/var/cache/libdnf5,sharing=locked     --mount=type=cache,dst=/var/cache/dnf,sharing=locked         set -e;     # 1. Install essential security packages     dnf install -y --skip-unavailable --setopt=install_weak_deps=False         policycoreutils-python-utils         selinux-policy-targeted         firewalld         audit         fapolicyd         crowdsec         usbguard         kernel-devel;     # 2. Inject flatpaks if provided     if [[ -n "${MIOS_FLATPAKS}" ]]; then         echo "${MIOS_FLATPAKS}" | tr "," "\n" > /ctx/usr/share/mios/flatpak-list;     fi;     # 3. Rootfs Overlay     bash /ctx/automation/08-system-files-overlay.sh;     # 4. Numbered Pipeline     chmod +x /ctx/automation/build.sh /ctx/automation/*.sh 2>/dev/null || true;     chmod +x /usr/libexec/mios/copy-build-log.sh;     /ctx/automation/build.sh;     # 5. Mandatory Cleanup for bootc lint     dnf clean all;     find /var -mindepth 1 -maxdepth 1 ! -name tmp -exec rm -rf {} +;     find /run -mindepth 1 -maxdepth 1 ! -name "secrets" -exec rm -rf {} + 2>/dev/null || true

# Install bootc bash completions
RUN bootc completion bash > /etc/bash_completion.d/bootc

# -- systemd-sysext consolidation ----------
RUN mkdir -p /usr/lib/extensions/source  && chmod +x /ctx/tools/mios-sysext-pack.sh  && /ctx/tools/mios-sysext-pack.sh /usr/lib/extensions/source || true

RUN rm -rf /ctx  && ostree container commit
RUN bootc container lint
```

---

## automation/build.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — Master build runner
# Executes all numbered scripts in order, then cleans up.
# Called from Containerfile RUN layer via bind mount.
#
# CHANGELOG v0.2.0:
#   - Standardized versioning across the entire stack.
#   - FIX: install_weakdeps=False (was True in v1.3 — contradicted docs)
#   - FIX: Safe arithmetic: VAR=$((VAR + 1)) not ((VAR++)) (set -e compat)
#   - Base: ucore-hci:stable-nvidia (Rawhide overlay in 01-repos.sh)
#   - Post-build validates malcontent-libs present (flatpak needs it)
#   - Footgun list includes malcontent-control/pam/tools
#   - PackageKit/gnome-tour removed via dnf (safe, no cascade)
#   - gnome-software KEPT (manages Flatpaks on immutable systems)
#   - malcontent-control hidden via NoDisplay (dnf remove cascades)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"
register_common_masks
export PACKAGES_MD="${PACKAGES_MD:-/ctx/PACKAGES.md}"
BUILD_LOG="/tmp/mios-build.log"

exec > >(mask_filter | tee -a "$BUILD_LOG") 2>&1

log_ts() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"
}

VERSION_STR="$(cat "${SCRIPT_DIR}/../VERSION" 2>/dev/null || cat /ctx/VERSION 2>/dev/null || echo 'v0.2.0')"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  MiOS ${VERSION_STR} — Building OS Image"
echo "  Base: ucore-hci:stable-nvidia + F44 + Rawhide kernel"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
log_ts "Build started"
log_ts "PACKAGES.MD : $PACKAGES_MD"
log_ts "SCRIPT_DIR  : $SCRIPT_DIR"
echo ""

if [[ ! -f "$PACKAGES_MD" ]]; then
    log_ts "FATAL: $PACKAGES_MD not found. Build context missing."
    exit 1
fi

# ── DNF config ──────────────────────────────────────────────────────────────
export SYSTEMD_OFFLINE=1
export container=podman

# ── Execute numbered scripts ────────────────────────────────────────────────
# Skip list:
#   08-system-files-overlay.sh  — called explicitly by the Containerfile BEFORE this script
#   37-ollama-prep.sh           — intentional local-only step (large model download; not for CI)
CONTAINERFILE_SCRIPTS="08-system-files-overlay.sh 37-ollama-prep.sh"

TOTAL_START=$SECONDS
SCRIPT_COUNT=0
SCRIPT_FAIL=0
FAILED_SCRIPTS=()

for script in "$SCRIPT_DIR"/[0-9][0-9]-*.sh; do
    SCRIPT_NAME="$(basename "$script")"
    if echo "$CONTAINERFILE_SCRIPTS" | grep -qF "$SCRIPT_NAME"; then
        log_ts "==> Skipping (Containerfile post-step): $SCRIPT_NAME"
        continue
    fi
    SCRIPT_COUNT=$((SCRIPT_COUNT + 1))
    echo "───────────────────────────────────────────────────────────────────"
    log_ts "==> STEP $SCRIPT_COUNT: $SCRIPT_NAME"
    echo "───────────────────────────────────────────────────────────────────"

    STEP_START=$SECONDS

    set +e
    bash "$script"
    SCRIPT_EXIT=$?
    set -e

    STEP_ELAPSED=$(( SECONDS - STEP_START ))

    if [[ $SCRIPT_EXIT -eq 0 ]]; then
        log_ts "✓ $SCRIPT_NAME completed (${STEP_ELAPSED}s)"
    else
        log_ts "✗ $SCRIPT_NAME FAILED (exit $SCRIPT_EXIT, ${STEP_ELAPSED}s)"
        SCRIPT_FAIL=$((SCRIPT_FAIL + 1))
        FAILED_SCRIPTS+=("$SCRIPT_NAME")
    fi
    echo ""
done

# ── Bloat Removal (active removal approach) ──────────
# Per user mandate: remove anything that's bloat.
# malcontent-libs must remain (gnome-control-center hard dep), but
# malcontent-control/pam/tools are UI/CLI components we don't need.
# Leaf apps like gnome-tour and gnome-initial-setup are safe to remove.
echo ""
log_ts "==> Removing known bloat packages..."
BLOAT_PACKAGES=$(source "${SCRIPT_DIR}/lib/packages.sh"; get_packages "bloat")
if [[ -n "$BLOAT_PACKAGES" ]]; then
    $DNF_BIN "${DNF_SETOPT[@]}" remove -y "${DNF_OPTS[@]}" $BLOAT_PACKAGES 2>/dev/null || true
else
    log_ts "NOTE: No bloat packages defined in manifest."
fi

# ── Suppress remaining ucore base bloat (mask/hide) ──────────
# For things that can't be easily removed without cascade, hide them.
echo ""
log_ts "==> Suppressing remaining base image bloat (mask/hide)..."
systemctl mask packagekit.service 2>/dev/null || true
for app in gnome-tour gnome-initial-setup; do
    desktop="/usr/share/applications/${app}.desktop"
    if [ -f "$desktop" ]; then
        # Ensure target directory exists for NoDisplay override
        mkdir -p /usr/local/share/applications
        grep -v '^NoDisplay=' "$desktop" > "/usr/local/share/applications/${app}.desktop"
        echo "NoDisplay=true" >> "/usr/local/share/applications/${app}.desktop"
        echo "  ✓ Hidden: $app (NoDisplay=true)"
    fi
done

# ── Post-build validation ──────────────────────────────────────────────────
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log_ts "Post-build validation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

source "${SCRIPT_DIR}/lib/packages.sh"
CRITICAL_PACKAGES=($(get_packages "critical"))
VALIDATION_FAIL=0
if [[ ${#CRITICAL_PACKAGES[@]} -eq 0 ]]; then
    log_ts "WARNING: No critical packages found in manifest validation section!"
else
    for pkg in "${CRITICAL_PACKAGES[@]}"; do
        if rpm -q "$pkg" > /dev/null 2>&1; then
            echo "  ✓ $pkg"
        else
            echo "  ✗ $pkg MISSING"
            VALIDATION_FAIL=$((VALIDATION_FAIL + 1))
        fi
    done
fi

# Hardware & Driver Verification (Moved from legacy 41-akmods-copy.sh)
if rpm -qa 'kmod-nvidia*' 2>/dev/null | grep -q . ; then
    echo "  ✓ NVIDIA kmod(s) present"
else
    echo "  ⚠ NVIDIA kmod(s) MISSING (using ucore base?)"
fi

if compgen -G "/etc/pki/akmods/certs/*.der" > /dev/null; then
    echo "  ✓ MOK certs present"
fi

# RTX 50 Blackwell Karg Check
if grep -q "vfio_pci.disable_idle_d3=1" /usr/lib/bootc/kargs.d/*.toml 2>/dev/null; then
    echo "  ✓ Blackwell VFIO workaround present in kargs.d"
else
    echo "  ⚠ Blackwell VFIO workaround missing in kargs.d"
fi

# malcontent-libs MUST be present (flatpak links against libmalcontent-0.so.0)
if rpm -q malcontent-libs > /dev/null 2>&1; then
    echo "  ✓ malcontent-libs (required by flatpak)"
else
    echo "  ⚠ malcontent-libs MISSING — flatpak may break"
fi

# gnome-software: expected (manages Flatpaks on immutable systems)
if rpm -q gnome-software > /dev/null 2>&1; then
    echo "  ✓ gnome-software (Flatpak manager)"
fi

# Footgun check — these should NOT be present after bloat removal
FOOTGUN_PACKAGES=($(get_packages "bloat"))
for pkg in "${FOOTGUN_PACKAGES[@]}"; do
    if rpm -q "$pkg" > /dev/null 2>&1; then
        echo "  ⚠ FOOTGUN: $pkg is installed (should not be in build-up image)"
    fi
done

if [[ $VALIDATION_FAIL -gt 0 ]]; then
    log_ts "WARNING: $VALIDATION_FAIL critical packages missing!"
fi

# ── Technical Invariant Validation ──
echo ""
log_ts "==> Running Technical Invariant Validation (99-postcheck.sh)..."
if [[ -f "${SCRIPT_DIR}/99-postcheck.sh" ]]; then
    bash "${SCRIPT_DIR}/99-postcheck.sh"
else
    log_ts "⚠ automation/99-postcheck.sh not found — skipping"
fi

# ── Cleanup ─────────────────────────────────────────────────────────────────

# Preserve logs in an immutable path for Day-2 diagnostics
echo ""
log_ts "Preserving build logs to /usr/lib/mios/logs/..."
mkdir -p /usr/lib/mios/logs
cp -v /var/log/dnf5.log* /var/log/hawkey.log /tmp/mios-build.log /usr/lib/mios/logs/ 2>/dev/null || true

echo ""
log_ts "Cleaning up..."
$DNF_BIN "${DNF_SETOPT[@]}" clean all
rm -rf /var/cache/dnf /var/cache/libdnf5 /tmp/geist-font /tmp/*.tar* /tmp/*.rpm 2>/dev/null || true
rm -rf /usr/share/doc/* /usr/share/man/* /usr/share/info/* 2>/dev/null || true
rm -rf /usr/share/gnome/help/* /usr/share/help/* 2>/dev/null || true

# Clean bootc lint triggers (logs now preserved in /usr/lib/mios/logs)
rm -f /var/log/dnf5.log* /var/log/hawkey.log 2>/dev/null || true
rm -rf /run/ceph /run/cockpit /run/k3s /tmp/* 2>/dev/null || true
rm -f /var/lib/systemd/random-seed 2>/dev/null || true

rm -f /tmp/mios-build.log

# ── Summary ─────────────────────────────────────────────────────────────────
TOTAL_ELAPSED=$(( SECONDS - TOTAL_START ))
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  BUILD SUMMARY"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Scripts:   $SCRIPT_COUNT executed, $SCRIPT_FAIL failed"
if [[ $SCRIPT_FAIL -gt 0 ]]; then
    echo "  Failed:    ${FAILED_SCRIPTS[*]}"
fi
echo "  Packages:  $VALIDATION_FAIL critical missing"
echo "  Duration:  ${TOTAL_ELAPSED}s ($((TOTAL_ELAPSED / 60))m $((TOTAL_ELAPSED % 60))s)"
echo "  Version:   $VERSION_STR"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if [[ $SCRIPT_FAIL -gt 0 ]]; then
    log_ts "FATAL: $SCRIPT_FAIL scripts failed — review build output above"
    exit 1
fi
```

---

## automation/lib/common.sh

```bash
#!/usr/bin/env bash
# ============================================================================
# automation/lib/common.sh
# ----------------------------------------------------------------------------
# Shared helpers for MiOS build scripts.
# Safe to source multiple times (idempotent).
# ============================================================================

# shellcheck source=lib/masking.sh
source "$(dirname "${BASH_SOURCE[0]}")/masking.sh"

# --- Logging ----------------------------------------------------------------
log_ts() { date '+%Y-%m-%d %H:%M:%S'; }
log()  { printf '[%s] ==> %s\n' "$(log_ts)" "$*"; }
warn() { printf '[%s] WARN: %s\n' "$(log_ts)" "$*" >&2; }
die()  { printf '[%s] ERROR: %s\n' "$(log_ts)" "$*" >&2; exit 1; }
diag() { printf '[%s] DIAG: %s\n' "$(log_ts)" "$*"; }

# --- dnf flags --------------------------------------------------------------
# Select dnf binary (prefer dnf5 if available)
if command -v dnf5 &>/dev/null; then
    export DNF_BIN="dnf5"
else
    export DNF_BIN="dnf"
fi

# Defense-in-depth: /etc/dnf/dnf.conf already carries install_weak_deps=False,
# but passing it on every invocation guarantees behaviour even if a script or
# transaction overrides the global default. Array form so elements are one-
# argv-each under `set -u`, and future flags can be added in one place.
if [[ -z "${DNF_SETOPT+x}" || "$(declare -p DNF_SETOPT 2>/dev/null)" != "declare -a"* ]]; then
    declare -ga DNF_SETOPT=(--setopt=install_weak_deps=False)
fi
if [[ -z "${DNF_OPTS+x}" || "$(declare -p DNF_OPTS 2>/dev/null)" != "declare -a"* ]]; then
    declare -ga DNF_OPTS=(--allowerasing --best)
fi
# String variant for legacy/debug visibility only. Do NOT use in commands.
export DNF_SETOPT_STR="${DNF_SETOPT[*]}"
export DNF_OPTS_STR="${DNF_OPTS[*]}"
```

---

## automation/lib/packages.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — Package extraction library
# Parses PACKAGES.md fenced code blocks tagged with ```packages-<category>
#
# Usage:
#   source automation/lib/packages.sh
#   install_packages "gnome"
# shellcheck source=lib/common.sh
#   install_packages_strict "kernel"   # fails if section is empty/missing

get_packages() {
    local category="$1"
    local packages_file="${2:-${PACKAGES_MD:-/ctx/PACKAGES.md}}"

    if [[ ! -f "$packages_file" ]]; then
        echo "[packages.sh] ERROR: $packages_file not found" >&2
        return 1
    fi

    # shellcheck disable=SC2001 # tr is intentionally used here to word-split packages
    sed -n "/^\`\`\`packages-${category}$/,/^\`\`\`$/{/^\`\`\`/d;/^$/d;/^#/d;p}" "$packages_file" \
        | tr '\n' ' '
}

get_packages_strict() {
    local result
    result=$(get_packages "$@")
    if [[ -z "$result" ]]; then
        echo "[packages.sh] ERROR: No packages found in section '$1'" >&2
        return 1
    fi
    echo "$result"
}

_PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${_PKG_DIR}/common.sh"

install_packages() {
    local category="$1"
    local packages_file="${2:-${PACKAGES_MD:-/ctx/PACKAGES.md}}"
    local packages
    packages=$(get_packages "$category" "$packages_file")
    if [[ -n "$packages" ]]; then
        echo "[packages.sh] Installing '$category' packages..."
        # Use subshell so set -e in parent doesn't kill entire script on failure.
        # shellcheck disable=SC2086 # $packages is intentionally word-split here
        ($DNF_BIN "${DNF_SETOPT[@]}" install -y "${DNF_OPTS[@]}" --skip-unavailable --exclude=PackageKit $packages) || {
            echo "[packages.sh] WARNING: Some '$category' packages failed to install" >&2
            echo "[packages.sh] Packages requested: $packages" >&2
        }
    else
        echo "[packages.sh] WARN: No packages in section '$category' — skipping"
    fi
}

install_packages_strict() {
    local category="$1"
    local packages_file="${2:-${PACKAGES_MD:-/ctx/PACKAGES.md}}"
    local packages
    packages=$(get_packages_strict "$category" "$packages_file") || return 1
    echo "[packages.sh] Installing '$category' packages (strict section)..."
    # shellcheck disable=SC2086 # $packages is intentionally word-split here
    $DNF_BIN "${DNF_SETOPT[@]}" install -y "${DNF_OPTS[@]}" --skip-unavailable --exclude=PackageKit $packages || {
        echo "[packages.sh] FATAL: Mandatory '$category' packages failed to install" >&2
        echo "[packages.sh] Packages requested: $packages" >&2
        return 1
    }
}

install_packages_optional() {
    local category="$1"
    local packages_file="${2:-${PACKAGES_MD:-/ctx/PACKAGES.md}}"

    # Check if section exists at all
    local raw_section
    raw_section=$(sed -n "/^\`\`\`packages-${category}$/,/^\`\`\`$/{/^\`\`\`/d;p}" "$packages_file")

    if [[ -z "$raw_section" ]]; then
        echo "[packages.sh] WARN: Section 'packages-${category}' not found — skipping"
        return 0
    fi

    # Check if ALL lines are comments (intentionally disabled)
    local uncommented
    uncommented=$(echo "$raw_section" | grep -v '^#' | grep -v '^$' || true)

    if [[ -z "$uncommented" ]]; then
        echo "[packages.sh] INFO: All packages in '${category}' are commented out (intentionally disabled)"
        return 0
    fi

    # Some packages are uncommented — install those
    local packages
    packages=$(get_packages "$category" "$packages_file")
    if [[ -n "$packages" ]]; then
        echo "[packages.sh] Installing optional '$category' packages..."
        # shellcheck disable=SC2086 # $packages is intentionally word-split here
        ($DNF_BIN "${DNF_SETOPT[@]}" install -y "${DNF_OPTS[@]}" --skip-unavailable --exclude=PackageKit $packages) || {
            echo "[packages.sh] WARNING: Some optional '$category' packages failed" >&2
        }
    fi
}
```

---

## automation/lib/masking.sh

```bash
#!/usr/bin/env bash
# ============================================================================
# automation/lib/masking.sh
# ----------------------------------------------------------------------------
# Credential masking and secure execution helpers.
# ============================================================================

# Internal array of strings to mask
declare -ga MASK_LIST=()

# Register a string to be masked in output
# Usage: add_mask "my-secret-string"
add_mask() {
    local secret="$1"
    if [[ -n "$secret" && "$secret" != "null" ]]; then
        # Avoid duplicates
        for m in "${MASK_LIST[@]}"; do
            [[ "$m" == "$secret" ]] && return 0
        done
        MASK_LIST+=("$secret")
    fi
}

# Register common sensitive environment variables
register_common_masks() {
    local vars=(
        GHCR_TOKEN
        GH_TOKEN
        GITHUB_TOKEN
        MIOS_PASSWORD
        MIOS_PASSWORD_HASH
        SIGNING_SECRET
        COSIGN_PASSWORD
    )
    for v in "${vars[@]}"; do
        if [[ -n "${!v:-}" ]]; then
            add_mask "${!v}"
        fi
    done
}

# Filter stdin to mask registered secrets
# Usage: some_command | mask_filter
mask_filter() {
    if [[ ${#MASK_LIST[@]} -eq 0 ]]; then
        cat
        return
    fi

    local sed_script=""
    for secret in "${MASK_LIST[@]}"; do
        # Escape characters that are special to sed's regex and the delimiter
        # We use '|' as the delimiter for 's' because it's less common in hashes
        # than '/', but we still must escape it if it appears in the secret.
        local escaped_secret=$(printf '%s' "$secret" | sed 's/[][\\.*^$|/]/\\&/g')
        sed_script+="s|$escaped_secret|[MASKED]|g;"
    done
    sed -u "$sed_script"
}

# Prompt for credentials if not set
# Usage: ensure_cred "GHCR_TOKEN" "Enter your GitHub Container Registry Token"
ensure_cred() {
    local var_name="$1"
    local prompt_msg="$2"
    if [[ -z "${!var_name:-}" ]]; then
        read -rsp "$prompt_msg: " val
        echo >&2 # Newline after silent read
        export "$var_name"="$val"
    fi
    add_mask "${!var_name}"
}

# Secure curl wrapper with optional credentials
# Usage: scurl [curl-args] URL
scurl() {
    local args=()
    local use_creds=false
    local url=""
    local is_binary=false
    
    # Simple parser to find the URL and check for binary download flags
    for arg in "$@"; do
        if [[ "$arg" =~ ^https?:// ]]; then
            url="$arg"
        elif [[ "$arg" == "-o" || "$arg" == "-O" || "$arg" == "--output" ]]; then
            is_binary=true
        fi
    done

    # Inherit credentials from environment if available and URL matches github/ghcr
    if [[ "$url" =~ github\.com|ghcr\.io ]]; then
        if [[ -n "${GH_TOKEN:-}" || -n "${GITHUB_TOKEN:-}" || -n "${GHCR_TOKEN:-}" ]]; then
            local token="${GH_TOKEN:-${GITHUB_TOKEN:-${GHCR_TOKEN:-}}}"
            # Use -H for token auth to avoid process list exposure of -u
            args+=("-H" "Authorization: token $token")
            add_mask "$token"
        fi
    fi

    if [[ "$is_binary" == "true" ]]; then
        curl "${args[@]}" "$@"
    else
        curl "${args[@]}" "$@" | mask_filter
    fi
}
```

---

## automation/01-repos.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 01-repos: Fedora 44 overlay on ucore (base kernel preserved)
#
# FIX v0.2.0: Two-phase distro-sync to handle filesystem scriptlet failure.
# The filesystem package's lua %posttrans fails in container builds, aborting
# the entire 1162-package transaction. Without this fix, the system boots with
# F43 core libs but F44 desktop packages — a broken ABI mismatch.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/packages.sh"
source "${SCRIPT_DIR}/lib/common.sh"

# ── Global DNF config ───────────────────────────────────────────────────────
echo "[01-repos] Setting install_weak_deps=False globally..."
DNF_CONF="/usr/lib/dnf/dnf.conf"
if [ ! -f "$DNF_CONF" ]; then
    DNF_CONF="/etc/dnf/dnf.conf"
fi

if [ -f "$DNF_CONF" ]; then
    if ! grep -q '^install_weak_deps=False' "$DNF_CONF"; then
        sed -i '/^install_weak_deps=/d' "$DNF_CONF" 2>/dev/null || true
        echo "install_weak_deps=False" >> "$DNF_CONF"
    fi
fi


# ── Protect Base Repos from Third-Party Ties ───────────────────────────────
echo "[01-repos] Elevating base repos to priority 98..."
if [ -d /etc/yum.repos.d ]; then
    for repo in /etc/yum.repos.d/fedora*.repo /etc/yum.repos.d/ublue-os*.repo; do
        if [ -f "$repo" ] && ! grep -q '^priority=' "$repo"; then
            sed -i '/^\[.*\]/a priority=98' "$repo"
        fi
    done
fi

# ── Fedora 44 repo overlay ─────────────────────────────────────────────────
echo "[01-repos] Adding Fedora 44 repository..."
cat > /etc/yum.repos.d/fedora-44.repo <<'EOREPO'
[fedora-44]
name=Fedora 44 - $basearch
metalink=https://mirrors.fedoraproject.org/metalink?repo=fedora-44&arch=$basearch
enabled=1
countme=1
metadata_expire=6h
repo_gpgcheck=0
type=rpm
gpgcheck=0
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-fedora-44-$basearch
skip_if_unavailable=False
priority=95

[fedora-44-updates]
name=Fedora 44 Updates - $basearch
metalink=https://mirrors.fedoraproject.org/metalink?repo=updates-released-f44&arch=$basearch
enabled=1
countme=1
metadata_expire=6h
repo_gpgcheck=0
type=rpm
gpgcheck=0
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-fedora-44-$basearch
skip_if_unavailable=True
priority=95
EOREPO

# ── Distro-sync to Fedora 44 (TWO-PHASE) ───────────────────────────────────
echo "[01-repos] Distro-sync to Fedora 44 (this takes a while)..."

echo "[01-repos] Phase 1: Pre-upgrading DNF, RPM, and core systemd/filesystem..."
# Isolate the problematic filesystem scriptlet and core package upgrades.
# By doing this first, a filesystem %posttrans failure won't abort the entire
# 1100+ package distro-sync transaction, preventing a fractured RPM database.
$DNF_BIN "${DNF_SETOPT[@]}" upgrade -y --allowerasing --best \
    dnf rpm fedora-release fedora-repos filesystem systemd glibc dbus-broker 2>&1 || {
    echo "[01-repos] NOTE: Pre-upgrade had warnings (likely filesystem lua scriptlet), continuing..."
}

echo "[01-repos] Phase 2: Distro-upgrade and userspace alignment..."
# We use 'upgrade --refresh' to ensure we have fresh metadata and catch latest
# userspace patches, followed by 'distro-sync' to align the remainder with F44.
$DNF_BIN "${DNF_SETOPT[@]}" --setopt=excludepkgs="shim-*,kernel*" upgrade --refresh -y || true
$DNF_BIN "${DNF_SETOPT[@]}" --setopt=excludepkgs="shim-*,kernel*" distro-sync -y --best --allowerasing || {
    echo "[01-repos] WARNING: Distro-sync to Fedora 44 failed. Repository might be unreachable."
    echo "[01-repos] Continuing with base image packages..."
}

echo "[01-repos] Verifying core package versions..."
rpm -q systemd glibc dbus-broker filesystem || true

# ── Pre-install F44 ca-certificates ────────────────────────────────────────
echo "[01-repos] Ensuring F44 ca-certificates is installed..."
$DNF_BIN "${DNF_SETOPT[@]}" install -y ca-certificates p11-kit-trust 2>&1 | tail -5 || true

# ── RPMFusion ───────────────────────────────────────────────────────────────
echo "[01-repos] Installing RPMFusion Free + Nonfree for Rawhide..."
$DNF_BIN "${DNF_SETOPT[@]}" install -y \
    "https://mirrors.rpmfusion.org/free/fedora/rpmfusion-free-release-rawhide.noarch.rpm" \
    "https://mirrors.rpmfusion.org/nonfree/fedora/rpmfusion-nonfree-release-rawhide.noarch.rpm" \
    2>&1 | tail -15 || true


for repo in rpmfusion-free rpmfusion-free-updates rpmfusion-nonfree rpmfusion-nonfree-updates; do
    if [ -f "/etc/yum.repos.d/${repo}.repo" ]; then
        if ! grep -q '^priority=' "/etc/yum.repos.d/${repo}.repo"; then
            sed -i '/^\['"$repo"'\]/a priority=90' "/etc/yum.repos.d/${repo}.repo"
        fi
    fi
done

# ── Terra repo ──────────────────────────────────────────────────────────────
echo "[01-repos] Installing Terra repo..."
$DNF_BIN "${DNF_SETOPT[@]}" install -y --repofrompath 'terra,https://repos.fyralabs.com/terra44' \
    --setopt='terra.gpgcheck=1' --setopt='terra.gpgkey=https://repos.fyralabs.com/terra44/key.asc' \
    terra-release 2>&1 | tail -10 || true

if [ -f /etc/yum.repos.d/terra.repo ]; then
    if ! grep -q '^priority=' /etc/yum.repos.d/terra.repo; then
        sed -i '/^\[terra\]/a priority=85' /etc/yum.repos.d/terra.repo
    fi
    # BIB (bootc-image-builder) runs in a CentOS Stream 10 container and cannot
    # resolve file:// GPG key paths that live inside the MiOS image.
    # Rewrite to https:// and disable repo_gpgcheck so Anaconda ISO manifest
    # generation succeeds without "Couldn't open file RPM-GPG-KEY-terra44".
    sed -i 's|^gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-terra44|gpgkey=https://repos.fyralabs.com/terra44/key.asc|' \
        /etc/yum.repos.d/terra.repo
    sed -i 's/^repo_gpgcheck=1/repo_gpgcheck=0/' /etc/yum.repos.d/terra.repo
fi

# ── CrowdSec repo ──────────────────────────────────────────────────────────
echo "[01-repos] Adding CrowdSec repo..."
cat > /etc/yum.repos.d/crowdsec.repo <<'EOREPO'
[crowdsec]
name=CrowdSec
baseurl=https://packagecloud.io/crowdsec/crowdsec/rpm_any/rpm_any/$basearch
enabled=1
gpgcheck=0
repo_gpgcheck=0
priority=80
EOREPO

# ── NVIDIA Container Toolkit repo ──────────────────────────────────────────
echo "[01-repos] Adding NVIDIA Container Toolkit repo..."
if ! [ -f /etc/yum.repos.d/nvidia-container-toolkit.repo ]; then
    cat > /etc/yum.repos.d/nvidia-container-toolkit.repo <<'EOREPO'
[nvidia-container-toolkit]
name=NVIDIA Container Toolkit
baseurl=https://nvidia.github.io/libnvidia-container/stable/rpm/$basearch
enabled=1
gpgcheck=1
gpgkey=https://nvidia.github.io/libnvidia-container/gpgkey
priority=70
EOREPO
fi

# Ensure all repo files have correct permissions
chmod 0644 /etc/yum.repos.d/*.repo 2>/dev/null || true

echo "[01-repos] Done. Protected base + F44 userspace + RPMFusion + Terra + CrowdSec."
echo "[01-repos] Priority: CrowdSec(80) < Terra(85) < RPMFusion(90) < F44(95) < Base(98) < Default(99)"
```

---

## automation/08-system-files-overlay.sh

```bash
#!/bin/bash
# ============================================================================
# automation/08-system-files-overlay.sh - MiOS v0.2.0
# ----------------------------------------------------------------------------
# Overlay /ctx/ onto the rootfs during the Containerfile build,
# correctly handling the /usr/local -> /var/usrlocal symlink.
#
# v0.2.0 Architecture: Rootfs-Native
#   - Sources now directly from /ctx/usr, /ctx/etc, /ctx/var, /ctx/home
# ============================================================================
set -euo pipefail

# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"

CTX="${CTX:-/ctx}"

log "08-overlay: starting Rootfs-Native overlay"

# --- Stage 1: /usr (everything except /usr/local) --------------------------
if [[ -d "${CTX}/usr" ]]; then
    log "  stage 1: overlay usr content (excluding /usr/local)"
    tar -C "${CTX}/usr" -cf - --exclude='./local' . | tar -C /usr --no-overwrite-dir -xf -
fi

# --- Stage 2: /usr/local via /var/usrlocal ---------------------------------
if [[ -d "${CTX}/usr/local" ]]; then
    log "  stage 2: overlay /usr/local content"
    if [[ -L /usr/local ]]; then
        log "    /usr/local is a symlink -> $(readlink /usr/local); writing through"
        install -d -m 0755 /var/usrlocal
        tar -C "${CTX}/usr/local" -cf - . | tar -C /var/usrlocal --no-overwrite-dir -xf -
    else
        log "    /usr/local is a real directory; writing directly"
        tar -C "${CTX}/usr/local" -cf - . | tar -C /usr/local --no-overwrite-dir -xf -
    fi
fi

# --- Stage 3: /etc (System Config Templates) -------------------------------
if [[ -d "${CTX}/etc" ]]; then
    log "  stage 3: overlay etc content"
    tar -C "${CTX}/etc" -cf - . | tar -C /etc --no-overwrite-dir -xf -
fi

# --- Stage 4: /var (Mutable System State Templates) ------------------------
# DEPRECATED: /var population via tar overlay violates zero-trust immutability.
# All mandatory /var structure must be declared in /usr/lib/tmpfiles.d/*.conf.
# if [[ -d "${CTX}/var" ]]; then
#     log "  stage 4: overlay var content"
#     tar -C "${CTX}/var" -cf - . | tar -C /var --no-overwrite-dir -xf -
# fi

# --- Stage 5: /home (User Space Templates) ---------------------------------
if [[ -d "${CTX}/home" ]]; then
    log "  stage 5: overlay home content"
    mkdir -p /var/home
    tar -C "${CTX}/home" -cf - . | tar -C /var/home --no-overwrite-dir -xf -
fi

# Normalize permissions on systemd unit and config files.
log "08-overlay: normalizing systemd file permissions"
find /usr/lib/systemd -type f \( -name "*.service" -o -name "*.socket" -o -name "*.timer" -o -name "*.mount" -o -name "*.conf" -o -name "*.target" -o -name "*.path" -o -name "*.slice" -o -name "*.preset" -o -name "*.automount" -o -name "*.swap" \) -exec chmod 644 {} \; 2>/dev/null || true
find /usr/lib/systemd -type d -exec chmod 755 {} \; 2>/dev/null || true

# Logically Bound Images
QDIR="/usr/share/containers/systemd"
BDIR="/usr/lib/bootc/bound-images.d"
if [[ -d "${QDIR}" ]]; then
    install -d -m 0755 "${BDIR}"
    shopt -s nullglob
    for q in "${QDIR}"/*.container; do
        name="$(basename "$q")"
        ln -sf "${QDIR}/${name}" "${BDIR}/${name}"
        log "  LBI: bound ${name}"
    done
    shopt -u nullglob
fi

# ═══ Pathing Compatibility ═══
log "08-overlay: applying pathing compatibility symlinks"

# 1. WSL2 looks for /etc/wsl.conf, but we store it in /usr/lib/wsl.conf for immutability
if [[ -f /usr/lib/wsl.conf ]]; then
    ln -sf /usr/lib/wsl.conf /etc/wsl.conf
    log "  WSL: symlinked /etc/wsl.conf -> /usr/lib/wsl.conf"
fi

# 2. Standardize /home to /var/home (FCOS/bootc style)
if [ ! -L /home ] && [ -d /home ] && [ ! "$(ls -A /home)" ]; then
    rm -rf /home
    ln -sf /var/home /home
    log "  Path: symlinked /home -> /var/home"
elif [ ! -e /home ]; then
    ln -sf /var/home /home
    log "  Path: created /home -> /var/home symlink"
fi

log "08-overlay: relabeling overlaid files"
restorecon -RFv /usr/ 2>/dev/null || true
restorecon -RFv /etc/ 2>/dev/null || true

log "08-overlay: complete"
```

---

## automation/10-gnome.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 10-gnome: GNOME 50 desktop — PURE BUILD-UP
#
# STRATEGY: ucore has ZERO GNOME packages. We install exactly what we need.
# With install_weakdeps=False (set globally in 01-repos.sh), only hard deps
# get pulled in. This means:
#   - malcontent-libs comes in (gnome-control-center hard dep) — CORRECT
#   - malcontent-control/pam/tools do NOT come in (weak deps) — CORRECT
#   - No GNOME bloat apps get installed — nothing to remove
#
# The ~25 core packages from the docs produce a fully functional GNOME 50
# Wayland desktop with GDM, all portals, audio, Bluetooth, networking,
# security, and proper theming across GTK3/GTK4/Qt.
#
# CHANGELOG v0.2.0:
#   - MANDATORY Bibata cursor download — retries 3x, FAILS BUILD if missing
#   - dconf profiles for user + GDM added to 
#   - Flatpak: 7 apps (added Flatseal + LocalSend)
#   - adw-gtk3 theme for GTK3 visual consistency
set -euo pipefail
# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/packages.sh"

# ═════════════════════════════════════════════════════════════════════════════
# GNOME 50 — Install from PACKAGES.md (build-up, NOT strip-down)
# ═════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Installing GNOME 50 desktop (pure build-up)..."
install_packages "gnome"

# Optional GNOME Core Apps (all commented out by default in PACKAGES.md)
install_packages_optional "gnome-core-apps"

# ═════════════════════════════════════════════════════════════════════════════
# Localsearch/tracker — disable indexing without removing
# Removing localsearch breaks Nautilus search + Activities Overview.
# Hide via autostart overrides in usr/share/xdg/autostart/
# ═════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Disabling localsearch/tracker indexing (keep package, hide autostart)..."

# ═════════════════════════════════════════════════════════════════════════════
# Qt Adwaita theming — required for Qt apps to match GNOME look
# Managed via usr/lib/environment.d/60-mios-qt-adwaita.conf
# ═════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Setting Qt Adwaita environment variables (managed via overlay)..."

# ═════════════════════════════════════════════════════════════════════════════
# Geist Font (Vercel)
# ═════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Installing Geist font family..."
mkdir -p /usr/share/fonts/geist
git clone --depth=1 https://github.com/vercel/geist-font.git /tmp/geist-font 2>/dev/null || true
if [ -d /tmp/geist-font ]; then
    find /tmp/geist-font \( -name "*.otf" -o -name "*.ttf" \) -exec cp {} /usr/share/fonts/geist/ \; 2>/dev/null || true
    rm -rf /tmp/geist-font
fi
fc-cache -f /usr/share/fonts/geist 2>/dev/null || true

# ═════════════════════════════════════════════════════════════════════════════
# Bibata Cursor Theme — MANDATORY (build fails if download fails)
#
# The cursor shows as a SQUARE when:
#   - /usr/share/icons/Bibata-Modern-Classic/ doesn't exist (download failed)
#   - /usr/share/icons/default/index.theme points to nonexistent theme
#   - dconf cursor-theme references a theme with no files
#
# FIX: Retry download 3 times. VERIFY the cursors directory exists.
#      FAIL THE BUILD if cursors are missing — a square cursor is unacceptable.
# ═════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Installing Bibata-Modern-Classic cursor (MANDATORY)..."
BIBATA_VER=""
BIBATA_FALLBACK="2.0.7"

# Try GitHub API for latest release tag (strips leading 'v')
# v0.2.0: Wrap in subshell + || true to prevent pipefail from killing the script if API is down
BIBATA_VER=$( (scurl -sL -H "Accept: application/vnd.github+json" "https://api.github.com/repos/ful1e5/Bibata_Cursor/releases/latest" \
    | grep -m1 '"tag_name"' | sed 's/.*"v\?\([^"]*\)".*/\1/') 2>/dev/null || true)

# Fallback if API fails (rate limit, network issue)
if [ -z "$BIBATA_VER" ]; then
    BIBATA_VER="$BIBATA_FALLBACK"
    echo "[10-gnome]   GitHub API unavailable — using fallback v${BIBATA_VER}"
else
    echo "[10-gnome]   Latest release: v${BIBATA_VER}"
fi

BIBATA_URL="https://github.com/ful1e5/Bibata_Cursor/releases/download/v${BIBATA_VER}/Bibata-Modern-Classic.tar.xz"
BIBATA_DIR="/usr/share/icons/Bibata-Modern-Classic"
mkdir -p /usr/share/icons

# Download with retries — DO NOT silence errors
BIBATA_OK=0
for attempt in 1 2 3; do
    echo "[10-gnome]   Download attempt $attempt/3..."
    if scurl -fSL --retry 3 --retry-delay 5 "$BIBATA_URL" -o /tmp/bibata.tar.xz; then
        if tar -xf /tmp/bibata.tar.xz -C /usr/share/icons/; then
            rm -f /tmp/bibata.tar.xz
            BIBATA_OK=1
            break
        fi
    fi
    echo "[10-gnome]   Attempt $attempt failed, retrying..."
    sleep 5
done

# VERIFY cursor files actually exist — log warning if missing but DO NOT fail build
if [ "$BIBATA_OK" -eq 0 ] || [ ! -d "$BIBATA_DIR/cursors" ]; then
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  WARNING: Bibata cursor theme download FAILED after 3 attempts"
    echo "  URL: $BIBATA_URL"
    echo "  The cursor will show as a SQUARE until the theme is installed."
    echo "  This failure is non-fatal for the build; users can install later."
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
else
    echo "[10-gnome] ✓ Bibata cursor installed: $(find "$BIBATA_DIR/cursors/" -mindepth 1 -maxdepth 1 | wc -l) cursors"
fi

# Comprehensive cursor default — every layer that reads cursor theme
# Managed via usr/share/icons/default/index.theme
# and usr/share/X11/icons/default/index.theme

# 3. update-alternatives for x-cursor-theme (Fedora cursor resolution)
if [ -d "$BIBATA_DIR/cursors" ]; then
    update-alternatives --install /usr/share/icons/default/index.theme \
        x-cursor-theme /usr/share/icons/Bibata-Modern-Classic/cursor.theme 100 2>/dev/null || true
    echo "[10-gnome] ✓ x-cursor-theme alternative set to Bibata"
fi

# 4. Symlink into /usr/share/cursors/xorg-x11 (legacy X11 cursor path)
mkdir -p /usr/share/cursors/xorg-x11
ln -sf /usr/share/icons/Bibata-Modern-Classic /usr/share/cursors/xorg-x11/Bibata-Modern-Classic 2>/dev/null || true

# 5. GDM user cursor — ensure cursor files are world-readable
chmod -R a+rX "$BIBATA_DIR" 2>/dev/null || true

# 6. Xresources fallback (oldest X11 cursor method)
# Managed via usr/lib/X11/Xresources


# ═══════════════════════════════════════════════════════════════════════════════
# Phosh — Mobile session for portrait/tablet remote access
# ═══════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Installing Phosh mobile session..."
install_packages_optional "phosh"
# Make session wrapper executable
chmod +x /usr/local/bin/phosh-session-wrapper 2>/dev/null || true
# ═════════════════════════════════════════════════════════════════════════════
# Flatpak Remotes
# Disable filtered Fedora remote, use unfiltered Flathub for full catalog
# ═════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Configuring Flatpak remotes..."
if command -v flatpak &>/dev/null; then
    flatpak remote-add --system --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo || true
    flatpak remote-add --system --if-not-exists flathub-beta https://flathub.org/beta-repo/flathub-beta.flatpakrepo || true
    flatpak remote-add --system --if-not-exists gnome-nightly https://nightly.gnome.org/gnome-nightly.flatpakrepo 2>/dev/null || true
    flatpak remote-modify --system --disable fedora 2>/dev/null || true
else
    echo "[10-gnome] WARN: flatpak binary not found, skipping remote configuration"
fi

# ═════════════════════════════════════════════════════════════════════════════
# Essential Flatpaks
# ═════════════════════════════════════════════════════════════════════════════
echo "[10-gnome] Flatpaks will be installed on first boot (mios-flatpak-install.service)..."
# NOTE: mios-flatpak-install.service is enabled in Containerfile STEP D
# (unit file lives in , not available during script execution)

exit 0

```

---

## automation/12-virt.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 12-virt: Virtualization, containers, orchestration, gaming
#
# CHANGELOG v1.3:
#   - Looking Glass B7: MOVED to 53-bake-lookingglass-client.sh (refactored out)
#   - KVMFR module: MOVED to 52-bake-kvmfr.sh (refactored out)
#   - K3s: MOVED to 13-ceph-k3s.sh (no longer duplicated here)
#   - CrowdSec: Updated sovereign mode config (RE2 regex engine default)
#   - Added Podman quadlet example for CrowdSec
#   - VirtIO-Win ISO: Updated URL pattern
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/packages.sh"
source "${SCRIPT_DIR}/lib/common.sh"

KVER=$(cat /tmp/mios-kver 2>/dev/null || find /usr/lib/modules/ -mindepth 1 -maxdepth 1 -printf "%f\n" | sort -V | tail -1)

# ── KVM / QEMU / Libvirt ────────────────────────────────────────────────────
echo "[12-virt] Installing KVM/QEMU/Libvirt..."
install_packages_strict "virt"

# ── Containers (Podman, Buildah, Skopeo, bootc, self-build tools) ────────────
echo "[12-virt] Installing container runtime and self-building tools..."
install_packages_strict "containers"

# Extra self-build tools (image-rechunking, etc. - may be repo-dependent)
install_packages "self-build"

# ── Cockpit Web Management ──────────────────────────────────────────────────
echo "[12-virt] Installing Cockpit..."
install_packages_strict "cockpit"

# ── Boot & Update Management (bootupd, ukify, etc.) ─────────────────────────
echo "[12-virt] Installing boot and update management tools..."
install_packages "boot"

# ── CrowdSec IPS (sovereign/offline mode) ───────────────────────────────────
echo "[12-virt] Installing CrowdSec..."
install_packages "security"

# Sovereign mode: disable Central API, use local-only decisions
if [ -d /etc/crowdsec ]; then
    # acquis.d/journalctl.yaml managed via  overlay

    # Disable online API for sovereign operation
    if [ -f /etc/crowdsec/config.yaml ]; then
        sed -i 's/^online_client:/# online_client:/' /etc/crowdsec/config.yaml 2>/dev/null || true
    fi
    echo "[12-virt] CrowdSec configured for sovereign/offline mode"
fi

# ── Windows Interop & Remote Desktop ────────────────────────────────────────
echo "[12-virt] Installing Windows interop tools..."
install_packages "wintools"

# ── Gaming (Steam, Wine, Gamescope) ─────────────────────────────────────────
# NOTE: steam-devices and udev-joystick-blacklist-rm (terra weak dep of
# gamescope-session-steam) both ship the same udev rules file. Exclude it.
echo "[12-virt] Installing gaming packages..."
GAMING_PKGS=$(get_packages "gaming")
if [[ -n "$GAMING_PKGS" ]]; then
    ($DNF_BIN "${DNF_SETOPT[@]}" install -y "${DNF_OPTS[@]}" --skip-unavailable --exclude=udev-joystick-blacklist-rm $GAMING_PKGS) || {
        echo "[12-virt] WARNING: Some gaming packages failed to install" >&2
    }
fi

# ── Guest Agents ────────────────────────────────────────────────────────────
echo "[12-virt] Installing guest agents..."
install_packages "guests"

# ── Storage ─────────────────────────────────────────────────────────────────
echo "[12-virt] Installing storage packages..."
install_packages "storage"

# ── High Availability (Pacemaker/Corosync) ──────────────────────────────────
echo "[12-virt] Installing HA stack..."
install_packages "ha"

# ── CLI Utilities ───────────────────────────────────────────────────────────
echo "[12-virt] Installing CLI utilities..."
install_packages "utils"

# ── Android (Waydroid) ──────────────────────────────────────────────────────
echo "[12-virt] Installing Waydroid..."
install_packages "android"

# ── VirtIO-Win ISO (latest stable) ─────────────────────────────────────────
echo "[12-virt] Downloading VirtIO-Win ISO..."
VIRTIO_URL="https://fedorapeople.org/groups/virt/virtio-win/direct-downloads/stable-virtio/virtio-win.iso"
mkdir -p /usr/share/mios/virtio
scurl -sL "$VIRTIO_URL" -o /usr/share/mios/virtio/virtio-win.iso 2>/dev/null || {
    echo "[12-virt] WARNING: VirtIO-Win ISO download failed — download manually later"
}

# Symlink the immutable ISO into /var/lib/libvirt/images via tmpfiles.d so it survives upgrades
# Managed via usr/lib/tmpfiles.d/mios-virtio.conf

echo "[12-virt] Virtualization stack complete. (LG: refactored to 53-lg; K3s: refactored to 13-ceph-k3s)"
```

---

## automation/13-ceph-k3s.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 13-ceph-k3s: Ceph distributed storage + K3s Kubernetes
# Cephadm runs ALL server daemons as Podman containers.
# Only client tools + orchestrator binary are baked into the image.
#
# v0.2.0 FIXES:
#   - K3s manifests stored in /usr/share/mios/k3s-manifests/ (not /var)
#     First-boot service copies them to /var/lib/rancher/k3s/server/manifests/
#     This fixes bootc lint: /var content must use tmpfiles.d entries
#   - systemctl enables moved to Containerfile STEP D (unit files in )
set -euo pipefail
# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/packages.sh"

# ─── Ceph Client + Orchestrator ──────────────────────────────────────────────
echo "[13-ceph-k3s] Installing Ceph client tools and cephadm..."
install_packages "ceph"

# ─── K3s Prerequisites ───────────────────────────────────────────────────────
echo "[13-ceph-k3s] Installing K3s prerequisites..."
install_packages "k3s"

# Note: k3s-selinux policy is compiled from source in 19-k3s-selinux.sh

# ─── K3s Binary & Install Script ─────────────────────────────────────────────
echo "[13-ceph-k3s] Resolving latest K3s release tag..."
# Retry 3 times for flaky networks
K3S_TAG=""
for i in 1 2 3; do
    # v0.2.0: Wrap in subshell + || true to prevent pipefail from killing the script if API is down
    K3S_TAG=$( (scurl -sL -o /dev/null -w "%{url_effective}" https://github.com/k3s-io/k3s/releases/latest | grep -oE '[^/]+$') 2>/dev/null || true)
    if [[ -n "$K3S_TAG" && "$K3S_TAG" != "latest" ]]; then break; fi
    sleep 2
done

if [[ -z "$K3S_TAG" || "$K3S_TAG" == "latest" ]]; then
    echo "[13-ceph-k3s] WARN: Could not resolve latest K3s tag. Skipping K3s binary installation."
    K3S_TAG=""
fi

if [[ -n "$K3S_TAG" ]]; then
    echo "[13-ceph-k3s] Latest K3s tag: $K3S_TAG"

    echo "[13-ceph-k3s] Downloading K3s binary, checksum, and install script..."
    K3S_URL="https://github.com/k3s-io/k3s/releases/download/${K3S_TAG}/k3s"
    K3S_SUM_URL="https://github.com/k3s-io/k3s/releases/download/${K3S_TAG}/sha256sum-amd64.txt"
    K3S_INSTALL_URL="https://raw.githubusercontent.com/k3s-io/k3s/${K3S_TAG}/install.sh"

    mkdir -p /tmp/k3s-dl
    if scurl -sfL "$K3S_URL" -o /tmp/k3s-dl/k3s && \
       scurl -sfL "$K3S_SUM_URL" -o /tmp/k3s-dl/sha256sum.txt && \
       scurl -sfL "$K3S_INSTALL_URL" -o /tmp/k3s-dl/k3s-install.sh; then
        cd /tmp/k3s-dl
        if grep -E "  k3s$" sha256sum.txt | sha256sum -c - >/dev/null 2>&1; then
            echo "[13-ceph-k3s] ✓ K3s SHA256 checksum verified"
            mv k3s /usr/local/bin/k3s
            chmod 755 /usr/local/bin/k3s

            # Only symlink if official RPM binaries don't exist, preventing PATH shadowing
            [ ! -f /usr/bin/kubectl ] && ln -sf /usr/local/bin/k3s /usr/local/bin/kubectl 2>/dev/null || true
            [ ! -f /usr/bin/crictl ] && ln -sf /usr/local/bin/k3s /usr/local/bin/crictl 2>/dev/null || true
            [ ! -f /usr/bin/ctr ] && ln -sf /usr/local/bin/k3s /usr/local/bin/ctr 2>/dev/null || true

            mv k3s-install.sh /usr/local/bin/k3s-install.sh
            chmod 755 /usr/local/bin/k3s-install.sh

            echo "[13-ceph-k3s] K3s binary and install script installed (tag: $K3S_TAG)"
        else
            echo "[13-ceph-k3s] ERROR: K3s binary SHA256 checksum mismatch! Skipping."
        fi
        cd - >/dev/null
    else
        echo "[13-ceph-k3s] WARN: K3s download failed. Skipping K3s installation."
    fi
    rm -rf /tmp/k3s-dl
fi

# ─── Make bootstrap script executable ────────────────────────────────────────
chmod 755 /usr/local/bin/ceph-bootstrap.sh 2>/dev/null || true

# ─── NOTE: Service enables are in Containerfile STEP D ───────────────────────
# k3s.service, mios-ceph-bootstrap.service, var-home.mount,
# var-lib-containers.mount all live in  and are enabled
# AFTER the COPY step in the Containerfile.

echo "[13-ceph-k3s] Ceph + K3s stack installed."
echo "[13-ceph-k3s]   Ceph Dashboard:  https://<host>:8443 (after bootstrap)"
echo "[13-ceph-k3s]   K3s API server:  https://<host>:6443 (after boot)"
```

---

## automation/37-selinux.sh

```bash
#!/bin/bash
# MiOS v0.2.0 — 37-selinux: Build-time SELinux policy fixes
# Custom per-rule modules for known Fedora Rawhide / systemd 260 denials.
set -euo pipefail

echo "[37-selinux] Applying SELinux build-time fixes..."

# ═══ Restorecon — fix labels for all major trees ═══
if command -v restorecon &>/dev/null; then
    echo "[37-selinux] Running restorecon on /boot /etc /usr /var..."
    restorecon -R /boot /etc /usr /var 2>/dev/null || true
fi

# ═══ Semanage import — atomic booleans + fcontexts ═══
if command -v semanage &>/dev/null; then
    echo "[37-selinux] Applying SELinux booleans and fcontexts..."
    semanage import <<'EOSEM' 2>/dev/null || true
boolean -m --on container_manage_cgroup
boolean -m --on container_use_cephfs
boolean -m --on daemons_dump_core
boolean -m --on domain_can_mmap_files
boolean -m --on virt_sandbox_use_all_caps
boolean -m --on virt_use_nfs
boolean -m --on virt_use_samba
boolean -m --on nis_enabled
fcontext -a -t boot_t '/boot/bootupd-state.json'
fcontext -a -t accountsd_var_lib_t '/usr/share/accountsservice/interfaces(/.*)?'
fcontext -a -t ceph_var_lib_t '/var/lib/ceph(/.*)?'
fcontext -a -t ceph_log_t '/var/log/ceph(/.*)?'
fcontext -a -t xdm_var_lib_t '/var/lib/gnome-remote-desktop(/.*)?'
EOSEM
    restorecon -v /boot/bootupd-state.json 2>/dev/null || true
    restorecon -R /usr/share/accountsservice 2>/dev/null || true
    restorecon -R /var/lib/gnome-remote-desktop 2>/dev/null || true
    echo "[37-selinux] ✓ Booleans and fcontexts applied"
fi

# ═══ Custom policy modules ═══
if command -v checkmodule &>/dev/null && command -v semodule_package &>/dev/null; then
    echo "[37-selinux] Building custom SELinux policy modules..."

    SELINUX_OK=0
    SELINUX_FAIL=0

    declare -A MIOS_POLICIES

    MIOS_POLICIES[bootupd]='
module mios_bootupd 1.0;
require { type boot_t; type bootupd_t; class file { read getattr open }; }
allow bootupd_t boot_t:file { read getattr open };'

    MIOS_POLICIES[accountsd]='
module mios_accountsd 1.0;
require { type accountsd_t; class lnk_file { read getattr }; }
allow accountsd_t self:lnk_file { read getattr };'

    MIOS_POLICIES[resolved]='
module mios_resolved 1.0;
require { type systemd_resolved_t; type init_var_run_t; class sock_file write; }
allow systemd_resolved_t init_var_run_t:sock_file write;'

    MIOS_POLICIES[fapolicyd]='
module mios_fapolicyd 1.0;
require { type fapolicyd_t; type xdm_var_run_t; class sock_file write; }
allow fapolicyd_t xdm_var_run_t:sock_file write;'

    MIOS_POLICIES[chcon]='
module mios_chcon 1.0;
require { type chcon_t; class capability mac_admin; }
allow chcon_t self:capability mac_admin;'

    MIOS_POLICIES[accountsd_homed]='
module mios_accountsd_homed 1.0;
require { type accountsd_t; type systemd_homed_t; class dbus send_msg; }
allow accountsd_t systemd_homed_t:dbus send_msg;
allow systemd_homed_t accountsd_t:dbus send_msg;'

    MIOS_POLICIES[accountsd_watch]='
module mios_accountsd_watch 1.0;
require { type accountsd_t; type usr_t; class dir { watch watch_reads }; }
allow accountsd_t usr_t:dir { watch watch_reads };'

    MIOS_POLICIES[fapolicyd_gdm]='
module mios_fapolicyd_gdm 1.1;
require { type fapolicyd_t; type xdm_t; class unix_stream_socket connectto; class fd use; class fifo_file write; }
allow fapolicyd_t xdm_t:unix_stream_socket connectto;
allow fapolicyd_t xdm_t:fd use;
allow fapolicyd_t xdm_t:fifo_file write;'

    MIOS_POLICIES[fapolicyd_grd]='
module mios_fapolicyd_grd 1.0;
require { type fapolicyd_t; type gnome_remote_desktop_t; class unix_stream_socket connectto; class fd use; class fifo_file write; }
allow fapolicyd_t gnome_remote_desktop_t:unix_stream_socket connectto;
allow fapolicyd_t gnome_remote_desktop_t:fd use;
allow fapolicyd_t gnome_remote_desktop_t:fifo_file write;'

    MIOS_POLICIES[portabled]='
module mios_portabled 1.0;
require { type init_t; type systemd_portabled_t; class dbus send_msg; }
allow init_t systemd_portabled_t:dbus send_msg;
allow systemd_portabled_t init_t:dbus send_msg;'

    MIOS_POLICIES[kvmfr]='
module mios_kvmfr 1.0;
require { type svirt_t; type device_t; class chr_file { open read write map getattr }; }
allow svirt_t device_t:chr_file { open read write map getattr };'

    MIOS_POLICIES[coreos_bootmount]='
module mios_coreos_bootmount 1.0;
require { type coreos_boot_mount_generator_t; type systemd_generator_unit_file_t; class dir { write add_name remove_name }; class file { create write open rename unlink }; }
allow coreos_boot_mount_generator_t systemd_generator_unit_file_t:dir { write add_name remove_name };
allow coreos_boot_mount_generator_t systemd_generator_unit_file_t:file { create write open rename unlink };'

    MIOS_POLICIES[gdm_cache]='
module mios_gdm_cache 1.0;
require { type xdm_t; type cache_home_t; class dir { add_name write create setattr }; class file { create write open getattr setattr }; }
allow xdm_t cache_home_t:dir { add_name write create setattr };
allow xdm_t cache_home_t:file { create write open getattr setattr };'

    MIOS_POLICIES[homed_varhome]='
module mios_homed_varhome 1.0;
require { type systemd_homed_t; type home_root_t; class dir { read getattr open search }; }
allow systemd_homed_t home_root_t:dir { read getattr open search };'

    MIOS_POLICIES[bootupd_state]='
module mios_bootupd_state 1.1;
require { type bootupd_t; type boot_t; class file { read open getattr lock ioctl }; class dir { read open getattr search }; }
allow bootupd_t boot_t:file { read open getattr lock ioctl };
allow bootupd_t boot_t:dir { read open getattr search };'

    MIOS_POLICIES[resolved_hook]='
module mios_resolved_hook 1.0;
require { type systemd_resolved_t; type init_t; class unix_stream_socket connectto; class sock_file write; }
allow systemd_resolved_t init_t:unix_stream_socket connectto;
allow systemd_resolved_t init_t:sock_file write;'

    MIOS_POLICIES[accountsd_malcontent]='
module mios_accountsd_malcontent 1.0;
require { type accountsd_t; type usr_t; class lnk_file { read getattr }; class file { read open getattr ioctl }; class dir { read open getattr search }; }
allow accountsd_t usr_t:lnk_file { read getattr };
allow accountsd_t usr_t:file { read open getattr ioctl };
allow accountsd_t usr_t:dir { read open getattr search };'

    MIOS_POLICIES[chcon_macadmin]='
module mios_chcon_macadmin 1.0;
require { type chcon_t; class capability2 mac_admin; }
allow chcon_t self:capability2 mac_admin;'

    MIOS_POLICIES[gdm_session_cache]='
module mios_gdm_session_cache 1.0;
require { type xdm_t; type cache_home_t; class dir { add_name write create read open getattr search setattr }; class file { create write read open getattr setattr }; }
allow xdm_t cache_home_t:dir { add_name write create read open getattr search setattr };
allow xdm_t cache_home_t:file { create write read open getattr setattr };'

    mkdir -p /usr/share/selinux/packages/mios

    for name in "${!MIOS_POLICIES[@]}"; do
        echo "${MIOS_POLICIES[$name]}" > "/tmp/mios_${name}.te"
        if checkmodule -M -m -o "/tmp/mios_${name}.mod" "/tmp/mios_${name}.te" 2>/dev/null && \
           semodule_package -o "/tmp/mios_${name}.pp" -m "/tmp/mios_${name}.mod" 2>/dev/null; then
            install -m 0644 "/tmp/mios_${name}.pp" "/usr/share/selinux/packages/mios/mios_${name}.pp"
            echo "[37-selinux] mios_${name}: Staged"
            SELINUX_OK=$((SELINUX_OK + 1))
        else
            echo "[37-selinux] mios_${name}: SKIPPED (type missing in current policy)"
            SELINUX_FAIL=$((SELINUX_FAIL + 1))
        fi
        rm -f "/tmp/mios_${name}".{te,mod,pp}
    done

    echo "[37-selinux] ${SELINUX_OK} policies staged in /usr/share/selinux/packages/mios/, ${SELINUX_FAIL} skipped"
fi

echo "[37-selinux] SELinux configuration complete."
```

---

## automation/42-cosign-policy.sh

```bash
#!/usr/bin/env bash
# ============================================================================
# automation/42-cosign-policy.sh - MiOS v0.2.0
# ----------------------------------------------------------------------------
# Consolidates cosign binary installation, Sigstore trust roots, and policy.json.
# Supercedes 37-cosign-policy.sh.
#
# Note: we pin to v0.2.0 because v3 breaks rpm-ostree bundle format (OCI 1.1).
# ============================================================================
set -euo pipefail

# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"

log "42-cosign-policy: ensuring cosign + trust roots + policy.json"

# 1. Install cosign binary (pinned to v2.x for rpm-ostree compatibility)
if ! command -v cosign >/dev/null 2>&1; then
    log "  downloading cosign v0.2.0 static binary..."
    scurl "https://github.com/sigstore/cosign/releases/download/v0.2.0/cosign-linux-amd64" -o /usr/local/bin/cosign
    chmod +x /usr/local/bin/cosign
fi

SYSFILES="/ctx/system_files"
# Paths updated to /usr/share/pki and /usr/lib/containers as per USR-OVER-ETC
install -d -m 0755 /usr/share/pki/containers
install -d -m 0755 /usr/lib/containers/registries.d

# 2. Install policy.json
# v0.2.0: Moved from etc/ to usr/lib/ in system_files
if [[ -f "${SYSFILES}/usr/lib/containers/policy.json" ]]; then
    install -m 0644 "${SYSFILES}/usr/lib/containers/policy.json" /usr/lib/containers/policy.json
    log "  installed /usr/lib/containers/policy.json"
else
    # Fallback to in-image path if ctx is missing (unlikely in build)
    [[ -f /usr/lib/containers/policy.json ]] || warn "missing policy.json"
fi

# 3. Install Sigstore TUF roots and public keys
# These ship via the usr/share/pki/containers/ overlay
for f in fulcio_v1.crt.pem rekor.pub ublue-os.pub ublue-cosign.pub mios-cosign.pub; do
    src="${SYSFILES}/usr/share/pki/containers/${f}"
    dst="/usr/share/pki/containers/${f}"
    if [[ -f "${src}" ]]; then
        install -m 0644 "${src}" "${dst}"
        log "  installed ${dst}"
    fi
done

# 4. JSON Sanity Check
if command -v jq >/dev/null 2>&1 && [[ -f /usr/lib/containers/policy.json ]]; then
    jq -e . /usr/lib/containers/policy.json >/dev/null || die "policy.json failed jq parse"
    log "  policy.json parses cleanly"
fi

log "42-cosign-policy: validation complete"
```

---

## automation/52-bake-kvmfr.sh

```bash
#!/usr/bin/env bash
# 52-bake-kvmfr.sh - compile Looking Glass kvmfr kmod against the ucore-hci
# kernel shipped in the base image, sign it with the ublue MOK, and bake the
# .ko into /usr/lib/modules/$KVER/extra/kvmfr/.
#
# This runs INSIDE the Containerfile build. No runtime compile. BAKED IN -
# WHEN POSSIBLE.
#
# v0.2.0 fix (supersedes 1.3.0):
#   The previous `if ! dnf5 -y install ... 2>/dev/null; then ... fi` plus
#
#       AVAIL_REPO="$(dnf5 --showduplicates repoquery ... | tail -5 | tr ...)"
#
#   was tripping the whole script with exit 2 BEFORE reaching the graceful-
#   skip block. Root cause: `VAR="$(failing-pipeline)"` under set -euo pipefail
#   causes set -e to fire on the assignment when the pipeline's first command
#   exits non-zero (pipefail promotes the failure). Verified with a reproducer.
#
#   Fix: wrap every dnf5/rpm/dnf5-repoquery call in an explicit
#   `set +e` / `RC=$?` / `set -e` guard. Drop the unreliable repoquery
#   diagnostic entirely - the log line is still informative without it.
#   Looking Glass still runs IVSHMEM-only without kvmfr.
set -euo pipefail

# shellcheck source=lib/common.sh
source "$(dirname "$0")/lib/common.sh"

# --- Detect the kernel version shipped in the base image -------------------
KVER="$(find /usr/lib/modules/ -mindepth 1 -maxdepth 1 -printf "%f\n" 2>/dev/null | sort -V | tail -1)"
if [[ -z "$KVER" ]]; then
    warn "no kernel modules directory; cannot determine kernel version"
    warn "skipping kvmfr bake - Looking Glass will run in IVSHMEM-only mode"
    exit 0
fi
log "building against kernel: $KVER"

# --- Try to get kernel-devel-$KVER exactly matched -------------------------
if [[ ! -d "/usr/src/kernels/$KVER" ]]; then
    log "installing kernel-devel-$KVER"
    set +e
    $DNF_BIN "${DNF_SETOPT[@]}" install -y "${DNF_OPTS[@]}" "kernel-devel-$KVER" >/dev/null 2>&1
    RC=$?
    set -e
    if [[ $RC -ne 0 ]]; then
        set +e
        AVAIL="$(rpm -qa 'kernel-devel*' 2>/dev/null | tr '\n' ' ')"
        set -e
        warn "SKIP: no exact kernel-devel for $KVER (dnf rc=$RC; installed: ${AVAIL:-none})"
        warn "      The ucore-hci base kernel $KVER is typically newer/older than"
        warn "      F44's repo-published kernel-devel. Project principle is 'never"
        warn "      upgrade base kernel in-container', so kvmfr is skipped here."
        warn "      Looking Glass still works in IVSHMEM-only mode. To enable kvmfr"
        warn "      on the booted image once the kernel matches, run:"
        warn "         sudo dnf install kernel-devel-\$(uname -r) akmod-kvmfr"
        warn "         sudo akmods --force --kernels \$(uname -r)"
        exit 0
    fi
fi

# --- Install akmod-kvmfr (from hikariknight/looking-glass-kvmfr COPR) ------
log "installing akmod-kvmfr"
set +e
$DNF_BIN "${DNF_SETOPT[@]}" install -y "${DNF_OPTS[@]}" akmod-kvmfr >/dev/null 2>&1
RC=$?
set -e
if [[ $RC -ne 0 ]]; then
    warn "SKIP: akmod-kvmfr install failed (rc=$RC; COPR unreachable or package missing)"
    warn "      verify COPR enabled: dnf5 copr list | grep looking-glass-kvmfr"
    exit 0
fi

# --- Force-build kvmfr kmod for this kernel --------------------------------
log "running akmods --force --kernels $KVER"
set +e
akmods --force --kernels "$KVER" 2>&1 | sed 's/^/[akmods] /'
RC=${PIPESTATUS[0]}
set -e
if [[ $RC -ne 0 ]]; then
    warn "SKIP: akmods build failed (rc=$RC)"
    warn "      checking /var/cache/akmods/kvmfr/ for build log..."
    find /var/cache/akmods/ -name '*.log' -exec tail -50 {} \; 2>/dev/null || true
    exit 0
fi

# --- Verify the kmod landed -------------------------------------------------
KMOD_PATH="/usr/lib/modules/$KVER/extra/kvmfr/kvmfr.ko"
if [[ -f "$KMOD_PATH" ]] || [[ -f "${KMOD_PATH}.xz" ]] || [[ -f "${KMOD_PATH}.zst" ]]; then
    log "OK: kvmfr.ko baked in at /usr/lib/modules/$KVER/extra/kvmfr/"
    ls -la "/usr/lib/modules/$KVER/extra/kvmfr/"
else
    warn "SKIP: kvmfr.ko NOT FOUND after akmods build"
    warn "      listing /usr/lib/modules/$KVER/extra/:"
    ls -la "/usr/lib/modules/$KVER/extra/" 2>/dev/null || warn "  (no extra/ dir)"
    exit 0
fi

# --- Update module dependencies --------------------------------------------
log "running depmod -a -b /usr $KVER"
depmod -a -b /usr "$KVER" || warn "depmod failed (non-fatal)"

# --- Sign the module with ublue MOK (if present, for Secure Boot) ----------
PRIV_KEY="/etc/pki/akmods/private/private_key.priv"
PUB_KEY="/etc/pki/akmods/certs/public_key.der"
if [[ -f "$PRIV_KEY" && -f "$PUB_KEY" ]]; then
    log "signing kvmfr.ko with akmods private key"
    SIGN_FILE="/usr/src/kernels/$KVER/automation/sign-file"
    if [[ -x "$SIGN_FILE" ]]; then
        for ko in /usr/lib/modules/$KVER/extra/kvmfr/*.ko; do
            [[ -f "$ko" ]] && "$SIGN_FILE" sha256 "$PRIV_KEY" "$PUB_KEY" "$ko" && \
                log "  signed: $ko"
        done
    else
        warn "sign-file script not found at $SIGN_FILE; kvmfr unsigned"
    fi
else
    log "NOTE: ublue MOK private key not in image (expected); users enroll MOK"
    log "      and kvmfr will use the public cert shipped by ublue-os-akmods-addons"
fi

log "kvmfr kmod BAKED IN"
```

---

## automation/53-bake-lookingglass-client.sh

```bash
#!/usr/bin/env bash
# 53-bake-lookingglass-client.sh - git clone Looking Glass B7, cmake/make,
# install looking-glass-client binary to /usr/bin/. BAKED IN - WHEN POSSIBLE.
#
# v0.2.0 fix:
#   - SKIP (don't fail) when cmake or required dev libraries are missing.
#     12-virt.sh already builds Looking Glass as part of its virtualization
#     stack and then removes cmake/gcc/*-devel to shrink the image. By the
#     time this script runs the toolchain is gone. Skipping here is safe
#     because the binary is already installed by 12-virt.sh; a hard-fail
#     aborted the whole build for a redundant second build attempt.
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"

# --- If 12-virt.sh already baked it in, declare success and exit -----------
if [[ -x /usr/bin/looking-glass-client ]]; then
    log "OK: looking-glass-client already present (installed by 12-virt.sh)"
    /usr/bin/looking-glass-client --version 2>&1 | head -5 || true
    exit 0
fi

# --- Check toolchain availability ------------------------------------------
MISSING=""
for tool in cmake make gcc git; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        MISSING="${MISSING}${tool} "
    fi
done

if [[ -n "$MISSING" ]]; then
    warn "SKIP: missing toolchain: $MISSING"
    warn "      12-virt.sh normally builds Looking Glass and removes cmake/gcc"
    warn "      afterwards. If 12-virt.sh failed, fix it first - the LG build"
    warn "      there is the canonical path."
    exit 0
fi

LG_BRANCH="${LG_BRANCH:-B7}"
BUILD_DIR="/tmp/LookingGlass-build"

# --- Clone -----------------------------------------------------------------
log "cloning Looking Glass $LG_BRANCH"
rm -rf "$BUILD_DIR"
if ! git clone --depth 1 --branch "$LG_BRANCH" --recurse-submodules \
        https://github.com/gnif/LookingGlass.git "$BUILD_DIR"; then
    warn "SKIP: git clone failed (network or branch issue)"
    exit 0
fi

# --- Configure + build client ---------------------------------------------
log "configuring client build"
mkdir -p "$BUILD_DIR/client/build"
cd "$BUILD_DIR/client/build"
if ! cmake -DCMAKE_INSTALL_PREFIX=/usr \
           -DCMAKE_INSTALL_LIBDIR=/usr/lib \
           -DCMAKE_BUILD_TYPE=Release \
           -DENABLE_LIBDECOR=ON \
           -DENABLE_PIPEWIRE=ON \
           -DENABLE_PULSEAUDIO=OFF \
           -DENABLE_BACKTRACE=OFF \
           ..; then
    warn "SKIP: cmake configure failed - check -devel packages"
    exit 0
fi

log "building looking-glass-client (jobs=$(nproc))"
if ! make -j"$(nproc)"; then
    warn "SKIP: make failed"
    exit 0
fi

# --- Install binary + desktop file ----------------------------------------
log "installing binary to /usr/bin/looking-glass-client"
install -Dm0755 looking-glass-client /usr/bin/looking-glass-client

# Ship a .desktop entry
install -Dm0644 /dev/stdin /usr/share/applications/looking-glass.desktop <<'DESK'
[Desktop Entry]
Type=Application
Name=Looking Glass
Comment=Low-latency KVM display from a VM via shared memory
Icon=video-display
Exec=looking-glass-client
Terminal=false
Categories=System;Utility;
Keywords=KVM;VFIO;Passthrough;
DESK

# --- Cleanup build tree (keep toolchain in image per self-building principle) ---
log "cleaning up source tree"
cd /
rm -rf "$BUILD_DIR"

# --- Verify ----------------------------------------------------------------
if [[ -x /usr/bin/looking-glass-client ]]; then
    log "OK: looking-glass-client baked in at /usr/bin/looking-glass-client"
    /usr/bin/looking-glass-client --version 2>&1 | head -5 || true
else
    warn "SKIP: binary missing after install (non-fatal)"
    exit 0
fi

log "Looking Glass client BAKED IN"
```

---

## automation/99-postcheck.sh

```bash
#!/usr/bin/env bash
# 99-postcheck.sh - build-time technical invariant validation
# 
# This script runs at the very end of the Containerfile build (before cleanup).
# It enforces mandatory version requirements, security postures, and 
# architectural purity. Failures here ABORT THE BUILD to prevent shipping
# a regressed or vulnerable image.
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"

echo "════════════ MiOS Build-Time Validation ════════════"

# 1. OpenSSH Version Check (CVE-2026-4631 / Cockpit RCE mitigation)
# Requirement: ≥ 9.6
log "Checking OpenSSH version..."
if ! command -v sshd >/dev/null 2>&1; then
    die "sshd not found in image (required for Podman-machine & remote mgmt)"
fi

SSH_VER_RAW=$(sshd -V 2>&1 | head -n1 | grep -oP 'OpenSSH_\K[0-9.]+')
log "  Found: OpenSSH $SSH_VER_RAW"

# Compare version (simple dot-split comparison)
if [[ $(printf '%s\n9.6' "$SSH_VER_RAW" | sort -V | head -n1) != "9.6" ]]; then
    die "OpenSSH version $SSH_VER_RAW is below required 9.6 (Vulnerable to CVE-2026-4631 in Cockpit context)"
fi
log "  ✓ OpenSSH version is safe"

# 2. Cockpit Security Posture
log "Checking Cockpit configuration..."
# In Rootfs-Native, config might be in /etc or /usr/lib
if [[ -f "/etc/cockpit/cockpit.conf" ]]; then
    COCKPIT_CONF="/etc/cockpit/cockpit.conf"
elif [[ -f "/usr/lib/cockpit/cockpit.conf" ]]; then
    COCKPIT_CONF="/usr/lib/cockpit/cockpit.conf"
else
    COCKPIT_CONF=""
fi

if [[ -f "$COCKPIT_CONF" ]]; then
    if ! grep -q "LoginTo = false" "$COCKPIT_CONF"; then
        die "Cockpit LoginTo mitigation missing in $COCKPIT_CONF (CVE-2026-4631)"
    fi
    log "  ✓ Cockpit LoginTo = false is enforced"
else
    log "  ⚠ Cockpit config not found at expected paths; skipping check"
fi

# 3. Kernel Argument Validation (Schema Strictness Preparation)
log "Validating kargs.d files..."
if [[ -d /usr/lib/bootc/kargs.d ]]; then
    for f in /usr/lib/bootc/kargs.d/*; do
        [[ -e "$f" ]] || continue
        # Future: run 'bootc container lint' or specialized schema check
        log "  found karg: $(basename "$f")"
    done
    log "  ✓ kargs.d presence verified"
fi

# 4. Critical Package Verification
log "Verifying critical system binaries..."
CRITICAL_TOOLS=(podman bootc cockpit-bridge rpm-ostree)
for tool in "${CRITICAL_TOOLS[@]}"; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        die "Critical tool '$tool' is missing from the image"
    fi
    log "  ✓ $tool present"
done

# 5. NVIDIA Container Toolkit Version Check
log "Checking NVIDIA Container Toolkit version..."
if command -v nvidia-ctk >/dev/null 2>&1; then
    NCT_VER=$(nvidia-ctk --version | head -n1 | grep -oP 'version \K[0-9.]+')
    log "  Found: $NCT_VER"
    if [[ $(printf '%s\n1.18' "$NCT_VER" | sort -V | head -n1) != "1.18" ]]; then
        die "nvidia-container-toolkit version $NCT_VER is below required 1.18"
    fi
    log "  ✓ NVIDIA Container Toolkit version is safe"
fi

# 6. Cockpit Version Check (for CVE-2026-4631)
log "Checking Cockpit version..."
if rpm -q cockpit >/dev/null 2>&1; then
    COCKPIT_VER=$(rpm -q cockpit --queryformat '%{VERSION}')
    log "  Found: Cockpit $COCKPIT_VER"
    # CVE fixed in 360. MiOS targets 361+ for Fedora 44 GA stability.
    if [[ $(printf '%s\n361' "$COCKPIT_VER" | sort -V | head -n1) != "361" ]]; then
        log "  ⚠ Cockpit version $COCKPIT_VER is below 361 (Risk: CVE-2026-4631 / Regressions)"
    else
        log "  ✓ Cockpit version is safe"
    fi
fi

echo "═════════════ Validation SUCCESSFUL ═════════════"
exit 0
```
