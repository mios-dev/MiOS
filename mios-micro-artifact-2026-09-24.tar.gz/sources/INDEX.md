# Preserved Sources Master Index (2026-09-24)
Master provenance ledger indexing all preserved specifications, streamlined manifests, telemetry dumps, and CVE audits:

## Manifests & Reports
- `sources/manifests/daily-tarball-manifest-2026-09-24.md` (Streamlined tarball manifest)
- `sources/manifests/daily-tarball-manifest-2026-09-24.json` (Structured JSON manifest)
- `sources/reports/artifact-publisher-run-report-2026-09-24.md` (Streamlined publication run report)
- `sources/reports/artifact-publisher-run-report-2026-09-24.json` (Structured JSON run report)

## Specifications
- `sources/specs/AGENT-ARTIFACT-SYSTEM-PROMPT.md` (Authoritative agent contract)
- `sources/specs/MiOS-AI-Training-Spec-2026-09-24.md` (Harness & training specification)
- `sources/specs/MiOS-Repo-To-Micro-Spec-2026-09-23.md` (Upstream mios-micro specification)

## References & Telemetry
- `sources/references/shell-shortcuts-interaction-reference.md` (CLI sigils & terminal shortcuts)
- `sources/telemetry/WS-CUA-OSWorld-G-2026-09-24.json` (Task completion telemetry)
- `sources/telemetry/WS-SEC-Tetragon-Latency-2026-09-24.json` (eBPF latency telemetry)
- `sources/cve-audits/Kernel-7.2.8-Podman-5.8.2.md` (Kernel and container security audit)
