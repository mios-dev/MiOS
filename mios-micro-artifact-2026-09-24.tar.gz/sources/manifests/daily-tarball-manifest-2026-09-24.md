# mios-micro Daily Tarball Manifest (2026-09-24)
- **Repository:** `mios-micro` (Repository for Training Data)
- **System Prompt:** `AGENT-ARTIFACT-SYSTEM-PROMPT.md`
- **Artifact ID:** `MIOS-MICRO-COMBINED-ARTIFACT-2026-09-24`
- **Packaging:** 1 Singular Combined Tarball (`mios-micro-artifact-2026-09-24.tar.gz`)
- **OCI Image Reference:** `ghcr.io/mios-dev/mios-micro:train-latest`
- **Storage Destination:** `MiOS-RnD` (Google Drive folder ID: `1P36wJy2QUglpIvKiO9fL5rOsvMe0K1z4`)

## Verification Summary
- **OCI Descriptor Closure:** 100% verified. All index, manifest, config, and layer blobs physically present in `blobs/sha256/`.
- **AI Training Integrity:** Valid UTF-8 JSONL, strict Hugging Face TRL schema, 0 PII/secrets, complete assistant targets.
- **Stopping Invariants:** HW (PASS), SEC (PASS), CUA (PASS), ISO (PASS), REL (PASS).
- **Publication Verdict:** ACCEPT (Gold Standard).
