#!/bin/bash
# MiOS Build Progress Library - TTY0 Compatible
# Cross-platform progress indicators (Linux/Windows/WSL2)
# ASCII-only characters for maximum compatibility

# Detect terminal capabilities
TTY_WIDTH=$(tput cols 2>/dev/null || echo 80)
TTY_SUPPORTS_COLOR=false
TTY_SUPPORTS_CURSOR=false

if [[ -t 1 ]] && command -v tput &>/dev/null; then
    if tput setaf 1 &>/dev/null; then
        TTY_SUPPORTS_COLOR=true
    fi
    if tput cup 0 0 &>/dev/null; then
        TTY_SUPPORTS_CURSOR=true
    fi
fi

# ASCII-only box drawing characters (TTY0 compatible)
BOX_TL="+"  # Top-left corner
BOX_TR="+"  # Top-right corner
BOX_BL="+"  # Bottom-left corner
BOX_BR="+"  # Bottom-right corner
BOX_H="-"   # Horizontal line
BOX_V="|"   # Vertical line
BOX_FILL="="  # Progress bar fill
BOX_EMPTY="."  # Progress bar empty

# Colors (if supported)
if $TTY_SUPPORTS_COLOR; then
    COLOR_RESET="\033[0m"
    COLOR_RED="\033[0;31m"
    COLOR_GREEN="\033[0;32m"
    COLOR_YELLOW="\033[0;33m"
    COLOR_BLUE="\033[0;34m"
    COLOR_CYAN="\033[0;36m"
    COLOR_GRAY="\033[0;90m"
    COLOR_BOLD="\033[1m"
else
    COLOR_RESET=""
    COLOR_RED=""
    COLOR_GREEN=""
    COLOR_YELLOW=""
    COLOR_BLUE=""
    COLOR_CYAN=""
    COLOR_GRAY=""
    COLOR_BOLD=""
fi

# Status symbols (ASCII-only)
SYMBOL_OK="[OK]"
SYMBOL_FAIL="[FAIL]"
SYMBOL_WARN="[WARN]"
SYMBOL_INFO="[INFO]"
SYMBOL_SKIP="[SKIP]"
SYMBOL_RUN="[RUN]"

# ==============================================================================
# Box Drawing Functions (ASCII-only)
# ==============================================================================

# Draw horizontal line
draw_hline() {
    local width=${1:-$TTY_WIDTH}
    printf '%*s\n' "$width" | tr ' ' "$BOX_H"
}

# Draw box top
draw_box_top() {
    local width=${1:-$TTY_WIDTH}
    local title="${2:-}"
    if [[ -z "$title" ]]; then
        printf "$BOX_TL"
        printf '%*s' $((width - 2)) | tr ' ' "$BOX_H"
        printf "$BOX_TR\n"
    else
        local title_len=${#title}
        local padding=$(( (width - title_len - 4) / 2 ))
        printf "$BOX_TL"
        printf '%*s' $padding | tr ' ' "$BOX_H"
        printf " $title "
        printf '%*s' $((width - title_len - padding - 4)) | tr ' ' "$BOX_H"
        printf "$BOX_TR\n"
    fi
}

# Draw box bottom
draw_box_bottom() {
    local width=${1:-$TTY_WIDTH}
    printf "$BOX_BL"
    printf '%*s' $((width - 2)) | tr ' ' "$BOX_H"
    printf "$BOX_BR\n"
}

# Draw box line with text
draw_box_line() {
    local width=${1:-$TTY_WIDTH}
    local text="${2:-}"
    printf "$BOX_V %-*s $BOX_V\n" $((width - 4)) "$text"
}

# ==============================================================================
# Progress Bar Functions
# ==============================================================================

# Draw progress bar
# Usage: progress_bar <current> <total> [width]
progress_bar() {
    local current=$1
    local total=$2
    local width=${3:-40}

    local percent=$(( (current * 100) / total ))
    local filled=$(( (current * width) / total ))
    local empty=$(( width - filled ))

    printf "["
    printf '%*s' "$filled" | tr ' ' "$BOX_FILL"
    printf '%*s' "$empty" | tr ' ' "$BOX_EMPTY"
    printf "] %3d%% (%d/%d)" "$percent" "$current" "$total"
}

# Progress bar with spinner (for indeterminate progress)
# Usage: progress_spinner <message>
progress_spinner() {
    local message="$1"
    local spin='/-\|'
    local i=0
    while true; do
        printf "\r${COLOR_CYAN}${SYMBOL_RUN}${COLOR_RESET} %s ${spin:i++%${#spin}:1}" "$message"
        sleep 0.1
    done
}

# ==============================================================================
# Build Phase Tracking
# ==============================================================================

# Global build state
BUILD_PHASE_CURRENT=0
BUILD_PHASE_TOTAL=0
BUILD_PHASE_START_TIME=0
BUILD_PHASE_LOG_FILE="${MIOS_BUILD_LOG:-/var/log/mios-build.log}"

# Initialize build tracking
# Usage: build_init <total_phases> [log_file]
build_init() {
    BUILD_PHASE_TOTAL=$1
    BUILD_PHASE_LOG_FILE="${2:-$BUILD_PHASE_LOG_FILE}"
    BUILD_PHASE_START_TIME=$(date +%s)
    BUILD_PHASE_CURRENT=0

    mkdir -p "$(dirname "$BUILD_PHASE_LOG_FILE")"

    echo "========================================" >> "$BUILD_PHASE_LOG_FILE"
    echo "MiOS Build Started: $(date -Iseconds)" >> "$BUILD_PHASE_LOG_FILE"
    echo "Total Phases: $BUILD_PHASE_TOTAL" >> "$BUILD_PHASE_LOG_FILE"
    echo "========================================" >> "$BUILD_PHASE_LOG_FILE"

    draw_box_top 70 "MiOS Build Starting"
    draw_box_line 70 "Total Phases: $BUILD_PHASE_TOTAL"
    draw_box_line 70 "Started: $(date '+%Y-%m-%d %H:%M:%S')"
    draw_box_bottom 70
    echo ""
}

# Start a build phase
# Usage: build_phase_start <phase_number> <phase_name>
build_phase_start() {
    local phase_num=$1
    local phase_name="$2"
    BUILD_PHASE_CURRENT=$phase_num

    local phase_start_time=$(date +%s)

    echo "----------------------------------------" >> "$BUILD_PHASE_LOG_FILE"
    echo "Phase $phase_num/$BUILD_PHASE_TOTAL: $phase_name" >> "$BUILD_PHASE_LOG_FILE"
    echo "Started: $(date -Iseconds)" >> "$BUILD_PHASE_LOG_FILE"
    echo "----------------------------------------" >> "$BUILD_PHASE_LOG_FILE"

    printf "\n${COLOR_CYAN}${COLOR_BOLD}"
    progress_bar "$phase_num" "$BUILD_PHASE_TOTAL" 50
    printf "${COLOR_RESET}\n"
    printf "${COLOR_YELLOW}Phase %d/%d: %s${COLOR_RESET}\n" "$phase_num" "$BUILD_PHASE_TOTAL" "$phase_name"
    printf "%s\n" "$(draw_hline 70)"
}

# Complete a build phase
# Usage: build_phase_complete <status> [message]
build_phase_complete() {
    local status="$1"  # ok, fail, warn, skip
    local message="${2:-}"

    local phase_end_time=$(date +%s)
    local phase_duration=$((phase_end_time - BUILD_PHASE_START_TIME))

    case "$status" in
        ok)
            printf "${COLOR_GREEN}%s Phase %d complete${COLOR_RESET}" "$SYMBOL_OK" "$BUILD_PHASE_CURRENT"
            ;;
        fail)
            printf "${COLOR_RED}%s Phase %d failed${COLOR_RESET}" "$SYMBOL_FAIL" "$BUILD_PHASE_CURRENT"
            ;;
        warn)
            printf "${COLOR_YELLOW}%s Phase %d completed with warnings${COLOR_RESET}" "$SYMBOL_WARN" "$BUILD_PHASE_CURRENT"
            ;;
        skip)
            printf "${COLOR_GRAY}%s Phase %d skipped${COLOR_RESET}" "$SYMBOL_SKIP" "$BUILD_PHASE_CURRENT"
            ;;
    esac

    if [[ -n "$message" ]]; then
        printf " - %s" "$message"
    fi
    printf "\n"

    echo "Status: $status" >> "$BUILD_PHASE_LOG_FILE"
    if [[ -n "$message" ]]; then
        echo "Message: $message" >> "$BUILD_PHASE_LOG_FILE"
    fi
    echo "Duration: ${phase_duration}s" >> "$BUILD_PHASE_LOG_FILE"
    echo "" >> "$BUILD_PHASE_LOG_FILE"
}

# Finish build tracking
# Usage: build_finish <status>
build_finish() {
    local status="$1"  # success, failure
    local end_time=$(date +%s)
    local total_duration=$((end_time - BUILD_PHASE_START_TIME))

    local hours=$((total_duration / 3600))
    local minutes=$(( (total_duration % 3600) / 60 ))
    local seconds=$((total_duration % 60))

    echo "========================================" >> "$BUILD_PHASE_LOG_FILE"
    echo "MiOS Build Finished: $(date -Iseconds)" >> "$BUILD_PHASE_LOG_FILE"
    echo "Status: $status" >> "$BUILD_PHASE_LOG_FILE"
    echo "Total Duration: ${hours}h ${minutes}m ${seconds}s" >> "$BUILD_PHASE_LOG_FILE"
    echo "========================================" >> "$BUILD_PHASE_LOG_FILE"

    echo ""
    if [[ "$status" == "success" ]]; then
        draw_box_top 70 "Build Complete"
        draw_box_line 70 "${SYMBOL_OK} All phases completed successfully"
    else
        draw_box_top 70 "Build Failed"
        draw_box_line 70 "${SYMBOL_FAIL} Build did not complete successfully"
    fi
    draw_box_line 70 "Total Time: ${hours}h ${minutes}m ${seconds}s"
    draw_box_line 70 "Log: $BUILD_PHASE_LOG_FILE"
    draw_box_bottom 70
    echo ""
}

# ==============================================================================
# Logging Functions (unified with progress)
# ==============================================================================

# Log with timestamp
# Usage: log_msg <level> <message>
log_msg() {
    local level="$1"
    local message="$2"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')

    case "$level" in
        INFO)
            printf "${COLOR_BLUE}${SYMBOL_INFO}${COLOR_RESET} %s\n" "$message"
            ;;
        OK)
            printf "${COLOR_GREEN}${SYMBOL_OK}${COLOR_RESET} %s\n" "$message"
            ;;
        WARN)
            printf "${COLOR_YELLOW}${SYMBOL_WARN}${COLOR_RESET} %s\n" "$message"
            ;;
        FAIL)
            printf "${COLOR_RED}${SYMBOL_FAIL}${COLOR_RESET} %s\n" "$message"
            ;;
        SKIP)
            printf "${COLOR_GRAY}${SYMBOL_SKIP}${COLOR_RESET} %s\n" "$message"
            ;;
    esac

    echo "[$timestamp] [$level] $message" >> "$BUILD_PHASE_LOG_FILE"
}

# Convenience wrappers
log_info() { log_msg INFO "$1"; }
log_ok() { log_msg OK "$1"; }
log_warn() { log_msg WARN "$1"; }
log_fail() { log_msg FAIL "$1"; }
log_skip() { log_msg SKIP "$1"; }

# ==============================================================================
# Checkpoint System (snapshot build state)
# ==============================================================================

CHECKPOINT_DIR="${MIOS_CHECKPOINT_DIR:-/var/lib/mios/checkpoints}"

# Create build checkpoint
# Usage: checkpoint_create <name> <data>
checkpoint_create() {
    local name="$1"
    local data="$2"

    mkdir -p "$CHECKPOINT_DIR"
    local checkpoint_file="$CHECKPOINT_DIR/${name}.checkpoint"

    cat > "$checkpoint_file" <<EOF
timestamp=$(date -Iseconds)
phase=$BUILD_PHASE_CURRENT
data=$data
EOF

    log_info "Checkpoint created: $name"
}

# Load checkpoint
# Usage: checkpoint_load <name>
checkpoint_load() {
    local name="$1"
    local checkpoint_file="$CHECKPOINT_DIR/${name}.checkpoint"

    if [[ -f "$checkpoint_file" ]]; then
        source "$checkpoint_file"
        log_info "Checkpoint loaded: $name (phase $phase)"
    else
        log_warn "Checkpoint not found: $name"
        return 1
    fi
}

# ==============================================================================
# Build Statistics
# ==============================================================================

# Track package installation
STATS_PACKAGES_INSTALLED=0
STATS_PACKAGES_FAILED=0
STATS_FILES_COPIED=0
STATS_SERVICES_ENABLED=0

# Increment stats (use || true to prevent set -e exit on 0 value)
stats_package_installed() { ((STATS_PACKAGES_INSTALLED++)) || true; }
stats_package_failed() { ((STATS_PACKAGES_FAILED++)) || true; }
stats_file_copied() { ((STATS_FILES_COPIED++)) || true; }
stats_service_enabled() { ((STATS_SERVICES_ENABLED++)) || true; }

# Print build statistics
stats_print() {
    draw_box_top 70 "Build Statistics"
    draw_box_line 70 "Packages Installed: $STATS_PACKAGES_INSTALLED"
    draw_box_line 70 "Package Failures: $STATS_PACKAGES_FAILED"
    draw_box_line 70 "Files Copied: $STATS_FILES_COPIED"
    draw_box_line 70 "Services Enabled: $STATS_SERVICES_ENABLED"
    draw_box_bottom 70
}

# Export all functions
export -f draw_hline draw_box_top draw_box_bottom draw_box_line
export -f progress_bar progress_spinner
export -f build_init build_phase_start build_phase_complete build_finish
export -f log_msg log_info log_ok log_warn log_fail log_skip
export -f checkpoint_create checkpoint_load
export -f stats_package_installed stats_package_failed stats_file_copied stats_service_enabled stats_print
