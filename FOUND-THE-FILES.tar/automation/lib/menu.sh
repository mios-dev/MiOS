#!/usr/bin/env bash
# ============================================================================
# automation/lib/menu.sh
# ----------------------------------------------------------------------------
# Unified menu and interactive UI components for MiOS.
# ============================================================================

# Colors - MiOS-Build Theme (Teal/Coral/White)
readonly MENU_TEAL='\033[38;5;43m'
readonly MENU_CORAL='\033[38;5;210m'
readonly MENU_WHITE='\033[1;37m'
readonly MENU_GRAY='\033[38;5;245m'
readonly MENU_SUCCESS='\033[38;5;48m'
readonly MENU_YELLOW='\033[1;33m'
readonly MENU_BLUE='\033[0;34m'
readonly MENU_CYAN='\033[0;36m'
readonly MENU_MAGENTA='\033[0;35m'
readonly MENU_BOLD='\033[1m'
readonly MENU_DIM='\033[2m'
readonly MENU_NC='\033[0m'

# --- Banner & Headers -------------------------------------------------------

menu_banner() {
    local title="$1"
    local subtitle="${2:-}"
    
    clear
    echo -e "${MENU_BOLD}${MENU_CYAN}*****************************************************************"
    echo -e "* $(printf "%-61s" "$title") *"
    if [[ -n "$subtitle" ]]; then
        echo -e "* $(printf "%-61s" "$subtitle") *"
    fi
    echo -e "*****************************************************************${MENU_NC}"
    echo ""
}

menu_header() {
    local title="$1"
    echo -e "${MENU_BOLD}${MENU_TEAL}--- $title ---${MENU_NC}"
    echo ""
}

# --- Menu Items -------------------------------------------------------------

menu_item() {
    local key="$1"
    local label="$2"
    local status="${3:-}"
    local color="${4:-$MENU_TEAL}"
    
    local status_str=""
    if [[ -n "$status" ]]; then
        status_str=" ${MENU_CYAN}[$status]${MENU_NC}"
    fi
    
    echo -e "  ${color}${key})${MENU_NC} ${label}${status_str}"
}

menu_spacer() {
    echo ""
}

menu_section() {
    local title="$1"
    echo -e "${MENU_BOLD}${MENU_MAGENTA}*** $title ***${MENU_NC}"
}

# --- Prompts & Input --------------------------------------------------------

menu_prompt() {
    local message="${1:-Selection}"
    local default="${2:-}"
    local result_var="$3"
    
    local prompt_str="  ${MENU_BOLD}${MENU_WHITE}${message}${MENU_NC}"
    if [[ -n "$default" ]]; then
        prompt_str+=" ${MENU_GRAY}(default: $default)${MENU_NC}"
    fi
    prompt_str+=": "
    
    read -p "$(echo -e "$prompt_str")" val
    val="${val:-$default}"
    
    eval "$result_var=\"$val\""
}

menu_prompt_secret() {
    local message="$1"
    local result_var="$2"
    
    echo -ne "  ${MENU_BOLD}${MENU_WHITE}${message}${MENU_NC}: "
    read -rs val
    echo ""
    eval "$result_var=\"$val\""
}

menu_pause() {
    local message="${1:-Press Enter to return to menu...}"
    echo ""
    read -p "$(echo -e "  ${MENU_GRAY}$message${MENU_NC}")"
}

menu_confirm() {
    local message="$1"
    local default="${2:-N}"
    local result_var="$3"
    
    local prompt_char="y/N"
    [[ "$default" =~ ^[Yy]$ ]] && prompt_char="Y/n"
    
    echo -ne "  ${MENU_BOLD}${MENU_WHITE}${message}${MENU_NC} [${prompt_char}]: "
    read -n 1 -r val
    echo ""
    
    if [[ -z "$val" ]]; then
        val="$default"
    fi
    
    if [[ "$val" =~ ^[Yy]$ ]]; then
        eval "$result_var=true"
    else
        eval "$result_var=false"
    fi
}

# --- Status Indicators ------------------------------------------------------

menu_log_info() { echo -e "  ${MENU_BLUE}[INFO]${MENU_NC} $*"; }
menu_log_success() { echo -e "  ${MENU_SUCCESS}[OK]${MENU_NC} $*"; }
menu_log_warn() { echo -e "  ${MENU_YELLOW}[WARN]${MENU_NC} $*"; }
menu_log_error() { echo -e "  ${MENU_CORAL}[FAIL]${MENU_NC} $*"; }
