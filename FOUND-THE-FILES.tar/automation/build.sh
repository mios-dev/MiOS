#!/bin/bash
# MiOS v0.1.4 - Master Build Runner v2
# TTY0-Compatible with Native Progress Bars and Unified Logging
# Executes all numbered scripts with integrated smoke testing

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/common.sh"
source "${SCRIPT_DIR}/lib/progress.sh"

register_common_masks

export PACKAGES_MD="${PACKAGES_MD:-/ctx/PACKAGES.md}"
export MIOS_BUILD_LOG="${MIOS_BUILD_LOG:-/usr/lib/mios/logs/build.log}"
export MIOS_STATE_DIR="${MIOS_STATE_DIR:-/tmp/mios-build-state}"
export MIOS_CHECKPOINT_DIR="${MIOS_CHECKPOINT_DIR:-/var/lib/mios/checkpoints}"

# Create directories
mkdir -p "$(dirname "$MIOS_BUILD_LOG")"
mkdir -p "$MIOS_STATE_DIR"
mkdir -p "$MIOS_CHECKPOINT_DIR"

# Clear previous state
rm -f "$MIOS_STATE_DIR"/*

# Unified logging: redirect to log file with masking
exec 3>&1  # Save stdout for progress updates
exec 4>&2  # Save stderr
exec > >(mask_filter >> "$MIOS_BUILD_LOG") 2>&1

# Version detection
VERSION_RAW="$(cat "${SCRIPT_DIR}/../VERSION" 2>/dev/null || cat /ctx/VERSION 2>/dev/null || echo '0.1.4')"
VERSION_STR=$(echo "$VERSION_RAW" | sed 's/^MiOSv//;s/^v//')
export MIOS_VERSION="$VERSION_STR"

#===============================================================================
# Build Phase Definitions
#===============================================================================

CONTAINERFILE_SCRIPTS="08-system-files-overlay.sh"  # Run in Containerfile stage 1

# Count total phases
ALL_SCRIPTS=("$SCRIPT_DIR"/[0-9][0-9]-*.sh)
TOTAL_SCRIPTS=0
for script in "${ALL_SCRIPTS[@]}"; do
    SCRIPT_NAME="$(basename "$script")"
    if ! echo "$CONTAINERFILE_SCRIPTS" | grep -qF "$SCRIPT_NAME"; then
        TOTAL_SCRIPTS=$((TOTAL_SCRIPTS + 1))
    fi
done

# Add phases: scripts + bloat-removal + cleanup + smoke-test
TOTAL_PHASES=$((TOTAL_SCRIPTS + 3))

#===============================================================================
# Initialize Build Tracking
#===============================================================================

build_init "$TOTAL_PHASES" "$MIOS_BUILD_LOG"

log_info "MiOS v${VERSION_STR} Build Starting" >&3
log_info "Total Phases: $TOTAL_PHASES" >&3
log_info "Log File: $MIOS_BUILD_LOG" >&3

if [[ ! -f "$PACKAGES_MD" ]]; then
    log_fail "FATAL: $PACKAGES_MD not found" >&3
    exit 1
fi

#===============================================================================
# Phase Execution: Numbered Scripts
#===============================================================================

PHASE=0
for script in "${ALL_SCRIPTS[@]}"; do
    SCRIPT_NAME="$(basename "$script")"

    # Skip scripts run in Containerfile
    if echo "$CONTAINERFILE_SCRIPTS" | grep -qF "$SCRIPT_NAME"; then
        continue
    fi

    PHASE=$((PHASE + 1))

    # Start phase
    build_phase_start "$PHASE" "$SCRIPT_NAME" >&3

    # Execute script
    PHASE_START_TIME=$(date +%s)
    set +e
    export MIOS_BUILD_STATE="$MIOS_STATE_DIR"
    bash "$script"
    SCRIPT_EXIT=$?
    set -e
    PHASE_DURATION=$(($(date +%s) - PHASE_START_TIME))

    # Record result
    if [[ $SCRIPT_EXIT -eq 0 ]]; then
        touch "$MIOS_STATE_DIR/${SCRIPT_NAME}.ok"
        build_phase_complete "ok" "${PHASE_DURATION}s" >&3
        stats_package_installed
    else
        touch "$MIOS_STATE_DIR/${SCRIPT_NAME}.fail"
        build_phase_complete "fail" "Exit code: $SCRIPT_EXIT" >&3
        stats_package_failed
    fi

    # Checkpoint after every 10 phases
    if (( PHASE % 10 == 0 )); then
        checkpoint_create "phase-${PHASE}" "Completed ${SCRIPT_NAME}"
    fi
done

#===============================================================================
# Phase: Bloat Removal
#===============================================================================

PHASE=$((PHASE + 1))
build_phase_start "$PHASE" "Remove Bloat Packages" >&3

BLOAT_PACKAGES=$(source "${SCRIPT_DIR}/lib/packages.sh"; get_packages "bloat")
if [[ -n "$BLOAT_PACKAGES" ]]; then
    log_info "Removing bloat packages: $BLOAT_PACKAGES"
    $DNF_BIN "${DNF_SETOPT[@]}" remove -y "${DNF_OPTS[@]}" $BLOAT_PACKAGES || true
    build_phase_complete "ok" "Bloat packages removed" >&3
else
    build_phase_complete "skip" "No bloat packages defined" >&3
fi

#===============================================================================
# Phase: Final Cleanup
#===============================================================================

PHASE=$((PHASE + 1))
build_phase_start "$PHASE" "Final Cleanup" >&3

log_info "Cleaning DNF cache"
rm -rf /var/cache/dnf/* /var/cache/libdnf5/*

log_info "Creating repository artifact snapshot"
if [[ -d "/ctx" ]]; then
    ARTIFACT_DIR="/usr/lib/mios/artifacts"
    mkdir -p "$ARTIFACT_DIR"
    tar -cJf "${ARTIFACT_DIR}/repo-snapshot.tar.xz" -C /ctx . 2>/dev/null || true
    stats_file_copied
fi

build_phase_complete "ok" "Cleanup complete" >&3

#===============================================================================
# Phase: Integrated Smoke Test
#===============================================================================

PHASE=$((PHASE + 1))
build_phase_start "$PHASE" "Smoke Test (Build Validation)" >&3

# Inline smoke test (simplified for build-time)
SMOKE_PASS=0
SMOKE_FAIL=0

smoke_check() {
    local test_name="$1"
    local test_command="$2"

    if eval "$test_command" &>/dev/null; then
        log_ok "$test_name" >&3
        ((SMOKE_PASS++))
        return 0
    else
        log_fail "$test_name" >&3
        ((SMOKE_FAIL++))
        return 1
    fi
}

log_info "Running build-time validation checks" >&3

# Critical packages
smoke_check "gnome-shell installed" "rpm -q gnome-shell"
smoke_check "podman installed" "rpm -q podman"
smoke_check "bootc installed" "rpm -q bootc"
smoke_check "cockpit installed" "rpm -q cockpit"

# Filesystem structure
smoke_check "/home -> /var/home symlink" "test -L /home"
smoke_check "/opt -> /var/opt symlink" "test -L /opt"
smoke_check "/usr/lib/locale.conf exists" "test -f /usr/lib/locale.conf"

# Systemd services
smoke_check "gdm.service enabled" "systemctl is-enabled gdm.service 2>/dev/null"
smoke_check "cockpit.socket enabled" "systemctl is-enabled cockpit.socket 2>/dev/null"
smoke_check "sshd.service enabled" "systemctl is-enabled sshd.service 2>/dev/null"

# Security hardening
smoke_check "sysctl hardening present" "test -f /usr/lib/sysctl.d/99-mios-hardening.conf"
smoke_check "bootc kargs present" "test -f /usr/lib/bootc/kargs.d/00-mios.toml"

# Footgun check (should NOT be present)
smoke_check "PackageKit NOT installed" "! rpm -q PackageKit"
smoke_check "gnome-tour NOT installed" "! rpm -q gnome-tour"

if [[ $SMOKE_FAIL -eq 0 ]]; then
    build_phase_complete "ok" "All $SMOKE_PASS checks passed" >&3
else
    build_phase_complete "warn" "$SMOKE_FAIL/$((SMOKE_PASS + SMOKE_FAIL)) checks failed" >&3
fi

#===============================================================================
# Build Statistics and Summary
#===============================================================================

TOTAL_DURATION=$(($(date +%s) - BUILD_PHASE_START_TIME))
FAIL_COUNT=$(find "$MIOS_STATE_DIR" -maxdepth 1 -name "*.fail" 2>/dev/null | wc -l)

# Print statistics
stats_print >&3

# Final status
if [[ $FAIL_COUNT -eq 0 ]]; then
    build_finish "success" >&3
    exit 0
else
    FAIL_LIST=$(find "$MIOS_STATE_DIR" -maxdepth 1 -name "*.fail" 2>/dev/null | xargs -n1 basename | sed 's/\.fail//' | tr '\n' ' ')
    log_fail "Build failed. Failed scripts: $FAIL_LIST" >&3
    build_finish "failure" >&3
    exit 1
fi
