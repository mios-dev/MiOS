# Preserved Sources Master Index (2026-09-24)
- sources/specs/MiOS-AI-Training-Spec-2026-09-24.md (Google Drive ID: 12NRMg0YMt2MwkFFVa--2YGvCxz8tzMBWjebUUpNwtk0)
- sources/specs/MiOS-Repo-To-Micro-Spec-2026-09-23.md (Google Drive ID: 11MF2ZrLCVMNJZ_QKHs59GEDByMi2z4zf3r0ABWDnHZo)
- sources/telemetry/WS-CUA-OSWorld-G-2026-09-24.json
- sources/telemetry/WS-SEC-Tetragon-Latency-2026-09-24.json
- sources/cve-audits/Kernel-7.2.8-Podman-5.8.2.md
