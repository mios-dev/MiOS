# MiOS AI Training Artifact Manifest (2026-09-24)
Complete self-contained bundle for the root of github.com/mios-dev/MiOS.
Includes devcontainer harness, MCP config, Hugging Face TRL datasets, and preserved sources.
