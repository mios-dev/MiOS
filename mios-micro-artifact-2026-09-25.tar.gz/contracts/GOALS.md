# MiOS Dev-Loop Acceptance Stopping Invariants (GOALS.md)

1. [INVARIANT-HW]: Kernel 7.2.8 CXL.mem bypass directives eliminate DMAR status reg 2 faults on Blackwell PCIe 5.0 (pci=realloc,noaer,cxl_iommu_bypass=force).
2. [INVARIANT-SEC]: Tetragon v1.4.3 eBPF out-of-process gating intercepts 100% of unauthorized egress sockets with latency <= 1.85ms and zero /dev/kvmfr0 DMA lock contention.
3. [INVARIANT-CUA]: Holo1.5-7B visual grounding loop achieves >= 70% task completion on OSWorld-G with cycle latency <= 120ms (verified at 72.4% / 115ms).
4. [INVARIANT-ISO]: 4-tier isolation ladder promotes untrusted execution to Tier 4 libkrun microVMs with startup overhead <= 90ms (verified at 82ms).
5. [INVARIANT-REL]: Frozen admin-100 suite maintains Reliability AUC >= 0.965 with zero silent regression passes (verified at 0.971).
