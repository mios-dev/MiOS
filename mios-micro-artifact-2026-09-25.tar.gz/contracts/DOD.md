# Definition of Done (DOD.md)

1. Multi-repo worktree hygiene checked and cleanly unmounted.
2. Verified dataset pairs formatted to mios-micro Hugging Face TRL standards.
3. All source documents and telemetry preserved under sources/ with INDEX.md.
4. Two-sided verification gates executed with zero phantom failures.
5. Canonical OCI archive (oci-layout, index.json, blobs/) and POSIX tarball built.
