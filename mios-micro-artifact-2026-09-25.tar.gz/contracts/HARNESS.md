# Multi-Agent Harness Orchestration Contract (HARNESS.md)

Port Mapping:
- :8080 - Unified Router (Law 5 endpoint)
- :8633 - MiOS-OpenCode Builder Agent
- :8640 - MiOS-Sys-Agent Orchestrator
- :11441 - SGLang Heavy Inference Lane (Llama-3.3-70B)
- :11450 - Local Fast Draft Model (Holo1.5-7B)
