# Upstream 24h Intelligence Audit (UPSTREAM_AUDIT.md)
- Linux Kernel: 7.2.8 point release (CXL host bridge decoding fix)
- Podman / crun: Podman 5.8.2 / crun 1.20 (hardened pasta rootless detach)
- bootc: 1.16.14 with composefs metadata signature validation
- Tetragon: 1.4.3 eBPF tracepoint hardening
- SGLang: 0.5.20 execution engine
- MCP SDK: v2.0.2 RFC-8832 compliance
