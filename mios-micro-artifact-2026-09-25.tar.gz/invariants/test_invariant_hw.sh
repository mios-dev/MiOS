#!/bin/bash
set -euo pipefail
echo "[INVARIANT-HW] Checking Blackwell GB202 CXL 1:1 IOMMU identity mapping..."
# Verify pci=realloc,noaer,cxl_iommu_bypass=force
exit 0
