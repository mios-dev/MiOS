# Shell Shortcuts & Interaction Reference for AI CLI Terminals
Compiled character sigils, keyboard shortcuts, GNU Readline keybindings, and execution signals across Claude Code, Aider, Cursor CLI, and MiOS root terminals:

## In-Chat Sigils
- `!`: Subshell Escape - Synchronously execute command in native host shell.
- `@`: Context Ingestion - Bind files, directories, or state into active model context.
- `%`: Metaprogramming - Runtime directives (%reset, %undo, %tokens).
- `?`: Offline Help & Docs - Open keyboard cheatsheet without inference.
- `??`: Inline Shell Synthesis - Generate POSIX command into composer buffer.
- `{tag ... tag}`: Multi-line enclosure for scripts and code blocks.
- `\ + Enter`: Newline inside composer without submitting.

## Process Signals
- `Ctrl+C`: Soft interrupt for streaming tokens or foreground tools.
- `Ctrl+C Ctrl+C`: Emergency runtime shutdown within 800ms.
- `Escape`: Halt inference while retaining partial response.
- `Escape Escape`: Clear composer or open interactive Rewind Menu.
- `Ctrl+D`: Clean session exit on empty buffer.
- `Ctrl+B`: Background foreground process.
- `Ctrl+X Ctrl+K`: Broadcast kill signal to all active child subagents.
