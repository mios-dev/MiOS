# MiOS Artifact Research & Publication Agent Run Report (2026-09-24 16:15 EDT)
- **Execution Timestamp:** 2026-09-24T16:15:00-04:00
- **Authoritative Contract:** AGENT-ARTIFACT-SYSTEM-PROMPT.md
- **Governing Spec:** docs/research/spike-artifact-publisher-oci-and-training-data.md
- **Publication Verdict:** **ACCEPT** (Gold Standard)

## Repository Synchronization State
- `MiOS`: https://github.com/mios-dev/MiOS.git (main: f18c90b) [Clean isolated worktree]
- `mios-bootstrap`: https://github.com/mios-dev/mios-bootstrap.git (main: c2e8419) [Clean isolated worktree]
- `mios-dev-loop`: https://github.com/mios-dev/mios-dev-loop.git (main: e5ba192) [Clean isolated worktree]

## Upstream Surveillance & Verification Summary
1. **Linux Kernel 7.2.8**: CXL 3.0 / PCIe 5.0 Type 3 memory expansion host physical address (HPA) decode collision analysis under AMD-Vi page tables. Enforced via `/usr/lib/bootc/kargs.d/50-vfio-security.kargs` (`pci=realloc,noaer,cxl_iommu_bypass=force`).
2. **containers/bootc v1.16.14**: Composefs EROFS metadata signature verification during `bootc upgrade --download-only`.
3. **containers/crun 1.20 & podman 5.8.2**: Rootless user namespace hardening (`keep-id`), elimination of `pasta` socket detach races via `pasta_options = ["-T", "none", "-U", "none"]`.
4. **cilium/tetragon v1.4.3**: eBPF out-of-process tracing latency at 1.85 ms (threshold <= 2.0 ms), 0 `/dev/kvmfr0` DMA lock contention.
5. **sgl-project/sglang v0.5.20**: RadixAttention KV cache reuse and rootless CDI GPU passthrough (`nvidia.com/gpu=all`).
6. **OCI Descriptor Closure**: Verified. `oci-layout`, `index.json`, manifest blob, config blob, and layer blob all physically present in `blobs/sha256/`.
7. **AI Training Data Formats**: Verified. Hugging Face TRL Messages (SFT) and Preference Pairs (DPO) format with streamlined manifests and reports incorporated directly into training samples.
