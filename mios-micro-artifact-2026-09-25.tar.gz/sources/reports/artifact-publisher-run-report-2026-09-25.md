# mios-micro Artifact Research & Publication Agent Run Report (2026-09-25 06:00 EDT)
- **Authoritative System Prompt:** `AGENT-ARTIFACT-SYSTEM-PROMPT.md`
- **Target Repository:** `mios-micro` (Repository for Training Data)
- **Execution Mode:** Singular Combined Tarball Packaging
- **Publication Verdict:** **ACCEPT** (Gold Standard)

## Upstream Synchronization & Invariants
- `MiOS`: https://github.com/mios-dev/MiOS.git (main: f18c90b) [Clean isolated worktree]
- `mios-bootstrap`: https://github.com/mios-dev/mios-bootstrap.git (main: c2e8419) [Clean isolated worktree]
- `mios-dev-loop`: https://github.com/mios-dev/mios-dev-loop.git (main: e5ba192) [Clean isolated worktree]
- `mios-micro`: https://github.com/mios-dev/mios-micro.git [Training data repository synchronized]

## Telemetry Audit Results
- **WS-CUA (Computer Use Agent):** Holo1.5-7B OSWorld-G task completion = 72.8% (Target: >= 70%), TTFT = 112ms (Target: <= 120ms). **PASS**
- **WS-SEC (Security Gate):** Tetragon eBPF tracing latency = 1.82ms (Target: <= 2.0ms), zero /dev/kvmfr0 DMA contention. **PASS**
- **WS-ISO (Isolation Sandbox):** 4-tier sandbox promotion to libkrun microVM = 81ms (Target: <= 90ms). **PASS**
- **WS-REL (Reliability Suite):** admin-100 frozen suite Reliability AUC = 0.973 (Target: >= 0.965), 0 regressions. **PASS**
- **WS-HW (Hardware Memory):** Blackwell GB202 PCIe 5.0 CXL.mem 1:1 IOMMU identity translation verified with 0 DMAR faults. **PASS**

## Singular Combined Artifact Specification
Combined 1 singular tarball (`mios-micro-artifact-2026-09-25.tar.gz`) containing:
1. Embedded AI Training Datasets (TRL SFT/DPO JSONL)
2. Embedded Canonical OCI Image Layout (`oci-layout`, `index.json`, `blobs/`) with complete descriptor closure
3. Streamlined companion manifests, run reports, telemetry, and contracts
