# MiOS-AI Daily Tarball Manifest (2026-09-24)
- **Artifact ID:** ARTIFACTOR-BUNDLE-MIOS-AI-2026-09-24-STREAMLINED
- **Timestamp:** 2026-09-24T16:15:00-04:00
- **Target Repository:** github.com/mios-dev/MiOS
- **Governing Standard:** mios-micro Upstream AI Training & Dataset Specification
- **OCI Image Reference:** ghcr.io/mios-dev/mios:train-latest
- **Storage Location:** Google Drive folder MiOS-RnD (ID: 1P36wJy2QUglpIvKiO9fL5rOsvMe0K1z4)

## Included Artifacts
1. `mios-ai-training-data-artifact-2026-09-24.tar.gz`: Native POSIX tarball formatted for MiOS repository root extraction.
2. `mios-training-oci-image-2026-09-24.tar`: Canonical OCI Image Layout archive with complete descriptor closure.

## Directory Layout
- `.devcontainer/`: Automated devcontainer harness and initialization scripts.
- `.mcp.json`: Model Context Protocol v2.0 standard tool configuration.
- `llms.txt`: Standard LLM discovery manifest.
- `contracts/`: Authoritative contracts (GOALS.md, DOD.md, HARNESS.md, UPSTREAM_AUDIT.md).
- `datasets/`: SFT & DPO training data adhering to Hugging Face TRL conversational standards.
- `sources/`: Preserved specifications, streamlined run reports, telemetry ledgers, and master INDEX.md.
- `invariants/`: Hardware, security, and reliability stopping invariant tests.
- `automation/`: Ingestion, distillation, OCI packaging, and atomic deployment pipeline.
- `harness/`: Two-sided verification gates.
- `artifact.md`: Streamlined inline manifest.
