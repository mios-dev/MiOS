#!/bin/bash
# MiOS Pipeline Automation: 03-build-bootc-oci.sh
echo '[automation] Executing 03-build-bootc-oci.sh...'
exit 0
