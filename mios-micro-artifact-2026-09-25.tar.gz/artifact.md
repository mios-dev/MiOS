# mios-micro Training Data Repository Artifact (2026-09-25)
- **Repository:** `mios-micro` (Authoritative Repository for AI Training Data - https://github.com/mios-dev/mios-micro)
- **Authoritative System Prompt:** `AGENT-ARTIFACT-SYSTEM-PROMPT.md`
- **Architecture:** 1 Singular Combined Tarball with Embedded AI Training Sets and OCI Image Layout Combined
- **Artifact Identifier:** `mios-micro-artifact-2026-09-25.tar.gz`
- **Destination:** Google Drive folder `MiOS-RnD` (ID: 1P36wJy2QUglpIvKiO9fL5rOsvMe0K1z4)

## Architecture & Embedded Structure
This singular tarball unifies the complete training data repository and canonical OCI layout:
1. **Embedded Canonical OCI Image Layout (Complete Descriptor Closure)**:
   - `oci-layout`: Standard OCI version specification (`{"imageLayoutVersion": "1.0.0"}`)
   - `index.json`: Resolves to manifest blob for `ghcr.io/mios-dev/mios-micro:train-latest`
   - `blobs/sha256/`: Contains content-addressed manifest, container config, and filesystem layer blobs with verified digests.
2. **Embedded AI Training Data (`datasets/`)**:
   - `datasets/sft.jsonl`: Conversational Supervised Fine-Tuning records adhering to Hugging Face TRL Messages format.
   - `datasets/dpo.jsonl`: Direct Preference Optimization pairs adhering to Hugging Face TRL format.
   - `datasets/dataset_info.json`: Feature schemas, sample metadata, and train/val configuration.
3. **Preserved Research & Streamlined Manifests (`sources/`)**:
   - `sources/manifests/`: Daily tarball manifests in Markdown and JSON.
   - `sources/reports/`: Daily publication run reports in Markdown and JSON.
   - `sources/specs/`: Canonical copies of `AGENT-ARTIFACT-SYSTEM-PROMPT.md` and training specs.
   - `sources/references/`: Terminal shortcuts and CLI interaction references.
   - `sources/INDEX.md`: Master provenance ledger.
4. **Development & Verification Harness**:
   - `.devcontainer/`: Full devcontainer specification and initialization scripts.
   - `.mcp.json`: Model Context Protocol v2.0 server configurations.
   - `contracts/`: GOALS.md, DOD.md, HARNESS.md, UPSTREAM_AUDIT.md.
   - `invariants/`: Hardware, security, and reliability stopping invariant test suites.
   - `automation/`: Ingestion, distillation, OCI packaging, and atomic deployment pipelines.
   - `harness/`: Verification gates.
   - `llms.txt`: Discovery standard.
