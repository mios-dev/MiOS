#!/bin/bash
set -euo pipefail
echo "[devcontainer:post-create] Initializing embedded agent harness workspace..."
mkdir -p .devloop_artifacts .worktrees
git config --global --add safe.directory /workspace || true
echo "[devcontainer:post-create] Workspace permissions verified."
