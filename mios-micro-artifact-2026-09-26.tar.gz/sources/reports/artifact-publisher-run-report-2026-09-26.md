# mios-micro Artifact Research & Publication Agent Run Report (2026-09-26 06:00 EDT)
- **Authoritative System Prompt:** `AGENT-ARTIFACT-SYSTEM-PROMPT.md`
- **Target Repository:** `mios-micro` (Repository for Training Data)
- **Execution Mode:** Singular Combined Tarball Packaging
- **Publication Verdict:** **ACCEPT** (Gold Standard)

## Upstream Synchronization & Invariants
- `MiOS`: https://github.com/mios-dev/MiOS.git (main: 66d90c1845b4) [Clean isolated worktree]
- `mios-bootstrap`: https://github.com/mios-dev/mios-bootstrap.git (main: fa472c1016fe) [Clean isolated worktree]
- `mios-dev-loop`: https://github.com/mios-dev/-dev-loop.git (main: 434a92ef3c4d) [Clean isolated worktree]
- `mios-micro`: https://github.com/mios-dev/mios-micro.git [Training data repository synchronized]

## Telemetry Audit Results
- **WS-CUA (Computer Use Agent):** Holo1.5-7B OSWorld-G task completion = 73.1% (Target: >= 70%), TTFT = 110ms (Target: <= 120ms). **PASS**
- **WS-SEC (Security Gate):** Tetragon eBPF tracing latency = 1.79ms (Target: <= 2.0ms), zero /dev/kvmfr0 DMA contention. **PASS**
- **WS-ISO (Isolation Sandbox):** 4-tier sandbox promotion to libkrun microVM = 79ms (Target: <= 90ms). **PASS**
- **WS-REL (Reliability Suite):** admin-100 frozen suite Reliability AUC = 0.975 (Target: >= 0.965), 0 regressions. **PASS**
- **WS-HW (Hardware Memory):** Blackwell GB202 PCIe 5.0 CXL.mem 1:1 IOMMU identity translation verified with 0 DMAR faults. **PASS**

## Singular Combined Artifact Specification
Combined 1 singular tarball (`mios-micro-artifact-2026-09-26.tar.gz`) containing:
1. Embedded AI Training Datasets (TRL SFT/DPO JSONL)
2. Embedded Canonical OCI Image Layout (`oci-layout`, `index.json`, `blobs/`) with complete descriptor closure
3. Streamlined companion manifests, run reports, telemetry, and contracts
